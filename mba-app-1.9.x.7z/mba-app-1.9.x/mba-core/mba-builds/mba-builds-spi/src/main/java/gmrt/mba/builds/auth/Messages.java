package gmrt.mba.builds.auth;

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/6/11
 */
public class Messages {

    public static String MbaAuthInstaller_Install() {
        return "Managed Build Authentication and Authorization";
    }

}
