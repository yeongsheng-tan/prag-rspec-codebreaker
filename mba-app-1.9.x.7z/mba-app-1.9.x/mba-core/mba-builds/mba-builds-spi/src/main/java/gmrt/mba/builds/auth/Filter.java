package gmrt.mba.builds.auth;

import gmrt.mba.Appliance;
import org.acegisecurity.Authentication;
import org.acegisecurity.context.SecurityContextHolder;
import org.acegisecurity.event.authentication.InteractiveAuthenticationSuccessEvent;
import org.acegisecurity.ui.webapp.AuthenticationProcessingFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Implements a standard  {@link javax.servlet.Filter}  that ties the  {@link Realm} into Hudson authentication.
 *
 * @author jason.stiefel@bankofamerica.com
 */
public class Filter extends AuthenticationProcessingFilter {

    /**
     * Because we're never going to redirect the user for authentication or present a form or anything like that we
     * are overriding the default filter implementation so we can control the flow. This eliminates calls to:
     * <li>{@link org.acegisecurity.ui.AbstractProcessingFilter#onPreAuthentication}
     * <li>{@link org.acegisecurity.ui.AbstractProcessingFilter#successfulAuthentication}
     * Authentication should _never_ fail here (the appliance takes care of that) so just need to run through the
     * process and not worry about catching failure exceptions.
     */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        if (requiresAuthentication(httpRequest, httpResponse)) {
            Authentication authResult = attemptAuthentication(httpRequest);
            SecurityContextHolder.getContext().setAuthentication(authResult);
            if (eventPublisher != null) {
                eventPublisher.publishEvent(new InteractiveAuthenticationSuccessEvent(authResult, this.getClass()));
            }
        }

        chain.doFilter(request, response);
    }

    /**
     * Checks {@link org.acegisecurity.context.SecurityContext} for an {@link Authentication}. Checks to see if the
     * authentication matches the {@link gmrt.da.auth.User} so we can "detect" users switching
     * roles.
     */
    @Override
    protected boolean requiresAuthentication(HttpServletRequest request, HttpServletResponse response) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null)
            return true;

        if (authentication instanceof Realm.ManagedBuildAuth) {
            Realm.ManagedBuildAuth auth = (Realm.ManagedBuildAuth)authentication;
            return !Appliance.getInstance().getAuth().getUser().equals(auth.getUser());
        }

        // Anyone else coming through with an existing authentication can be assumed safe?
        return false;
    }

    /**
     * Delegates to {@link Realm#authenticate(org.acegisecurity.Authentication)}
     */
    public Authentication attemptAuthentication(HttpServletRequest request) {
        return getAuthenticationManager().authenticate(SecurityContextHolder.getContext().getAuthentication());
    }

}
