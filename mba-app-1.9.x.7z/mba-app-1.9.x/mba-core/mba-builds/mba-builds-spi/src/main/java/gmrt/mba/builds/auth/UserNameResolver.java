package gmrt.mba.builds.auth;

import gmrt.da.auth.UserNotFoundException;
import hudson.Extension;
import hudson.model.User;
import org.apache.log4j.Logger;

/**
 * Resolves (on-demand) the user using {@link Realm#resolveUser(hudson.model.User)}
 *
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 16, 2010
 */
@Extension
public class UserNameResolver extends hudson.tasks.UserNameResolver {

    private static Logger LOG = Logger.getLogger(UserNameResolver.class.getName());

    @Override
    public String findNameFor(User u) {
        try {
            Realm.resolveUser(u);
        } catch (UserNotFoundException e) {
            LOG.error("Attempted to find name for user not found: " + u.getId(), e);
            return null;
        }
        LOG.info("Resolved name address for " + u.getId() + " to " + u.getFullName());
        return u.getId();
    }

}
