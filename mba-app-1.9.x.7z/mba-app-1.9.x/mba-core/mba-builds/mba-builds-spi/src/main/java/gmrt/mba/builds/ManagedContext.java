package gmrt.mba.builds;

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/2/11
 */
public interface ManagedContext extends gmrt.da.ManagedContext {}
