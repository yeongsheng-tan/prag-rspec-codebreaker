package gmrt.mba.builds.auth;

import gmrt.da.auth.Auth;
import gmrt.da.auth.User;
import gmrt.da.auth.UserNotFoundException;
import gmrt.mba.Appliance;
import hudson.Extension;
import hudson.model.Descriptor;
import hudson.security.ACL;
import hudson.security.ChainedServletFilter;
import hudson.security.SecurityRealm;
import hudson.tasks.Mailer;
import org.acegisecurity.Authentication;
import org.acegisecurity.AuthenticationException;
import org.acegisecurity.AuthenticationManager;
import org.acegisecurity.GrantedAuthority;
import org.acegisecurity.context.HttpSessionContextIntegrationFilter;
import org.acegisecurity.providers.AbstractAuthenticationToken;
import org.acegisecurity.userdetails.UserDetails;
import org.acegisecurity.userdetails.UserDetailsService;
import org.acegisecurity.userdetails.UsernameNotFoundException;
import org.acegisecurity.wrapper.SecurityContextHolderAwareRequestFilter;
import org.kohsuke.stapler.DataBoundConstructor;
import org.springframework.dao.DataAccessException;

import javax.servlet.ServletException;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Implements an SSO capable security realm for Hudson using Atlassian Crowd. Much inspired by
 * <a href="http://wiki.hudson-ci.org/display/HUDSON/Crowd+Plugin">Hudson Crowd Plugin</a> and hoping to contribute
 * something back to that project for SSO at some point.
 *
 * @author jason.stiefel@bankofamerica.com
 */
public class Realm extends hudson.security.SecurityRealm
        implements AuthenticationManager, GrantedAuthority, UserDetailsService {

    private static Logger LOG = Logger.getLogger(Realm.class.getName());

    @Extension
    public static class DescriptorImpl extends Descriptor<SecurityRealm> {

        public DescriptorImpl() {
            super(Realm.class);
        }

        @Override
        public String getDisplayName() {
            return "Managed Build Authentication Realm";
        }

    }

    @DataBoundConstructor
    public Realm() {}

    @Override
    public synchronized SecurityComponents createSecurityComponents() {
        return new SecurityComponents(this, this);
    }

    /**
     * Creates a filter chain of {@link org.acegisecurity.context.HttpSessionContextIntegrationFilter} then
     * {@link SecurityContextHolderAwareRequestFilter} and finally our {@link Filter}. We intentionally don't support
     * BASIC authentication because we don't want users to authenticate against the appliance directly.
     */
    public javax.servlet.Filter createFilter(javax.servlet.FilterConfig filterConfig) {
        HttpSessionContextIntegrationFilter sessionFilter = null;
        try {
            sessionFilter = new HttpSessionContextIntegrationFilter();
        } catch (ServletException e) {
            throw new IllegalStateException("Failed creating the session filter ...", e);
        }
        Filter filter = new Filter();
        filter.setAuthenticationManager(this);
        return new ChainedServletFilter(sessionFilter, filter);
    }

    /**
     * Returns <code>null</code>, should never be used.
     */
    @Override
    public String getLoginUrl() {
        return null;
    }

    /**
     * Always returns <code>false</code>.
     */
    @Override
    public boolean allowsSignup() {
        return false;
    }

    /**
     * Always returns <code>false</code>.
     */
    @Override
    public boolean canLogOut() {
        return false;
    }

    public Authentication authenticate(Authentication _authentication) throws AuthenticationException {

        if (ACL.SYSTEM == _authentication) {
            LOG.info("Authenticating ACL.SYSTEM user: " + _authentication);
            _authentication.setAuthenticated(true);
            return _authentication;
        }

        User user = Appliance.getInstance().getAuth().getUser();
        ManagedBuildAuth authentication = new ManagedBuildAuth(new GrantedAuthority[] {this},
                user.getUserId(), String.valueOf(user.getCredentials()));
        authentication.setAuthenticated(true);
        authentication.setUser(user);

        return authentication;
    }

    /**
     * Returns the name of this authority.
     * @return {@link #getClass()}.getName()
     */
    public String getAuthority() {
        return "ManagedBuildAuth";
    }

    /**
     * Loads the user from the {@link Auth}
     */
    @Override
    public UserDetails loadUserByUsername(final String username) throws UsernameNotFoundException, DataAccessException {

        return new UserDetails() {
            public GrantedAuthority[] getAuthorities() {
                return new GrantedAuthority[] {Realm.this};
            }

            public String getPassword() {
                return UUID.randomUUID().toString();
            }

            public String getUsername() {
                return username;
            }

            public boolean isAccountNonExpired() {
                return true;
            }

            public boolean isAccountNonLocked() {
                return true;
            }

            public boolean isCredentialsNonExpired() {
                return true;
            }

            public boolean isEnabled() {
                return true;
            }
        };

    }

    /**
     * Resolves a user with information from the SSO server. Does explicitly call {@link hudson.model.User#save()}.
     */
    public static void resolveUser(hudson.model.User user) throws UserNotFoundException {

        LOG.info("Resolving user for " + user.getId());

        try {
            Auth auth = Appliance.getInstance().getAuth();
            User appUser = auth.getUser(user.getId());
            user.addProperty(new Mailer.UserProperty(appUser.getEmail()));
            user.setFullName(appUser.getDisplayName());
            user.save();
            LOG.info("Resolved and saved user " + user.getDisplayName());

        } catch (Throwable t) {
            LOG.log(Level.SEVERE, "Exception occured resolving user: " + user.getId(), t);
            throw new UserNotFoundException(user.getId());
        }

    }

    /**
     * Intially the Principal should be the users remote addr. Credentials are the Crowd token.
     */
    public static class ManagedBuildAuth extends AbstractAuthenticationToken implements Authentication {

        private String principal;
        private String credentials;
        private User user;

        public ManagedBuildAuth(GrantedAuthority[] authorities, String principal, String credentials) {
            super(authorities);
            this.principal = principal;
            this.credentials = credentials;
        }

        public String getCredentials() {
            return credentials;
        }

        public String getPrincipal() {
            if (user != null)
                return user.getUserId();
            return principal;
        }

        public User getUser() {
            return user;
        }

        public void setUser(User user) {
            this.user = user;
        }
    }


}
