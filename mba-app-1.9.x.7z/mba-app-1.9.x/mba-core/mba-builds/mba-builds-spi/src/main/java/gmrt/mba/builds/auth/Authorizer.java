package gmrt.mba.builds.auth;

import gmrt.mba.auth.MbaRole;
import hudson.Extension;
import hudson.model.Descriptor;
import hudson.model.Hudson;
import hudson.model.Job;
import hudson.security.ACL;
import hudson.security.Permission;
import org.acegisecurity.Authentication;
import org.apache.log4j.Logger;
import org.kohsuke.stapler.DataBoundConstructor;

import java.util.Collection;
import java.util.Collections;

/**
 * {@link hudson.security.AuthorizationStrategy} for {@link MbaRole}s.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 12/21/10
 */
public class Authorizer extends hudson.security.AuthorizationStrategy {

    private static final Logger LOG = Logger.getLogger(Authorizer.class);
    private static final SSOAcl acl = new SSOAcl();

    @Extension
    public static class DescriptorImpl extends Descriptor<hudson.security.AuthorizationStrategy> {
        @Override
        public String getDisplayName() {
            return "Managed Build Authorization Strategy";
        }
    }

    @DataBoundConstructor
    public Authorizer() {}

    @Override
    public ACL getRootACL() {
        return acl;
    }

    @Override
    public Collection<String> getGroups() {
        return Collections.emptyList();
    }

    /**
     * Implements the mapping from {@link MbaRole} to Hudson {@link Permission}s
     */
    private static final class SSOAcl extends ACL {

        @Override
        public boolean hasPermission(Authentication a, Permission permission) {

            if (LOG.isDebugEnabled())
                LOG.debug("Permission coming through, authorization=" + a + ", permission=" + permission);

            // Internal Hudson "system".
            if (ACL.SYSTEM == a) {
                if (LOG.isDebugEnabled())
                    LOG.debug("Allowing ACL.SYSTEM user for auth " + a + " and perm " + permission);
                return true;
            }

            if (a instanceof Realm.ManagedBuildAuth) {
                MbaRole role = (MbaRole)((Realm.ManagedBuildAuth)a).getUser().getRole();

                // Everyone gets read-only.
                if (Hudson.READ.equals(permission) || Job.READ.equals(permission))
                    return true;

                switch (role) {
                    case SYSTEM:
                        return true;
                    case ADMINISTRATOR:
                        return true;
                    case DEVELOPER:
                        return !Hudson.ADMINISTER.equals(permission);
                    case WORKER:
                        return !Hudson.ADMINISTER.equals(permission);
                }

            }

            return false;
        }
    }
}
