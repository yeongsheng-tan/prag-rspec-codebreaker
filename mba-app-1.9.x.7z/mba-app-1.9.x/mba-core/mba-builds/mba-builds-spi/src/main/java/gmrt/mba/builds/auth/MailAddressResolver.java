package gmrt.mba.builds.auth;

import gmrt.da.auth.UserNotFoundException;
import hudson.Extension;
import hudson.model.User;
import hudson.tasks.Mailer;
import org.apache.log4j.Logger;

/**
 * Resolves the email address for a user (on-demand) using
 * {@link Realm#resolveUser(hudson.model.User)}
 *
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 16, 2010
 */
@Extension
public class MailAddressResolver extends hudson.tasks.MailAddressResolver {

    private static Logger LOG = Logger.getLogger(MailAddressResolver.class.getName());

    @Override
    public String findMailAddressFor(User u) {
        try {
            Realm.resolveUser(u);
        } catch (UserNotFoundException e) {
            LOG.error("Attempted to find mail address for user not found: " + u.getId(), e);
            return null;
        }
        Mailer.UserProperty email = u.getProperty(Mailer.UserProperty.class);
        LOG.info("Resolved mail address for " + u.getId() + " to " + email.getAddress());
        return email.getAddress();
    }
}
