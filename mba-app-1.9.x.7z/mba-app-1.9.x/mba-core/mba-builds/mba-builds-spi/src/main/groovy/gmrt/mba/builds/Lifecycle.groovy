package gmrt.mba.builds

import hudson.lifecycle.RestartNotSupportedException

/**
 * @see hudson.lifecycle.Lifecycle
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 1/26/11
 */
class Lifecycle extends hudson.lifecycle.Lifecycle {

  /**
   * @throws RestartNotSupportedException
   */
  @Override
  void verifyRestartable() {
    throw new RestartNotSupportedException('[MBA] Restart your appliance using the standard interface');
  }

  /**
   * @return false
   */
  @Override
  boolean canRewriteHudsonWar() {
    false;
  }



}
