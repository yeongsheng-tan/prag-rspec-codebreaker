/*
 * Copyright 2010 NHN Corp. All rights Reserved.
 * NHN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package gmrt.mba.core.builds.updatecenter;

import net.sf.json.JSONObject;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * UpdateSite representation including {@link Plugin}
 * 
 * @author yeongsheng.tan@baml.com
 * @since 10/25/11
 */
public class UpdateSite {
	public final int updateCenterVersion = 1;
	public List<Plugin> plugins = new ArrayList<Plugin>();
	public final String id = "mba-update-site";
	private transient JSONObject uc;

	/**
	 * Init {@link UpdateSite} class with the .hpi files. This method should be
	 * called after {@link UpdateSite} object is created, to construct update
	 * info.
	 * 
	 * @param updateCenterBasePath
	 *            the file path in which the "plugins" folder exist
	 * @param urlBasePath
	 *            base URL for downloading hpi files.
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	public void init(File updateCenterBasePath, String urlBasePath) throws IOException, Exception {
		String downloadBaseUrl = urlBasePath + "/plugins";

		//Repository repo = new Repository("mba-group",new URL(System.getenv().get("MBA_ARTIFACTS_GROUP")),repoDir);
		//MavenRepository repo = createRepository();
		//uc = buildUpdateCenterJson(repo,updateCenterBasePath,downloadBaseUrl);

		for (File hpiFile : (Collection<File>) FileUtils.listFiles(new File(updateCenterBasePath, "plugins"), new String[]{"hpi"}, false)) {
			try {
				Plugin plugin = new Plugin();
				plugin.init(hpiFile, downloadBaseUrl);
				this.plugins.add(plugin);
			} catch (IOException e) {
				System.out.printf("Fail to get the %s info\n", hpiFile.getName());
			}
		}
	}

	/**
	 * Convert {@link UpdateSite} to JSON format
	 * 
	 * @return converted {@link JSONObject}
	 **/
	public JSONObject toJSON() throws IOException{
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("updateCenterVersion", this.updateCenterVersion);
		jsonObject.put("id", this.id);
		JSONObject pluginsJSON = new JSONObject();
		for (Plugin plugin : this.plugins) {
			pluginsJSON.element(plugin.getName(), plugin.toJSON());
		}
		jsonObject.put("plugins", pluginsJSON);
		return jsonObject;
		//return uc;
	}

/*	protected MavenRepository createRepository() throws Exception {
        MavenRepository repo = DefaultMavenRepositoryBuilder.createStandardInstance(null);
        return repo;
    }*/

	/**
	 * Convert {@link UpdateSite} to JSON String including JSONP callback
	 * function.
	 * 
	 * @return conveted JSON String
	 **/
	public String toUpdateCenterJSONString() throws IOException {
		return "updateCenter.post(\n" + toJSON().toString(4) + "\n);";
	}

/*    private JSONObject buildUpdateCenterJson(MavenRepository repo, File resolvedPluginsBaseFolder, String resolvedPluginsBaseUrl) throws Exception {
        JSONObject root = new JSONObject();
        root.put("updateCenterVersion","1");    // we'll bump the version when we make incompatible changes
*//*        JSONObject core = buildCore(repo);
        if (core!=null)
            root.put("core", core);*//*
        root.put("plugins", buildPlugins(repo,resolvedPluginsBaseFolder));
        root.put("id",id);
        root.put("connectionCheckUrl",resolvedPluginsBaseUrl);

        return root;
    }

    *//**
     * Build JSON for the plugin list.
     * @param repository
     *//*
    protected JSONObject buildPlugins(MavenRepository repository, File resolvedPluginsDir) throws Exception {
        ConfluencePluginList cpl = new ConfluencePluginList();

        JSONObject plugins = new JSONObject();
        for( PluginHistory hpi : repository.listHudsonPlugins() ) {
            try {
                System.out.println(hpi.artifactId);

                //Plugin plugin = new Plugin(hpi,cpl);
                Plugin plugin = new Plugin();
                if (plugin.isDeprecated()) {
                    System.out.println("=> Plugin is deprecated.. skipping.");
                    continue;
                }

                System.out.println(
                  plugin.page!=null ? "=> "+plugin.page.getTitle() : "** No wiki page found");
                JSONObject json = plugin.toJSON();
                System.out.println("=> " + json);
                plugins.put(plugin.artifactId, json);
                String permalink = String.format("/latest/%s.hpi", plugin.artifactId);
                //redirect.printf("Redirect 302 %s %s\n", permalink, plugin.latest.getURL().getPath());

                for (HPI v : hpi.artifacts.values()) {
                    stage(v, new File(resolvedPluginsDir, "plugins/" + hpi.artifactId + "/" + v.version + "/" + hpi.artifactId + ".hpi"));
                }

                if (!hpi.artifacts.isEmpty())
                    createLatestSymlink(hpi, plugin.latest, resolvedPluginsDir);
            } catch (IOException e) {
                e.printStackTrace();
                // move on to the next plugin
            }
        }

        return plugins;
    }

    *//**
     * Generates symlink to the latest version.
     *//*
    protected void createLatestSymlink(PluginHistory hpi, HPI latest, File resolvedPluginsDir) throws InterruptedException, IOException {
        File dir = new File(resolvedPluginsDir, "plugins/" + hpi.artifactId);
        new File(dir,"latest").delete();

        ProcessBuilder pb = new ProcessBuilder();
        pb.command("ln","-s", latest.version, "latest");
        pb.directory(dir);
        int r = pb.start().waitFor();
        if (r !=0)
            throw new IOException("ln failed: "+r);
    }

    *//**
     * Stages an artifact into the specified location.
     *//*
    protected void stage(MavenArtifact a, File dst) throws IOException, InterruptedException {
        File src = a.resolve();
        if (dst.exists() && dst.lastModified()==src.lastModified() && dst.length()==src.length())
            return;   // already up to date

//        dst.getParentFile().mkdirs();
//        FileUtils.copyFile(src,dst);

        // TODO: directory and the war file should have the release timestamp
        dst.getParentFile().mkdirs();

        ProcessBuilder pb = new ProcessBuilder();
        pb.command("ln","-f", src.getAbsolutePath(), dst.getAbsolutePath());
        if (pb.start().waitFor()!=0)
            throw new IOException("ln failed");

    }*/
}
