package gmrt.mba

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 9/6/11
 */
class Sys {
  public static final String MBA_BASE = 'mba.base'
  public static final String MBA_WORK = 'mba.work'
  public static final String MBA_HOME = 'mba.home'
  public static final String MBA_CONFIG = 'mba.config'
  public static final String MBA_LOG_CONFIG = 'mba.log.config'
  public static final String MBA_HTTP_PORT = 'mba.http.port'
  public static final String MBA_SERV_PORT = 'mba.serv.port'
}
