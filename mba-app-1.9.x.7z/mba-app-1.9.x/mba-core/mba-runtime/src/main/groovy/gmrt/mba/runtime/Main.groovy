package gmrt.mba.runtime

import groovy.text.SimpleTemplateEngine
import java.util.logging.Logger

/**
 * Main execution method for an MBA. This class will use the {@link gmrt.mba.Appliance#getInstance} to bootstrap an
 * {@link gmrt.mba.Appliance} instance for the environment specified via the arguments to the {@link Main#main} method.
 * The {@link Main#main} method dispatches to {@link Main#handle} where the {@link CLI} is instantiated and assuming
 * the arguments passed in are good will instantiate a <code>Main</code> and call {@link Main#go} with the {@link CLI}.
 *
 * @see Main#handle
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/1/11
 */
class Main {

  private static final Logger LOG = Logger.getLogger(Main.class.getName());

  public static final String RUNTIME_PROPS_PATH = 'META-INF/maven/gmrt.mba.core/mba-runtime/pom.properties'
  public static final String RUNTIME_META_INF = 'META-INF/gmrt.mba.core/mba-runtime'

  public static final boolean IS_UNIX = File.pathSeparatorChar != ';';

  def final String version;
  def final String groupId;
  def final String artifactId;

  private boolean addedToClasspath;
  private AntBuilder ant = new AntBuilder();
  private SimpleTemplateEngine templateEngine = new SimpleTemplateEngine();

  /**
   * Dispatches to {@link #handle} and calls {@link System#exit} with the value returned from {@link #handle}.
   */
  public static void main(String[] args) {
    System.exit(handle(args));
  }

  /**
   * Implements dispatching to the {@link Main#go} method. Returns the {@link System#exit} result code without actually
   * exiting the VM.
   * <p/>
   * <strong>Return codes:</strong>
   * <li><strong>-1</strong> Indicates an error was encountered
   * <li><strong>0</strong> All is well
   * <li><strong>1</strong> Restart required
   */
  public static int handle(String[] args) {

    try {

      CLI cli = new CLI();
      if (!cli.parseArguments(args)) {
        return -1;
      }

      def pomPropsStream = Main.class.classLoader.getResourceAsStream(RUNTIME_PROPS_PATH)
      if (!pomPropsStream)
        throw new FileNotFoundException(RUNTIME_PROPS_PATH)

      Properties pomProps = new Properties()
      pomProps.load(pomPropsStream)
      Main main = new Main(pomProps['groupId'], pomProps['artifactId'], pomProps['version']);
      if (main.go(cli))
        return 1;

      return 0;

    } catch (Throwable t) {
      t.printStackTrace(System.err)
      LOG.severe("Exception occured handling arguments '${args}'");
      return -1;
    }


  }

  Main(String groupId, String artifactId, String version) {

    this.version = version
    this.groupId = groupId
    this.artifactId = artifactId

  }

  /**
   * Handles the command line args and returns <code>true</code> when we should go around again (i.e. in the case of
   * a restart.)
   *
   * @return restart Indicates a restart should be performed.
   */
  boolean go(CLI cli) {

    switch (cli.action) {
      case CLI.INSTALL:
        return doInstall(cli);
      case CLI.START:
        return doStart(cli);
      case CLI.STATUS:
        return doStatus(cli);
      case CLI.STOP:
        return doStop(cli);
      case CLI.UPGRADE:
        return doUpgrade(cli);
    }

    return false;

  }

  boolean doInstall(CLI cli) {

    LOG.info("Installing into ${cli.base.path}");

    if (!cli.base.exists())
      cli.base.mkdirs()

    def mbaBin = new File(cli.base, "/bin");
    mbaBin.mkdirs();

    // Prevent overwrite of the files in home...
    if (cli.home.exists()) {
      ant.touch {
        fileset(dir: cli.home) {
          include(name: '*.*')
        }
      }
    }

    ant.unzip(src: cli.source, dest: cli.base, overwrite: false) {
      patternset {
        include(name: "${RUNTIME_META_INF}/**")
      }
      mapper(type: 'glob', from: "${RUNTIME_META_INF}/*", to: '*')
    }
    ant.fixcrlf(srcDir: cli.base) {
      patternset {
        include(name: "bin/*.sh")
        include(name: "bin/*.bat")
        include(name: "home/*.sh")
        include(name: "home/*.bat")
        include(name: "home/mba.properties")
        include(name: "home/log4j.xml")
      }
    }
    ant.chmod(perm: "ugo+rx") {
      fileset(dir: cli.base) {
        include(name: "bin/*.sh")
      }
    }

    def binding = [escapedDol: '$', escapedPct: '%', mbaJar: cli.source.name, mbaVer: "${groupId}:${version}"];
    mbaBin.eachFile {
      if (it.directory)
        return;
      if (!it.text.contains('${escapedPct}') && !it.text.contains('${escapedDol}'))
        return;
      try {
        LOG.info("Rendering ${it.name} ...")
        templateEngine.createTemplate(it).make(binding).writeTo(it.newWriter())
      } catch (Throwable t) {
        throw new IllegalStateException("An exception occured processing the template: ${it.name}", t);
      };
    }

    LOG.info('');
    LOG.info("Installation is complete, start the instance using the .${File.separator}bin${File.separator}mba.${(IS_UNIX) ? 'sh' : 'bat'} script");
    LOG.info('');

    false
  }

  boolean doUpgrade(CLI cli) {

    LOG.info("Uninstalling from ${cli.base.path} ...")

    File mbaBin = new File(cli.base, '/bin/');
    if (mbaBin.exists()) {
      ant.delete(dir: mbaBin)
    }

    if (cli.work.exists()) {
      ant.delete(includeEmptyDirs: true) {
        fileset(dir: cli.work) {
          exclude(name: 'local/')
        }
      }
    }

    doInstall(cli);

    false

  }

  boolean doStatus(CLI cli) {

    def app = getAppliance(cli);
    try {

      def container = app.getBean(Class.forName('gmrt.mba.Container'), Class.forName('gmrt.mba.Container'));
      def hostResolver = app.getBean(app.getClass(), Class.forName('gmrt.mba.HostResolver'));

      LOG.info("config: ${cli.config.path}");
      LOG.info("http: ${hostResolver.port}");
      LOG.info("serv: ${hostResolver.serv}")
      LOG.info("running: ${container.isRunning()}");
      LOG.info("freeMem: ${Runtime.runtime.freeMemory()}")

    } finally {
      app?.close();
    }

    false;

  }

  boolean doStop(CLI cli) {

    def app = getAppliance(cli);

    def daemon = Thread.startDaemon {
      try {

        def container = app.getBean(Class.forName('gmrt.mba.Container'), Class.forName('gmrt.mba.Container'));
        def hostResolver = app.getBean(app.getClass(), Class.forName('gmrt.mba.HostResolver'));

        if (!container.isRunning())
          throw new IllegalStateException("No running instance was found using servPort ${hostResolver.serv} ...");
        container.serv(1)

      } finally {
        app?.close();
      }
    }

    if (!cli.daemon) {
      daemon.join();
    }

    false;
  }

  boolean doStart(CLI cli) {

    if (!cli.work.exists() || !cli.home.exists() || cli.force) {
      doInstall(cli);
    }

    File userHome = new File(System.properties['user.home']);
    if (!userHome.exists()) {
      LOG.info("Creating master home directory at ${userHome.absolutePath}")
      userHome.mkdirs();
    }

    def app = getAppliance(cli);
    def container = app.getBean(Class.forName('gmrt.mba.Container'), Class.forName('gmrt.mba.Container'));
    def hostResolver = app.getBean(app.getClass(), Class.forName('gmrt.mba.HostResolver'));

    def daemon = Thread.startDaemon {

      try {
        if (container.isRunning())
          throw new IllegalStateException("An instance seems to be running already, using servPort ${hostResolver.serv} ...");

        updateApps(cli);
        updatePlugins(cli);

        container.start();

      } finally {
        app?.close();
      }

    }

    if (!cli.daemon) {
      daemon.join()
      return container.pendingRestart
    }

    // Now let's try and if it's all started..
    while (daemon.isAlive() && !container.isStarted()) {
      LOG.info("Sleeping while we wait for the container to report all apps started ...");
      Thread.sleep(5000);
    }

    false;
  }

  /**
   * Updates the unpacked applications in ${mba.work}/apps with anything newer found in ${mba.work}/lib/apps.
   */
  protected def updateApps(CLI cli) {

    LOG.info("Checking for app updates ...")

    def mbaBin = new File(cli.base, "/bin");
    def appSrc = new File(mbaBin, "/apps/");
    def appDir = new File(cli.work, '/apps/');
    appDir.mkdirs()

    appSrc.eachFile { packed ->

      def target = new File(appDir, packed.name.substring(0, packed.name.lastIndexOf('.')));
      if (target.exists()) {
        def ts = new File(target, 'unpacked.ts')
        if (ts.exists()) {
          long unpacked = Long.valueOf(ts.text);
          if (packed.lastModified() <= unpacked) {
            LOG.info("No update required for ${target.name} ...");
            return;
          }
          LOG.info("Wiping out ${target} to be replaced with ${packed.name} ...");
          ant.delete(dir: target);

        }
      }

      LOG.info("Unpacking app ${packed.name} ...");
      ant.unwar(src: packed, dest: target, failOnEmptyArchive: true)
      new File(target, 'unpacked.ts').write(String.valueOf(System.currentTimeMillis()));

    }

  }

  /**
   * Updates the plugins in ${mba.home}/APP/PLUGIN_DIR with anything newer found in ${mba.work}/lib/plugins.
   */
  protected def updatePlugins(CLI cli) {

    LOG.info("Checking for plugin updates ...");

    def mbaBin = new File(cli.base, "/bin");
    File pluginDir = new File(mbaBin, "/plugins/");
    pluginDir.mkdirs();   // We might not have a bin/plugins if we're running just the runtime...

    File buildsPlugins = new File(cli.home, 'builds/plugins/').with {
      if (!exists())
        mkdirs();
      it;
    }
    File artifactsPlugins = new File(cli.work, 'artifacts/plugin-repository/').with {
      if (!exists())
        mkdirs();
      it;
    }

    pluginDir.eachFile { File plugin ->

      File targetDir;

      switch (plugin.name.substring(plugin.name.lastIndexOf('.') + 1)) {
        case 'hpl':
          targetDir = buildsPlugins;
          break;
        case 'hpi':
          targetDir = buildsPlugins;
          break;
        case 'zip':
          targetDir = artifactsPlugins;
          break;
        default:
          throw new IllegalStateException("Unrecognized file in ${pluginDir.name}: ${plugin.name}");
      }

      def target = new File(targetDir, plugin.name);
      if (target.exists() && (target.lastModified() >= plugin.lastModified())) {
        LOG.info("No update required for ${target.name} ...");
        return;
      }

      LOG.info("Updating ${target.name} ...");
      ant.copy(file: plugin, tofile: target);

      // We need to unzip nexus plugins
      if (target.name.endsWith('.zip')) {
        ant.unzip(src: target, dest: target.parentFile, overwrite: true)
      }

    }

  }

  private synchronized Object getAppliance(CLI cli) {

    if (!addedToClasspath) {
      def libs = [];
      def mbaBin = new File(cli.base, "/bin/");
      mbaBin.mkdirs();
      def mbaLib = new File(mbaBin, "/lib/");
      mbaLib.mkdirs();
      mbaLib.eachFileMatch(~/.*\.jar/) { this.class.classLoader.addURL(it.toURL()) }
      addedToClasspath = true;
    }

    Class appClazz = Class.forName('gmrt.mba.Appliance');
    return appClazz.getMethod('getInstance').invoke(null);
  }
}
