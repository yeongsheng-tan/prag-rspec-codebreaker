package gmrt.mba.runtime

import org.kohsuke.args4j.Option
import org.kohsuke.args4j.CmdLineParser

import org.kohsuke.args4j.Argument
import org.kohsuke.args4j.CmdLineException
import org.apache.commons.lang.StringUtils
import gmrt.mba.Sys

/**
 * Command line interface for the MBA. Handles the defaults for most system property attributes and makes it simple
 * to override those attributes on the command line. Will set the corresponding system properties
 * (i.e. {@link gmrt.mba.Sys#MBA_BASE}, etc..).
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 7/26/11
 */
class CLI {

  public static final String INSTALL = 'install';
  public static final String START = 'start';
  public static final String STATUS = 'status';
  public static final String STOP = 'stop';
  public static final String UPGRADE = 'upgrade'

  /**
   * Simple enum type map that matches the options for the {@link #action} argument.
   */
  def static final Map<String, String> ACTION = ['install': INSTALL, 'start': START, 'status': STATUS, 'stop': STOP, 'upgrade': UPGRADE]

  @Option(name = '-base', metaVar = 'path', usage = 'Defaults to the directory where mba.jar is located')
  def File base = System.getProperty(Sys.MBA_BASE) ? new File(System.getProperty(Sys.MBA_BASE)) : null;

  @Option(name = '-work', metaVar = 'path', usage = 'Work directory, defaults to ${base}/work')
  def File work = System.getProperty(Sys.MBA_WORK) ? new File(System.getProperty(Sys.MBA_WORK)) : null;

  @Option(name = '-home', metaVar = 'path', usage = 'Defaults to ${base}/home')
  def File home = System.getProperty(Sys.MBA_HOME) ? new File(System.getProperty(Sys.MBA_HOME)) : null;

  @Option(name = '-config', metaVar = 'path', usage = 'Defaults to ${home}/mba.properties')
  def File config = System.getProperty(Sys.MBA_CONFIG) ? new File(System.getProperty(Sys.MBA_CONFIG)) : null;

  @Option(name = '-logConfig', metaVar = 'path', usage = 'Defaults to ${home}/log4j.xml, applies when -start indicated')
  def File logConfig = System.getProperty(Sys.MBA_LOG_CONFIG) ? new File(System.getProperty(Sys.MBA_LOG_CONFIG)) : null;

  @Option(name = '-http', metaVar = 'port', usage = 'Defaults to value in mba.properties')
  def Integer http = System.getProperty(Sys.MBA_HTTP_PORT) ? Integer.valueOf(System.getProperty(Sys.MBA_HTTP_PORT)) : null;

  @Option(name = '-serv', metaVar = 'port', usage = 'Defaults to value in mba.properties')
  def Integer serv = System.getProperty(Sys.MBA_SERV_PORT) ? Integer.valueOf(System.getProperty(Sys.MBA_SERV_PORT)) : null;

  @Option(name = '-force', usage = 'Varies by action, on start will install when not installed')
  def boolean force;

  @Option(name = '-daemon', usage = 'Allows the main method to return after running the action without waiting for an outcome. Only applies to start/stop')
  def boolean daemon;

  @Argument(metaVar = 'action', usage = 'One of "install", "start", "status" or "stop"')
  def String action;

  def File source;

  private CmdLineParser cmdLineParser;

  CLI() {
    this.cmdLineParser = new CmdLineParser(this);
    this.source = new File(CLI.class.protectionDomain.codeSource.location.path)
  }

  boolean parseArguments(String... args) {

    try {

      cmdLineParser.parseArgument(args);

      if (!action || !ACTION[action]) {
        printUsage();
        return false;
      }

      base = base ?: source.parentFile
      if (!base?.exists()) {
        System.err.println("***ERROR: Base ${base.path} does not exist");
        printUsage()
        return false;
      }

      home = home ?: new File(base, '/home/');
      if (!home?.exists() && action != INSTALL && !force) {
        System.err.println("***ERROR: No home directory found at ${home.path}, perhaps you should run 'install'? ...");
        printUsage();
        return false;
      }

      config = config ?: new File(home, 'mba.properties')
      if (!config?.exists() && action != INSTALL && !force) {
        System.err.println("***ERROR: No configuration file found at ${config.path}, perhaps you should run 'install'? ...");
        printUsage();
        return false;
      }

      logConfig = logConfig ?: new File(home, 'log4j.xml')
      if (action == START && !logConfig.exists() && !force) {
        System.err.println("***ERROR: No logging configuration file found at ${logConfig.path}, perhaps you should run 'install'? ...");
        printUsage();
        return false;
      }

      work = work ?: new File(base, '/work/');

      def props = [:];
      props[Sys.MBA_BASE] = base.path;
      props[Sys.MBA_WORK] = work.path;
      props[Sys.MBA_HOME] = home.path;
      props[Sys.MBA_CONFIG] = config.toURI().toString();

      if (action == START)  // We only setup logging when we're starting, otherwise it all goes to console.
        props[Sys.MBA_LOG_CONFIG] = logConfig.toURI().toString();

      // These can definitely be null
      if (http) props[Sys.MBA_HTTP_PORT] = http.toString();
      if (serv) props[Sys.MBA_SERV_PORT] = serv.toString();

      def art = CLI.class.package.specificationTitle ?: "unknown"
      def ver = CLI.class.package.specificationVersion ?: "SDK"
      println("*******************************************")
      println("** Code/Builds version ${art}:${ver}")
      println("** Brought to you by the GMRT Developer Architecture Team and the Code/ Platform (dg.code@bankofamerica.com)")
      println("** http://code.bankofamerica.com/")
      println("**")
      props.each {
        println("** ${StringUtils.leftPad(it.key, 15)}: ${it.value}")
        System.properties[it.key] = it.value
      }
      println("**")
      println("*******************************************")

    } catch (CmdLineException cle) {
      System.err.println("***ERROR: Could not parse command line: ${cle.message}");
      printUsage();
      return false;

    } catch (Throwable t) {
      t.printStackTrace()
      System.err.println("A fatal exception has occured parsing the command line arguments.");
      return false;
    }

    true;
  }

  void printUsage() {
    def File jar = new File(CLI.class.protectionDomain.codeSource.location.path);
    System.err.print("Usage: java [JVM_OPTIONS] -jar ${jar.name}")
    cmdLineParser.printSingleLineUsage(System.err)
    System.err.println()
    cmdLineParser.printUsage(System.err);
  }

}
