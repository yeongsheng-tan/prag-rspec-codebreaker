package gmrt.mba.runtime

import org.testng.annotations.Test

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 9/12/11
 */
class MavenMbaPluginIT {

  @Test(timeOut = 30000L, description = 'A "fake" test to make sure we can run/stop the MBA using the maven-mba-plugin mostly.')
  void verifyMbaStarted() {

    println("Requesting root page of appliance ...");
    println()
    println("http://localhost:8019".toURL().text);
    println()
    println("Requesting root of artifacts ...");
    println()
    println("http://localhost:8019/artifacts/".toURL().text);
    println()
    println("Requesting root of builds ...");
    println()
    println("http://localhost:8019/builds/".toURL().text);
    println()

  }

}
