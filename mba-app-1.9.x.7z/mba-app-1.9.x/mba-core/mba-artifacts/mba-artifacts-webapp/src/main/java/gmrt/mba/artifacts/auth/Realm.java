package gmrt.mba.artifacts.auth;

import gmrt.da.auth.User;
import gmrt.mba.Appliance;
import gmrt.mba.auth.MbaRole;
import org.apache.log4j.Logger;
import org.codehaus.plexus.component.annotations.Component;
import org.codehaus.plexus.component.annotations.Requirement;
import org.jsecurity.authc.*;
import org.jsecurity.authc.pam.UnsupportedTokenException;
import org.jsecurity.authz.AuthorizationInfo;
import org.jsecurity.realm.AuthorizingRealm;
import org.jsecurity.subject.PrincipalCollection;
import org.sonatype.plexus.rest.resource.PlexusResource;
import org.sonatype.security.usermanagement.UserNotFoundException;

/**
 * Authorizing realm that will pick up a {@link UsernamePasswordToken} with the expectation that the users remote
 * address has been set into the username and their SSO token stored as the password. (We're currently relying on
 * the NexusSSOAuthenticationFilter class that is part of the nexus-webapp module overlay to setup the authentication
 * token for us.) <b>This class is responsible for entitling users based on their {@link MbaRole}.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 15, 2010
 */
@Component(role = org.jsecurity.realm.Realm.class, hint = Realm.HINT)
public class Realm extends AuthorizingRealm implements org.jsecurity.realm.Realm {

    private static Logger LOG = Logger.getLogger(Realm.class);

    public static final String HINT = "ManagedBuildRealm";

    @Requirement(role = PlexusResource.class, hint = AuthSetup.HINT)
    private AuthSetup authSetup;

    @Requirement(role = org.sonatype.security.usermanagement.UserManager.class, hint = UserManager.HINT)
    private UserManager userManager;

    @Override
    public String getName() {
        return HINT;
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken)
            throws AuthenticationException {

        if (!(authenticationToken instanceof UsernamePasswordToken))
            throw new UnsupportedTokenException("Token of type "
                    + authenticationToken.getClass().getName() + " is not " + "supported.  A "
                    + UsernamePasswordToken.class.getName() + " is required.");

        UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;
        User appUser = Appliance.getInstance().getAuth().getUser();

        // Let's update the token so it will "fix" the authentication event logging.
        token.setUsername(appUser.getUserId());

        UserManager.NexusUser nexusUser = null;
        try {
            nexusUser = userManager.getUser(appUser.getUserId());
        } catch (UserNotFoundException e) {
            throw new IllegalStateException("Could not locate UserManager.NexusUser for NexusUser " +
                    appUser + ", this should never happen");
        }

        return new SimpleAuthenticationInfo(nexusUser.getUserId(), String.valueOf(token.getPassword()), getName());
    }

    @Override
    public boolean isPermitted(PrincipalCollection principals, String permission) {
        return super.isPermitted(principals, permission);
    }

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        User appUser = Appliance.getInstance().getAuth().getUser();
        return authSetup.authorizations((MbaRole) appUser.getRole());
    }

}
