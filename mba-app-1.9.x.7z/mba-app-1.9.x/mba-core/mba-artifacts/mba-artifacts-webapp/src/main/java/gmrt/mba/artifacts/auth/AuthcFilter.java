package gmrt.mba.artifacts.auth;

import gmrt.da.auth.Auth;
import gmrt.da.auth.SendChallengeException;
import gmrt.da.auth.User;
import gmrt.mba.Appliance;
import gmrt.mba.auth.MbaRole;
import gmrt.mba.auth.WorkerRealm;
import org.apache.log4j.Logger;
import org.apache.oro.text.regex.*;
import org.jsecurity.authc.AuthenticationToken;
import org.jsecurity.authc.UsernamePasswordToken;
import org.jsecurity.subject.Subject;
import org.sonatype.nexus.security.filter.NexusJSecurityFilter;
import org.sonatype.nexus.security.filter.authc.NexusHttpAuthenticationFilter;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.List;

/**
 * A fun little pass-through filter that attempts to determine whether you're doing a PUT (i.e. Secure Deploy) or
 * you're just a regular 'ole user from {@link Auth#getUser()}
 *
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 16, 2010
 */
public class AuthcFilter extends NexusHttpAuthenticationFilter {
    private static Logger LOG = Logger.getLogger(AuthcFilter.class);
	private static final String IS_APPLIANCE_ANONYMOUS = AuthcFilter.class.getName() + "-is_app_anon";

    private static final List<MbaRole> SUPER_ROLES = Arrays.asList(MbaRole.WORKER, MbaRole.SYSTEM, MbaRole.ADMINISTRATOR);
	//private static final List<String> SUPER_PATHS = Arrays.asList(new String[] {"/content/repositories/mba-backup","/service/local/repositories/mba-backup"});
	private static final String SUPER_PATHS_REGEX = "\\/{1}(content\\/repositories\\/mba\\-backup|service\\/local\\/repositories\\/mba\\-backup)/{1}.*\\.zip$";
	private final PatternCompiler compiler = new Perl5Compiler();
	private final PatternMatcher matcher = new Perl5Matcher();
	private Pattern pattern = null;

	public AuthcFilter() throws MalformedPatternException{
		pattern = compiler.compile(SUPER_PATHS_REGEX,Perl5Compiler.CASE_INSENSITIVE_MASK);
	}

    /**
     * We're overloading prehandle to deal with _ALL_ authentication right here, right now.
     */
    @Override
    public boolean onPreHandle(ServletRequest request, ServletResponse response, Object mappedValue) throws Exception {

        Subject subject = getSubject( request, response );
        if (subject.isAuthenticated()) {
            if(!checkForSuperAccess(request, response)){
	            return false;
            }else{
                return super.onPreHandle(request, response, mappedValue);
            }
        }

        executeLogin(request, response);
        if(!checkForSuperAccess(request, response)){
	        return false;
        }else{
            return super.onPreHandle(request, response, mappedValue);
        }
    }

    /**
     * Hard protection for the mba-back*.zip archive in paths {@link #SUPER_PATHS_REGEX} for all request methods
     * except PUT, restricting them to {@link #SUPER_ROLES}.
     *
     * @return requestCanContinue
     */
    protected boolean checkForSuperAccess(ServletRequest _request, ServletResponse _response) throws Exception {

        HttpServletRequest request = (HttpServletRequest)_request;
        HttpServletResponse response = (HttpServletResponse)_response;

	    if(pattern==null)
		    return false;

	    if (matcher.matches(request.getPathInfo(),pattern) && "GET".equalsIgnoreCase(request.getMethod())) {
            User user = Appliance.getInstance().getAuth().getUser();
		    LOG.info("ATTEMPT made to " + request.getMethod() + " for resource --> " + request.getPathInfo() + " --> with userId= " + user.getUserId() + " | user role= " + user.getRole());
		    if (!SUPER_ROLES.contains(user.getRole())) {
                LOG.debug("Not authorized for resource: " + request.getPathInfo());
	            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Not authorized for resource: " + request.getPathInfo());
                response.flushBuffer();
                return false;
            }
		}
/*        for (String superPath : SUPER_PATHS) {
	        //if (request.getPathInfo().startsWith(superPath)) {
	        if(request.getPathInfo().indexOf(superPath) > -1){
                User user = Appliance.getInstance().getAuth().getUser();
		        LOG.info("request.getMethod() = " + request.getMethod() + " | request.getPathInfo() = " + request.getPathInfo() + " --> user.getUserId() = " + user.getUserId() + " | user.getRole() = " + user.getRole());
		        if (!SUPER_ROLES.contains(user.getRole())) {
                    LOG.debug("Not authorized for resource: " + request.getPathInfo());
	                response.sendError(HttpServletResponse.SC_FORBIDDEN, "Not authorized for resource: " + request.getPathInfo());
                    response.flushBuffer();
                    return false;
                }
            }
        }*/
        return true;
    }

    /**
     * Overrides the default behavior to set a {@link SendChallengeException} into the request attributes to be picked
     * up by the {@link gmrt.da.auth.Filter}.
     *
     * @throws gmrt.da.auth.SendChallengeException
     */
    @Override
    public void postHandle(ServletRequest request, ServletResponse response) throws Exception {
        if (request.getAttribute(NexusJSecurityFilter.REQUEST_IS_AUTHZ_REJECTED) != null)
            request.setAttribute(SendChallengeException.class.getName(), new SendChallengeException(WorkerRealm.MBA_WORKER_REALM));
    }

    @Override
    protected AuthenticationToken createToken(ServletRequest request, ServletResponse response) {

        Auth auth = Appliance.getInstance().getAuth();
        User user = auth.getUser();
        if (auth.getAnonymous().equals(user))
            request.setAttribute(IS_APPLIANCE_ANONYMOUS, true);

        return new UsernamePasswordToken(user.getUserId(), (user.getCredentials().toString()).toCharArray());
    }

    /**
     * We don't record events for anonymous logins.
     */
    @Override
    protected boolean onLoginSuccess(AuthenticationToken token, Subject subject,
                                     ServletRequest request, ServletResponse response) {

        if (request.getAttribute(IS_APPLIANCE_ANONYMOUS) == null)
            return super.onLoginSuccess(token, subject, request, response);

        return true;
    }


}
