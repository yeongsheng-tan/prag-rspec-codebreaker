package gmrt.mba.artifacts;

import gmrt.mba.Appliance;
import gmrt.mba.Config;
import org.apache.log4j.Logger;
import org.codehaus.plexus.component.annotations.Component;
import org.codehaus.plexus.component.annotations.Requirement;
import org.codehaus.plexus.personality.plexus.lifecycle.phase.Initializable;
import org.codehaus.plexus.personality.plexus.lifecycle.phase.InitializationException;
import org.sonatype.configuration.ConfigurationException;
import org.sonatype.nexus.Nexus;
import org.sonatype.nexus.configuration.model.CLocalStorage;
import org.sonatype.nexus.configuration.model.CRepository;
import org.sonatype.nexus.plugins.RepositoryCustomizer;
import org.sonatype.nexus.proxy.StorageException;
import org.sonatype.nexus.proxy.maven.*;
import org.sonatype.nexus.proxy.registry.RepositoryRegistry;
import org.sonatype.nexus.proxy.repository.ProxyMode;
import org.sonatype.nexus.proxy.repository.RepositoryWritePolicy;
import org.sonatype.nexus.templates.NoSuchTemplateIdException;
import org.sonatype.nexus.templates.TemplateProvider;
import org.sonatype.nexus.templates.repository.DefaultRepositoryTemplateProvider;
import org.sonatype.nexus.templates.repository.maven.AbstractMavenRepositoryTemplate;
import org.sonatype.plexus.rest.resource.AbstractPlexusResource;
import org.sonatype.plexus.rest.resource.PathProtectionDescriptor;
import org.sonatype.plexus.rest.resource.PlexusResource;

import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * Creates or reconfigures the "managed" repositories from {@link ManagedRepository}
 *
 * @author jason.stiefel@bankofamerica.com
 * @see ManagedRepository
 * @since 1/11/11
 */
@Component(role = PlexusResource.class, hint = ManagedRepoSetup.HINT)
public class ManagedRepoSetup extends AbstractPlexusResource implements PlexusResource, Initializable {

    private static Logger LOG = Logger.getLogger(ManagedRepoSetup.class);

    public static final String HINT = "ManagedRepoSetup";
    public static final String RESOURCE_URI = "/repos/status.xml";

    @Requirement
    private RepositoryRegistry repositoryRegistry;

    @Requirement
    private Nexus nexus;

    @Requirement(role = TemplateProvider.class, hint = DefaultRepositoryTemplateProvider.PROVIDER_ID)
    private DefaultRepositoryTemplateProvider repoTemplateProvider;

    @Requirement(role = RepositoryCustomizer.class, hint = RepoStorageCustomizer.HINT)
    private RepoStorageCustomizer repoStorageCustomizer;

    private boolean remoteIndexesEnabled = false;

    public void initialize() throws InitializationException {

        LOG.info("Initializing Managed Build Appliance repositories within Nexus ...");

        Config config = Appliance.getInstance().getConfig();
        if (config.getArtifacts().isRemoteIndexesEnabled()) {
            LOG.info("** Enabling remote index downloads ...");
            remoteIndexesEnabled = true;
        } else {
            LOG.info("*** Remote index downloads are disabled ...");
        }


        try {
            boolean created = false;

            for (ManagedRepository.Type mrType :
                    Arrays.asList(ManagedRepository.Type.PROXY, ManagedRepository.Type.HOSTED, ManagedRepository.Type.GROUP)) {
                for (ManagedRepository managedRepository : ManagedRepository.values(mrType)) {
                    if (repositoryRegistry.repositoryIdExists(managedRepository.id))
                        continue;
                    createManagedRepo(managedRepository);
                    created = true;
                }
            }

            if (created)
                nexus.getNexusConfiguration().saveConfiguration();

        } catch (Exception e) {
            throw new InitializationException("Fatal exception occured configured managed repositories ...", e);
        }


    }

    private void createManagedRepo(ManagedRepository managedRepository)
            throws NoSuchTemplateIdException, ConfigurationException, IOException {

        AbstractMavenRepositoryTemplate template;
        switch (managedRepository.type) {
            case PROXY:
                template = (AbstractMavenRepositoryTemplate) repoTemplateProvider.getTemplateById(
                        (ManagedRepository.Policy.SNAPSHOT.equals(managedRepository.policy) ?
                                "default_proxy_snapshot" : "default_proxy_release")
                );
                break;
            case HOSTED:
                template = (AbstractMavenRepositoryTemplate) repoTemplateProvider.getTemplateById(
                        (ManagedRepository.Policy.SNAPSHOT.equals(managedRepository.policy) ?
                                "default_hosted_snapshot" : "default_hosted_release")
                );
                break;
            case GROUP:
                template = (AbstractMavenRepositoryTemplate) repoTemplateProvider.getTemplateById("default_group");
                break;
            default:
                throw new UnsupportedOperationException("Unknown managed repo type: " + managedRepository.type);

        }

        CRepository configuration = template.getCoreConfiguration().getConfiguration(true);
        configuration.setId(managedRepository.id);
        configuration.setName(managedRepository.name);
        configuration.setUserManaged(true);
        configuration.setLocalStorage(new CLocalStorage());
        configuration.getLocalStorage().setProvider("file");
        configuration.getLocalStorage().setUrl(repoStorageCustomizer.getLocalStorageUrl(managedRepository.id));
        configuration.setBrowseable(true);
        configuration.setSearchable(true);
        configuration.setExposed(true);

        MavenRepository repository = template.create();
        switch (managedRepository.type) {
            case PROXY:
                configureProxyRepo(managedRepository, (MavenProxyRepository)repository);
                break;
            case HOSTED:
                configureHostedRepo(managedRepository, (MavenHostedRepository)repository);
                break;
            case GROUP:
                configureGroupRepo(managedRepository, (MavenGroupRepository)repository);
                break;
            default:
                throw new UnsupportedOperationException("Unknown managed repo type: " + managedRepository.type);
        }

    }

    private void configureProxyRepo(ManagedRepository managedRepository, MavenProxyRepository m2)
            throws StorageException {

        configureArtifactsRepo(managedRepository, (AbstractMavenRepository)m2);

        m2.setRemoteUrl(managedRepository.url);
        m2.setDownloadRemoteIndexes(remoteIndexesEnabled);
        m2.setFileTypeValidation(true);
        m2.setCleanseRepositoryMetadata(false);
        m2.setArtifactMaxAge(-1);
        m2.setItemMaxAge(1440);
        m2.setRepositoryPolicy(RepositoryPolicy.valueOf(managedRepository.policy.name()));

    }

    private void configureHostedRepo(ManagedRepository managedRepository, MavenHostedRepository m2) {

        configureArtifactsRepo(managedRepository, (AbstractMavenRepository)m2);

        m2.setNotFoundCacheActive(false);
        m2.setIndexable(true);
        m2.setExposed(true);
        m2.setWritePolicy(ManagedRepository.Policy.RELEASE.equals(managedRepository.policy) ?
                RepositoryWritePolicy.ALLOW_WRITE_ONCE :
                RepositoryWritePolicy.ALLOW_WRITE);
    }

    /**
     * Configures the common attributes of both Proxy and Hosted repositories.
     */
    private void configureArtifactsRepo(ManagedRepository managedRepository, AbstractMavenRepository m2) {

        m2.setProxyMode(ProxyMode.ALLOW);
        m2.setArtifactMaxAge(1440);
        m2.setItemMaxAge(1440);
        m2.setMetadataMaxAge(1440);
        m2.setCleanseRepositoryMetadata(false);
        m2.setChecksumPolicy(ChecksumPolicy.WARN);

        if (ManagedRepository.Policy.RELEASE.equals(managedRepository.policy)) {
            m2.setRepositoryPolicy(RepositoryPolicy.RELEASE);
        } else if (ManagedRepository.Policy.SNAPSHOT.equals(managedRepository.policy)) {
            m2.setRepositoryPolicy(RepositoryPolicy.SNAPSHOT);
        } else {
            m2.setRepositoryPolicy(RepositoryPolicy.MIXED);
        }
    }

    private void configureGroupRepo(ManagedRepository managedRepository, MavenGroupRepository m2) {
        List<String> children = new LinkedList<String>();
        for (ManagedRepository child : managedRepository.children)
            children.add(child.id);
        if (m2.getMemberRepositoryIds() != null) {
            for (String existingMember : m2.getMemberRepositoryIds()) {
                if (!children.contains(existingMember))
                    children.add(existingMember);
            }
        }
        m2.setMergeMetadata(true);
        try {
            m2.setMemberRepositoryIds(children);
        } catch (Exception e) {
            LOG.error("Exception occured setting group members for managed repository " + managedRepository.id, e);
            return;
        }

        m2.setWritePolicy(RepositoryWritePolicy.READ_ONLY);
        m2.setSearchable(false);
    }


    @Override
    public String getResourceUri() {
        return RESOURCE_URI;
    }

    @Override
    public PathProtectionDescriptor getResourceProtection() {
        return new PathProtectionDescriptor(this.getResourceUri(), "anon");
    }

    @Override
    public Object getPayloadInstance() {
        return null;
    }

}
