package gmrt.mba.artifacts.auth;

import gmrt.da.auth.User;
import gmrt.mba.Appliance;
import org.codehaus.plexus.component.annotations.Component;
import org.codehaus.plexus.component.annotations.Requirement;
import org.sonatype.configuration.validation.InvalidConfigurationException;
import org.sonatype.plexus.rest.resource.PlexusResource;
import org.sonatype.security.usermanagement.*;

import java.util.*;

/**
 * Delegates up to {@link gmrt.da.auth.Auth} while mapping {@link User}s to
 * {@link gmrt.mba.artifacts.auth.UserManager.NexusUser}s.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 12/19/10
 */
@Component( role = org.sonatype.security.usermanagement.UserManager.class, hint = UserManager.HINT, description = UserManager.HINT)
public class UserManager extends AbstractReadOnlyUserManager implements RoleMappingUserManager {

    public static final String HINT = "ManagedBuildUsers";

    @Requirement(role = PlexusResource.class, hint = AuthSetup.HINT)
    private AuthSetup authSetup;

    public Set<RoleIdentifier> getUsersRoles(String userId, String userSource) throws UserNotFoundException {
        org.sonatype.security.usermanagement.User user = getUser(userId);
        return user.getRoles();
    }

    public void setUsersRoles(String userId, String userSource, Set<RoleIdentifier> roleIdentifiers)
            throws UserNotFoundException, InvalidConfigurationException {
        if (!getSource().equals(userSource))
            return;
        throw new UnsupportedOperationException("UserManager " + getSource() + " does not support writes");
    }

    public String getSource() {
        return HINT;
    }

    public String getAuthenticationRealmName() {
        return Realm.HINT;
    }

    public Set<org.sonatype.security.usermanagement.User> listUsers() {
        Set<org.sonatype.security.usermanagement.User> userList = new HashSet<org.sonatype.security.usermanagement.User>();
        for (User appUser : Appliance.getInstance().getAuth().getUsers()) {
            userList.add(getNexusUser(appUser));
        }
        return userList;
    }

    public Set<String> listUserIds() {
        Set<String> users = new HashSet<String>();
        for (User appUser : Appliance.getInstance().getAuth().getUsers()) {
            users.add(appUser.getUserId());
        }
        return users;
    }

    public Set<org.sonatype.security.usermanagement.User> searchUsers(UserSearchCriteria criteria) {
        return filterListInMemeory(listUsers(), criteria);
    }

    public NexusUser getUser(String userId) throws UserNotFoundException {
        User user = null;
        try {
            user = Appliance.getInstance().getAuth().getUser(userId);
        } catch (gmrt.da.auth.UserNotFoundException e) {
            throw new UserNotFoundException(userId);
        }
        return getNexusUser(user);
    }

    protected NexusUser getNexusUser(User applianceUser) {
        NexusUser nexusUser = new NexusUser();
        nexusUser.setUserId(applianceUser.getUserId());
        nexusUser.setName(applianceUser.getDisplayName());
        nexusUser.setEmailAddress(applianceUser.getEmail());
        nexusUser.setSource(UserManager.HINT);
        nexusUser.setReadOnly(false);
        nexusUser.setStatus(UserStatus.active);
        return nexusUser;
    }

    public static class NexusUser extends DefaultUser {
        private Date created = new Date();

        public NexusUser() {
            super();
        }
    }

}
