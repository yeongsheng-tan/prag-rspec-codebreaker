package gmrt.mba.artifacts.auth;

import org.apache.log4j.Logger;
import org.codehaus.plexus.component.annotations.Component;
import org.sonatype.security.email.SecurityEmailer;

import java.util.List;

/**
 * Overrides the default security emails by disabling them altogether. We don't want the users to know what their
 * "local" passwords are, they should only ever login via ssologon for now.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 16, 2010
 */
@Component( role = SecurityEmailer.class )
public class Emailer implements SecurityEmailer {

    private static Logger LOG = Logger.getLogger(Emailer.class.getName());

    public void sendNewUserCreated(String email, String userid, String password) {
        log();
    }

    public void sendResetPassword(String email, String password) {
        log();
    }

    public void sendForgotUsername(String email, List<String> userIds) {
        log();
    }

    private void log() {
        LOG.info("User security email is disabled while Managed Build Auth plugin is installed");
    }

}
