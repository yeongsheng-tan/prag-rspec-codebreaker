package gmrt.mba.artifacts;

import gmrt.mba.Appliance;
import gmrt.mba.Notifications;
import org.codehaus.plexus.component.annotations.Component;
import org.codehaus.plexus.component.annotations.Requirement;
import org.codehaus.plexus.personality.plexus.lifecycle.phase.Initializable;
import org.codehaus.plexus.personality.plexus.lifecycle.phase.InitializationException;
import org.sonatype.configuration.ConfigurationException;
import org.sonatype.micromailer.Address;
import org.sonatype.nexus.email.NexusEmailer;
import org.sonatype.plexus.rest.resource.AbstractPlexusResource;
import org.sonatype.plexus.rest.resource.PathProtectionDescriptor;
import org.sonatype.plexus.rest.resource.PlexusResource;

/**
 * Configures the {@link NexusEmailer} with the <i>mba.notifications...</i> configuration.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 1/21/11
 */
@Component(role = PlexusResource.class, hint = NotificationsSetup.HINT)
public class NotificationsSetup extends AbstractPlexusResource implements PlexusResource, Initializable {

    public static final String HINT = "ApplianceNotifications";
    public static final String RESOURCE_URI = "/notifications/status.xml";

    @Requirement(role = NexusEmailer.class)
    private NexusEmailer nexusEmailer;

    public void initialize() throws InitializationException {

// See CODE-676
//        Notifications config = Appliance.getInstance().getConfig().getNotifications();
//
//        nexusEmailer.setSMTPHostname(config.getSmtpHost());
//        nexusEmailer.setSMTPSystemEmailAddress(new Address(config.getReplyTo()));
//        nexusEmailer.setSMTPUsername(config.getSmtpUser());
//        nexusEmailer.setSMTPPassword(config.getSmtpPass());
//
//        try {
//            nexusEmailer.commitChanges();
//        } catch (ConfigurationException e) {
//            throw new InitializationException("Exception occured configuring notifications", e);
//        }

    }

    @Override
    public String getResourceUri() {
        return RESOURCE_URI;
    }

    @Override
    public PathProtectionDescriptor getResourceProtection() {
        return new PathProtectionDescriptor(this.getResourceUri(), "anon");
    }

    @Override
    public Object getPayloadInstance() {
        return null;
    }

}
