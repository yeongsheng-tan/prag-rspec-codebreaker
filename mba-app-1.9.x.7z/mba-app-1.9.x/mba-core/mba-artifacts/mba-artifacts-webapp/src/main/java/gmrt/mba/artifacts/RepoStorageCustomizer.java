package gmrt.mba.artifacts;

import gmrt.mba.Appliance;
import gmrt.mba.Artifacts;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.plexus.component.annotations.Component;
import org.codehaus.plexus.component.annotations.Requirement;
import org.sonatype.configuration.ConfigurationException;
import org.sonatype.nexus.configuration.application.NexusConfiguration;
import org.sonatype.nexus.plugins.RepositoryCustomizer;
import org.sonatype.nexus.proxy.StorageException;
import org.sonatype.nexus.proxy.repository.Repository;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * "Fixes" the local storage URL on repositories.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 1/24/11
 */
@Component( role = RepositoryCustomizer.class, hint = RepoStorageCustomizer.HINT )
public class RepoStorageCustomizer implements RepositoryCustomizer {

    private static final Logger LOG = Logger.getLogger(RepoStorageCustomizer.class);

    public static final String HINT = "RepoStorageCustomizer";

    @Requirement
    private NexusConfiguration nexusConfiguration;

    public boolean isHandledRepository(Repository repository) {
        return true;
    }

    public void configureRepository(Repository repository) throws ConfigurationException {

        try {
            if (checkAndFixLocalStorage(repository)) {
                LOG.info("Fixed storage path for repository " + repository.getId() + " ...");
                //nexusConfiguration.saveConfiguration();
            }
        } catch (IOException e) {
            LOG.error("Exception occured updating repository storage path for repo " + repository.getId(), e);
        }

    }

    protected boolean checkAndFixLocalStorage(Repository repo) throws StorageException {

        String localUrl = getLocalStorageUrl(repo.getId());
        String repoUrl;
        try {
            repoUrl = (!StringUtils.isBlank(repo.getLocalUrl()) ? new File(new URI(repo.getLocalUrl())).toURI().toString() : "");
        } catch (URISyntaxException e) {
            throw new StorageException("Invalid URI for local storage: " + repo.getLocalUrl());
        }

        if (!StringUtils.isBlank(repoUrl) && repoUrl.startsWith(localUrl)) {
            if (LOG.isDebugEnabled())
                LOG.debug("Repository (" + repo.getId() + ") already has correct path: " + repoUrl);
            return false;
        }

        LOG.info("Setting " + repo.getId() + " storage to path: " + localUrl);
        repo.setLocalUrl(localUrl);
        return true;
    }

    protected String getLocalStorageUrl(String repoId) {
        Artifacts config = Appliance.getInstance().getConfig().getArtifacts();
        return new File(config.getRepos(), repoId).toURI().toString();
    }

}
