package gmrt.mba.artifacts.auth;

import gmrt.mba.auth.MbaRole;
import org.apache.log4j.Logger;
import org.codehaus.plexus.component.annotations.Component;
import org.codehaus.plexus.component.annotations.Requirement;
import org.codehaus.plexus.personality.plexus.lifecycle.phase.Initializable;
import org.codehaus.plexus.personality.plexus.lifecycle.phase.InitializationException;
import org.jsecurity.authz.SimpleAuthorizationInfo;
import org.sonatype.configuration.validation.InvalidConfigurationException;
import org.sonatype.plexus.rest.resource.AbstractPlexusResource;
import org.sonatype.plexus.rest.resource.PathProtectionDescriptor;
import org.sonatype.plexus.rest.resource.PlexusResource;
import org.sonatype.security.SecuritySystem;
import org.sonatype.security.authorization.xml.RoleResolver;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Installs the {@link Realm} and caches the entitlements from {@link Authorizer} for each {@link MbaRole}.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 12/19/10
 */
@Component(role = PlexusResource.class, hint = AuthSetup.HINT)
public class AuthSetup extends AbstractPlexusResource implements PlexusResource, Initializable {

    private static final Logger LOG = Logger.getLogger(AuthSetup.class);
    private static final String RESOURCE_URI = "/auth/status.xml";

    public static final String HINT = "ManagedBuildAuthPlugin";

    @Requirement(role = SecuritySystem.class)
    private SecuritySystem securitySystem;

    @Requirement(role = RoleResolver.class)
    private RoleResolver roleResolver;

    private Map<MbaRole, SimpleAuthorizationInfo> authorizations = new HashMap<MbaRole, SimpleAuthorizationInfo>();

    /**
     * Bootstraps the application context and makes sure we can talk to the SSO server before enabling SSO.
     *
     * @throws InitializationException
     */
    public void initialize() throws InitializationException {

        LOG.info("Initializing MBA auth ...");

        Authorizer authorizer = new Authorizer(roleResolver);
        for (MbaRole role : MbaRole.values())
            authorizations.put(role, authorizer.authorize(role));

        try {
            securitySystem.setAnonymousAccessEnabled(false);
            securitySystem.setRealms(Arrays.asList(Realm.HINT));
        } catch (InvalidConfigurationException e) {
            throw new InitializationException("Could not add the Auth realm to the security system ...", e);
        }

    }

    /**
     * Returns a cached list of permissions for the specified {@link MbaRole}.
     */
    public SimpleAuthorizationInfo authorizations(MbaRole mbaRole) {
        return authorizations.get(mbaRole);
    }

    @Override
    public String getResourceUri() {
        return RESOURCE_URI;
    }

    @Override
    public PathProtectionDescriptor getResourceProtection() {
        return new PathProtectionDescriptor(this.getResourceUri(), "anon");
    }

    @Override
    public Object getPayloadInstance() {
        return null;
    }

}
