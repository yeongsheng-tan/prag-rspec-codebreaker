package gmrt.mba.artifacts.auth

import gmrt.mba.auth.MbaRole
import org.jsecurity.authz.SimpleAuthorizationInfo
import org.sonatype.security.authorization.xml.RoleResolver

/**
 * Maps an {@link MbaRole} to a list of Nexus string permissions. This is in effect the ACL for Nexus.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 1/25/11
 */
class Authorizer {

  private RoleResolver resolver;

  Authorizer(RoleResolver resolver) {
    this.resolver = resolver
  }

  public SimpleAuthorizationInfo authorize(MbaRole mbaRole) {

    SimpleAuthorizationInfo sai = new SimpleAuthorizationInfo();

    switch (mbaRole) {
      case MbaRole.SYSTEM:
        sai.addRole('admin');
        break;
      case MbaRole.ADMINISTRATOR:
        addAdministrator(sai);
        addDeveloper(sai);
        addAnonymous(sai);
        break;
      case MbaRole.DEVELOPER:
        addDeveloper(sai);
        addAnonymous(sai);
        break;
      case MbaRole.WORKER:
        addWorker(sai);
        addAnonymous(sai);
        break;
      default:
        addAnonymous(sai);
    }

    Set<String> permissions = resolver.resolvePermissions(sai.getRoles())
    Set<String> merged = new HashSet<String>(permissions);
    merged.addAll(sai.getStringPermissions() ?: []);
    sai.setStringPermissions(merged);

    return sai;
  }

  private void addAdministrator(SimpleAuthorizationInfo sai) {

    sai.addRole('ui-repository-admin');
    sai.addRole('ui-routing-admin');
    sai.addRole('ui-group-admin');
    sai.addRole('ui-scheduled-tasks-admin');
    sai.addRole('ui-repository-targets-admin');

    sai.addStringPermission('nexus:tasksrun')
    sai.addStringPermission('nexus:repogroups:create,update,delete');
    sai.addStringPermission('nexus:target:any:*:create,update,delete');

  }

  private void addDeveloper(SimpleAuthorizationInfo sai) {

    sai.addStringPermission('nexus:artifact:create,read');
    sai.addStringPermission('nexus:metadata:delete,read');
    sai.addStringPermission('nexus:cache:delete,read');
    sai.addStringPermission('nexus:index:delete,read');
    sai.addStringPermission('nexus:repostatus:update');
    sai.addStringPermission('nexus:repometa:read');

    sai.addStringPermission('nexus:target:any:mba-snapshots:delete,read');
    sai.addStringPermission('nexus:target:any:mba-thirdparty:create,read');
    sai.addStringPermission('nexus:attributes:any:*:create,update,delete');
  }

  private void addWorker(SimpleAuthorizationInfo sai) {

    sai.addStringPermission('nexus:target:any:mba-snapshots:create,read');
    sai.addStringPermission('nexus:target:any:mba-snapshots:update,read');
    sai.addStringPermission('nexus:target:any:mba-releases:create,read');
    sai.addStringPermission('nexus:target:any:mba-releases:update,read');
	/*MBS-352 - CRUD access permissions for worker to mba-backup artifacts repo*/
	sai.addStringPermission('nexus:target:any:mba-backup:create,read');
    sai.addStringPermission('nexus:target:any:mba-backup:update,read');
  }

  private void addAnonymous(SimpleAuthorizationInfo sai) {

    sai.addRole('anonymous');
    sai.addRole('ui-system-feeds');
    sai.addRole('repo-all-read');

  }
}
