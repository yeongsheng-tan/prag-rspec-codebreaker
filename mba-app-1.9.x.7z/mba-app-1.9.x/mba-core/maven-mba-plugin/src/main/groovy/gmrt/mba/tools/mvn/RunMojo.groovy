package gmrt.mba.tools.mvn

import org.apache.maven.plugin.MojoExecutionException

/**
 * Executes the appliance out of the {@link AbstractMbaMojo#mbaBase} path.
 *
 * @goal run
 * @requiresDependencyResolution runtime
 * @description Executes the MBA runtime with the plugins found in the current project dependency scope. I.e. if you
 * run this from the mba-artifacts-plugin module the {@link AssembleMojo} will pull in the mba-builds-plugin and any
 * other plugins that mba-artifacts-plugin depends on.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 12/27/10
 */
public class RunMojo extends AssembleMojo {

  /**
   * Location for permanent artifact storage when running using the Mojo (this prevents you from constantly re-caching
   * artifacts when you're doing continuous integration or testing.)
   *
   * @parameter expression="${java.io.tmpdir}/mba/repos"
   */
  protected File artifactRepos;

  /**
   * Toggles whether the MBA will block the thread once started. Default (daemon = false) will block the mojo thread
   * allowing you to interact with the instance. Setting to true will return from the mojo once the container is
   * started and you'll need to shut it down using the stop mojo.
   *
   * @parameter expression="false"
   */
  protected boolean daemon;

  void doExecute() {

    super.doExecute();

    if (daemon)
      invokeMbaAction('start','-force','-daemon');
    else
      invokeMbaAction('start','-force');

  }

  protected void loadConfigOverrides() {

    super.loadConfigOverrides();

    if (artifactRepos) {
      artifactRepos.mkdirs();
      System.setProperty('mba.artifacts.repos', artifactRepos.path);
    }

  }

}
