package gmrt.mba.tools.mvn

/**
 * Executes the appliance out of the {@link AbstractMbaMojo#mbaBase} path.
 *
 * @goal stop
 * @description Stops a running MBA
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 12/27/10
 */
public class StopMojo extends AbstractMbaMojo {

  void doExecute() {
    invokeMbaAction('stop','-force');
  }

}
