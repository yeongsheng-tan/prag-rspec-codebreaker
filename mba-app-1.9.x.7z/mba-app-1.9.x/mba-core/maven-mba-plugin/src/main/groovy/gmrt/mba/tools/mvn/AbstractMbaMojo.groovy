package gmrt.mba.tools.mvn

import org.codehaus.groovy.maven.mojo.GroovyMojo
import org.apache.maven.artifact.resolver.ArtifactResolver
import org.apache.maven.artifact.metadata.ArtifactMetadataSource
import org.apache.maven.artifact.repository.ArtifactRepository
import org.apache.maven.artifact.factory.ArtifactFactory
import org.apache.maven.project.MavenProject
import org.apache.maven.plugin.MojoExecutionException

import org.apache.maven.artifact.Artifact
import org.apache.commons.io.FileUtils
import org.apache.tools.ant.taskdefs.Expand
import org.apache.tools.ant.Project
import org.apache.tools.ant.BuildException
import org.apache.tools.ant.util.FileNameMapper
import org.apache.maven.project.MavenProjectBuilder
import org.apache.maven.artifact.resolver.ArtifactNotFoundException
import org.apache.maven.plugin.MojoFailureException

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 12/29/10
 */
abstract class AbstractMbaMojo extends GroovyMojo {

  /**
   * The maven project.
   *
   * @parameter expression="${project}"
   * @required
   * @readonly
   */
  protected MavenProject project;

  /**
   * @component
   */
  protected MavenProjectBuilder projectBuilder;

  /**
   * @component
   */
  protected ArtifactFactory factory;

  /**
   * Local repository
   *
   * @parameter expression="${localRepository}"
   * @required
   * @readonly
   */
  protected ArtifactRepository local;

  /**
   * @component
   */
  protected ArtifactMetadataSource source;

  /**
   * @component
   */
  protected ArtifactResolver resolver;

  /**
   * Optional mba.properties overrides, will default to ${mbaBase}/home/mba.properties
   *
   * @parameter expression="${project.build.directory}/mba-runtime/home/mba.properties"
   */
  protected File mbaConfig;

  /**
   * Base directory that will be used for runtime directory structure. It can also be set to a packaged artifact.
   *
   * @parameter expression="${project.build.directory}/mba-runtime"
   */
  protected File mbaBase;

  /**
   * Home directory, defaults to being inside the base.
   *
   * @parameter expression="${project.build.directory}/mba-runtime/home"
   */
  protected File mbaHome;

  /**
   * The mba-runtime artifact
   */
  protected Artifact runtimeArtifact;

  /**
   * Flat list of transitive artifacts required by the current module. Only compile or provided scope artifacts will be
   * resolved transitively while runtime or provided scoped will be resolved as a singularly.
   */
  protected List<Artifact> artifactsInScope = [];

  final void execute() {

    discoverArtifactsInScope()
    resolveRuntimeArtifact();
    resolveBuildArtifact();

    doExecute();

  }

  abstract void doExecute()

  /**
   * Loads the core artifact and its dependencies into a new {@link ClassLoader} then calls the main method on the
   * Appliance. The actual strategy used to locate the appliance-core and its dependencies depends on whether
   * <strong>mba.base</strong> has been set.
   *
   * <p/>
   * <strong>Note:</strong> wipes out ALL existing mba.* system properties before executing the "handle" method on the
   * Main runtime class.
   */
  protected def invokeMbaAction(String... args) {

    loadConfigOverrides();

    log.info("*******************************************************************************************************");
    log.info("** Executing gmrt.mba.Main with overrides: ");
    System.properties.findAll { it.key.startsWith('mba.') }.sort {l,r -> l.key <=> r.key}.each {
      log.info("** ${it.key}: ${it.value}");
    }
    log.info("*******************************************************************************************************")

    def runtimeJar = (mbaBase.file) ? mbaBase : new File(mbaBase, "mba.jar")
    if (!runtimeJar.exists())
      throw new MojoExecutionException("No runtime was found at ${runtimeJar.path} ...");

    def libs = [runtimeJar.toURL()];

    def classLoader = new URLClassLoader(libs as URL[], ClassLoader.getSystemClassLoader().getParent())
    def mainClazz = classLoader.loadClass("gmrt.mba.runtime.Main")

    ClassLoader ccl = Thread.currentThread().getContextClassLoader();
    try {
      Thread.currentThread().setContextClassLoader(classLoader);
      mainClazz.'handle'(args);

    } finally {
      Thread.currentThread().setContextClassLoader(ccl);
    }

  }

  protected void loadConfigOverrides() {

    new HashMap(System.properties).each {
      if (it.key.startsWith('mba.'))
        System.properties.remove(it.key);
    }

    if (!mbaBase.file)
      System.setProperty('mba.base', mbaBase.path);
    if (mbaConfig && mbaConfig.exists())
      System.setProperty('mba.config', mbaConfig.path);

  }

  protected void discoverArtifactsInScope() {

    if (['war', 'hpi', 'nexus-plugin'].contains(project.packaging)) {
      artifactsInScope << project.artifact;
    }

    resolver.resolveTransitively(
            project.dependencyArtifacts.findAll { it.scope == 'compile' || it.scope == 'provided' } as Set,
            project.artifact, project.remoteArtifactRepositories, local, source).artifactResolutionNodes.each {
      artifactsInScope << it.artifact
    }
    project.dependencyArtifacts.findAll { it.scope == 'runtime' }.each { Artifact toResolve ->
      resolver.resolve(toResolve, project.remoteArtifactRepositories, local);
      artifactsInScope << toResolve;
    }

  }

  protected void resolveRuntimeArtifact() {
    runtimeArtifact = findModuleArtifact('gmrt.mba.core', 'mba-runtime', 'jar');
    if (!runtimeArtifact)
      throw new MojoFailureException("No gmrt.mba.core:mba-runtime artifact found in dependencies");
  }

  /**
   * Looks in the runtimeArtifacts for an artifact with the specified groupId/artifactId and type.
   */
  protected Artifact findModuleArtifact(String groupId, String artifactId, String type) {
    if (project.artifact.groupId == groupId && project.artifact.artifactId == artifactId && project.artifact.type == type)
      return project.artifact;
    def artifact = artifactsInScope.find { it.groupId == groupId && it.artifactId == artifactId && it.type == type}
    if (artifact) {
      log.info("Resolved module for ${groupId}:${artifactId} with ${artifact.file}")
      return artifact;
    }
    null;
  }

  /**
   * Makes an "educated guess" on the location of the current module build artifact. Will resolve against the repository
   * if the output directory doesn't contain a copy.
   */
  protected void resolveBuildArtifact() {

    // Already resolved?
    if (project.artifact.file)
      return;

    // If the artifact exists in the output directory then we will create a new transitory artifact using that file.
    def File built = new File(project.build.directory, "${project.build.finalName}.${project.artifact.artifactHandler.extension}");
    if (built.exists()) {
      project.artifact.file = built;
    } else {
      log.info("Current module artifact has not been built or the location is not ${built.path} ...");
      // We don't want to resolve the current project artifact remotely- thats just weird.
      try {
        resolver.resolve(project.artifact, [], local)
      } catch (ArtifactNotFoundException e) {
        log.info("Current module artifact is not yet in repository ...");
      }
    }
  }

}
