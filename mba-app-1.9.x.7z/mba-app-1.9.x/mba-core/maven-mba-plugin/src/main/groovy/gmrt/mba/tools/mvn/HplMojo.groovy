package gmrt.mba.tools.mvn

/**
 * @author jason.stiefel@bankofamerica.com
 * @goal hpl
 * @requiresDependencyResolution compile
 * @description Generates a Hudson .hpl file for a plugin artifact.
 * @since 1/4/11
 */
public class HplMojo extends AssembleMojo {

  public void doExecute() {

    if (!project.artifact || project.artifact.type != 'hpi') {
      log.info("Current project artifact type is not 'hpi', it is '${project.artifact.type}'");
      return;
    }

    createHpl();
  }

}
