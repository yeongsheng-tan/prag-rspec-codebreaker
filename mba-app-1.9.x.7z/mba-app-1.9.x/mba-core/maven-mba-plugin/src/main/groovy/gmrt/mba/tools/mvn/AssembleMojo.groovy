package gmrt.mba.tools.mvn

import org.apache.commons.io.FileUtils
import org.apache.maven.artifact.Artifact
import org.apache.maven.plugin.MojoFailureException
import org.apache.maven.project.MavenProject

/**
 * @goal assemble
 * @requiresDependencyResolution runtime
 * @description Resolves all the libs and plugins relative to the current module and copies them into the right spot.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 7/22/11
 */
class AssembleMojo extends AbstractMbaMojo {

  protected File mbaBin;

  void doExecute() {

    if (mbaBase.exists() && mbaBase.file) {
      log.info("Not assembling when mbaBase is a packaged artifact ...");
      return;
    }

    mbaBin = new File(mbaBase, "/bin");
    mbaBin.mkdirs();

    def mbaPlugins = new File(mbaBin, "/plugins");
    collectPlugins(mbaPlugins);

    def mbaJar = new File(mbaBase, "mba.jar")
    if (!mbaJar.exists() || (mbaJar.exists() && (runtimeArtifact.file.lastModified() > mbaJar.lastModified())))
      FileUtils.copyFile(runtimeArtifact.file, mbaJar, true);

  }

  void collectPlugins(File mbaPlugins) {
    if (!mbaPlugins.exists())
      mbaPlugins.mkdirs();
    collectBuildsPlugins(mbaPlugins);
    collectArtifactsPlugins(mbaPlugins);
  }

  /**
   * Configures the Hudson buildsHome with any plugins we found in the dependencies (or current project artifact)
   */
  void collectBuildsPlugins(File mbaPlugins) {

    // Find all the hpis in our collection of transitive dependency artifacts.
    artifactsInScope.unique {"${it.groupId}:${it.artifactId}:${it.baseVersion}"}.collectAll { Artifact artifact ->

      if (project.artifact == artifact && project.packaging == 'hpi')
        return artifact;

      return resolveTypeTransitive(artifact, 'hpi');

    }.flatten().unique {it.file.path}.each { Artifact hpiArtifact ->

      if (hpiArtifact != project.artifact) {

        File pluginArtifact = resolveHpl(hpiArtifact) ?: hpiArtifact.file;
        File pluginTarget = new File(mbaPlugins, "${hpiArtifact.artifactId}.${pluginArtifact.name.substring(pluginArtifact.name.lastIndexOf('.') + 1)}")
        if (pluginTarget.exists() && (pluginArtifact.lastModified() <= pluginTarget.lastModified())) {
          log.info("Plugin ${hpiArtifact} is already up to date ...");

        } else {

          log.info("Copying plugin dependency from ${pluginArtifact} to ${mbaPlugins}");
          FileUtils.copyFile(pluginArtifact, pluginTarget, true);

        }


      } else {

        File hplFile = createHpl();
        log.info("Copying ${hplFile} to ${mbaPlugins} ...");
        FileUtils.copyFileToDirectory(hplFile, mbaPlugins, true);

        log.info("Setting -Dstapler.jelly.noCache=true ...")
        System.properties['stapler.jelly.noCache'] = Boolean.TRUE.toString()


      }
    }

  }

  /**
   * Creates a Hudson hpl file in the build directory for the current project.
   */
  protected File createHpl() {

    def hplFile = new File(project.build.directory, "${project.build.finalName}.hpl")
    org.jvnet.hudson.maven.plugins.hpi.HplMojo hpl = [
            computeHplFile: {
              hplFile;
            }
    ] as org.jvnet.hudson.maven.plugins.hpi.HplMojo;
    hpl.with {
      project = this.project;
      log = this.log;
      pluginName = this.project.name;
      classesDirectory = new File(this.project.build.outputDirectory);
      warSourceDirectory = new File("${this.project.basedir}/src/main/webapp");
    }
    hpl.execute()

    return hplFile;
  }

  /**
   * Looks for an hpl file for an hpi artifact in the parent directory of the current module. <strong>This only
   * occurs when the current project artifact is also an hpi</strong>
   */
  protected File resolveHpl(Artifact hpi) {

    // We only support .hpl when your current module is an hpi as well.
    if (project.packaging != 'hpi')
      return hpi.file

    def hplFile = new File(project.basedir, "../${hpi.artifactId}/target/${hpi.artifactId}.hpl");
    if (hplFile.exists())
      return hplFile;

    return null;

  }

  /**
   * Unpacks any nexus plugins in the dependency tree.
   *
   * @param root
   * @param applianceProperties
   * @return
   */
  void collectArtifactsPlugins(File mbaPlugins) {

    artifactsInScope.unique {"${it.groupId}:${it.artifactId}:${it.baseVersion}"}.collectAll { Artifact artifact ->

      return resolveTypeTransitive(artifact, 'nexus-plugin').collectAll { Artifact npArtifact ->

        def bundle = factory.createArtifactWithClassifier(npArtifact.groupId, npArtifact.artifactId, npArtifact.version, 'zip', 'bundle');
        resolver.resolve(bundle, project.remoteArtifactRepositories, local);
        bundle;

      }

    }.flatten().unique {it.file.path}.each { Artifact nexusPlugin ->

      def dest = new File(mbaPlugins, "${nexusPlugin.artifactId}.zip")
      if (dest.exists() && nexusPlugin.file.lastModified() <= dest.lastModified()) {
        log.info("Plugin ${nexusPlugin} is already up to date ...")
        return;
      }

      log.info("Copying plugin dependency from ${nexusPlugin.file} to ${mbaPlugins}");
      FileUtils.copyFile(nexusPlugin.file, dest, true);

    }


  }

  protected ArrayList<Artifact> resolveTypeTransitive(Artifact artifact, String packaging) {
    try {
      MavenProject artifactProject = projectBuilder.buildFromRepository(artifact, project.remoteArtifactRepositories, local);
      if (artifactProject.packaging == packaging) {
        Artifact potentialArtifact = factory.createArtifact(artifact.groupId, artifact.artifactId, artifact.version, artifact.scope, packaging);
        resolver.resolve(potentialArtifact, project.remoteArtifactRepositories, local)
        return [potentialArtifact];
      }
    } catch (Throwable t) {
    }

    [];

  }

}