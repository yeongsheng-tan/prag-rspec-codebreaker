package gmrt.mba.tools.mvn

/**
 * @goal package
 * @execute phase="process-resources"
 * @requiresDependencyResolution runtime
 * @description Copies the resolved plugins from the mba.base work directory into the target/classes directory so they
 * can be packaged into the final app assembly.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/31/11
 */
class PackageMojo extends AssembleMojo {

  void doExecute() {

    File mbaPlugins = new File(project.build.outputDirectory, "META-INF/${runtimeArtifact.groupId}/${runtimeArtifact.artifactId}/bin/plugins");
    mbaPlugins.mkdirs();

    collectPlugins(mbaPlugins);

  }

}
