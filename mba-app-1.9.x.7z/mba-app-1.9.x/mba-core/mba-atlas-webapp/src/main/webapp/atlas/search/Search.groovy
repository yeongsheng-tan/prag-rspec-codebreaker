import org.springframework.context.ApplicationContext
import gmrt.da.web.atlas.AtlasService
import gmrt.da.web.atlas.AtlasServiceDispatcher
import gmrt.mba.atlas.ManagedContext
import gmrt.mba.atlas.ManagedContext

def pieces = (request.getHeader('referer') =~ /http:\/\/([^\/]+)(\/[^\?]*)/)?.getAt(0);
def server = pieces[1] ?: "";
def requestURI = pieces[2] ?: "";

def ApplicationContext ctx = Appliance.getInstance().getContext(ManagedContext.class)
def AtlasService service = ctx.getBean(AtlasServiceDispatcher.class.name).resolveServiceForURI(requestURI);

service.performSearch(requestURI, request.getParameter('atlas_search'), request, response);


