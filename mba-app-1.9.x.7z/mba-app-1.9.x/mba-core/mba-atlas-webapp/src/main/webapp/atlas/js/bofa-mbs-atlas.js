jQuery.noConflict();

/**
 * It's just sad that javascript doesn't a hash method.
 */
function posHashCode(string){
	var hash = 0;
	if (!string || string.length == 0) return hash;
	for (var i = 0; i < string.length; i++) {
		var _char = string.charCodeAt(i);
		hash = 31*hash+_char;
		hash = hash & hash;
	}
	return (hash < 0) ? -hash : hash;
}

(function() {

    var host, service = 'index';
	try {
		var bits = window.location.href.match(/^http:\/\/([^\/]+)\/([^\/]+)(.*)$/);
        host = bits[1];
        service = bits[2];
	} catch (err) {
		host = window.location.href.split('/')[2];
	}

    var token = ((document.cookie) ? document.cookie : '').match(/crowd\.token_key=[\w]+/);
    token = (token) ? posHashCode(token[0]) : 'NADA';

    var cachebuster = '___' + service + token;

	jQuery.ajax({
		url: 'http://' + host + '/atlas/AtlasEmbed' + cachebuster + '.groovy',
		cache: true,
		success: function(data) {
            jQuery(document).ready(function() {
                var atlasDiv = jQuery('#bofa-code-atlas');
                if (!atlasDiv) {
                    throw new Error("Could not find the bofa-code-atlas div on this page.");
                }
                atlasDiv.html(data)
            });
		}
	});
})();


