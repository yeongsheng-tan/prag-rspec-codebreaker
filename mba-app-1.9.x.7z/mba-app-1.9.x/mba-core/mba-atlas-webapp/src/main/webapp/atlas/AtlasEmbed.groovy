import gmrt.da.web.atlas.AtlasServiceDispatcher
import org.springframework.web.context.support.WebApplicationContextUtils

response.setHeader('Cache-Control', 'max-age=600');

def ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(context);

def referer = request.getHeader('referer') ?: 'http://code.bankofamerica.com/';
def pieces = (referer =~ /http:\/\/([^\/]+)(\/.*)/)?.getAt(0);
def requestURI = pieces[2] ?: '';

def dispatcher = ctx.getBean(AtlasServiceDispatcher.class.name)
def service = dispatcher.resolveServiceForURI(requestURI);
def contextKey = service?.getContextKey(requestURI);
def user = appliance.auth.user;
def anon = appliance.auth.anonymous;

def authLink = "${(user != anon) ? appliance.config.security.logout : appliance.config.security.login}${(referer) ? "?target=${URLEncoder.encode(referer, "utf8")}" : ''}";
def authTxt = (user != anon) ? 'Logout' : 'Login';

gsp('AtlasEmbed.gsp', [
        appliance: appliance,
        title: appliance.name,
        contextKey: contextKey,
        user: user,
        anon: anon,
        service: service,
        dispatcher: dispatcher,
        requestURI: requestURI,
        referer: referer,
        authLink: authLink,
        authTxt: authTxt
])