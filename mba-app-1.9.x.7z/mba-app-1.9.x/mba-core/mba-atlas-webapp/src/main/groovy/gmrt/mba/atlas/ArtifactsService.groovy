package gmrt.mba.atlas

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import gmrt.da.web.atlas.AtlasService
import gmrt.mba.Appliance

/**
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 15, 2010
 */
class ArtifactsService implements AtlasService {

  def String getLabel(String projectKey, String requestURI) {
    return 'Artifacts';
  }

  def String getContextKey(String requestURI) {
    return 'ANON';
  }

  def String getTitle(String requestURI) {
    return 'Developer Architecture Appliance';
  }

  def String getHref(String contextKey, String requestURI) {
    return '/artifacts/';
  }

  def void performSearch(String requestURI, String query, HttpServletRequest request, HttpServletResponse response) {
    //To change body of implemented methods use File | Settings | File Templates.
  }


}
