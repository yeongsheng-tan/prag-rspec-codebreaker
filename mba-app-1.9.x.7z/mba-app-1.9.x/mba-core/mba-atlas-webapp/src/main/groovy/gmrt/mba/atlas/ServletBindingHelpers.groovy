package gmrt.mba.atlas

import org.codehaus.groovy.runtime.MethodClosure
import javax.servlet.http.HttpServletRequest
import gmrt.mba.Appliance
import gmrt.da.web.BindingHelper
import groovy.servlet.ServletBinding

/**
 * Adds the methods of this class  to the binding for linking to code/.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 1/17/11
 */
class ServletBindingHelpers implements BindingHelper {

  private static final String GSP_INCLUDE = 'gsp-include';

  private groovy.servlet.ServletBinding binding;
  private Writer writer;

  void setVariables(ServletBinding binding) {

    this.binding = binding;
    this.writer = binding.getVariable('out');

    binding.setVariable('ServletBindingHelpers', this);

    try {
      HttpServletRequest request = (HttpServletRequest)binding.getVariable('request');
      Map propagatedVariables = request.getAttribute(GSP_INCLUDE);
      propagatedVariables.each { k, v ->
        binding.setVariable(k, v);
      }
    } catch (MissingPropertyException e) {
      // No worries, we're not "propagating" then...
    };

    // TODO Make this dynamic
    binding.setVariable('appliance', Appliance.instance)
    binding.setVariable('doc', new MethodClosure(this, 'doc'))
    binding.setVariable('issue', new MethodClosure(this, 'issue'))
    binding.setVariable('gsp', new MethodClosure(this, 'gsp'))

  }

  /**
   * Links to a doc.
   *
   * @param project where the page lives
   * @param name of page
   * @param text - optional link text
   */
  public String doc(List<String> args) {
    def (project, page, text) = [args[0], args[1], args[2]]
    return "<a href='http://code.bankofamerica.com/docs/display/${project}/${page ?: ''}'>${text ?: page}</a>"
  }

  /**
   * Links to an issue by key
   *
   * @param key Issue key
   * @param text Optional text of link (null uses key)
   */
  public String issue(List<String> args) {
    def (key, text) = [args[0], args[1]]
    return "<a href='http://code.bankofamerica.com/${key}'>${text ?: key}</a>"
  }

  /**
   * Renders a gsp style template using the current binding plus bindings specified.
   */
  public void gsp(String path, Map binding) {

    HttpServletRequest request = (HttpServletRequest)this.binding.getVariable('request');
    request.setAttribute(GSP_INCLUDE, binding);
    this.binding.include(path);

  }

}
