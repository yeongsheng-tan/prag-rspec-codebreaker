package gmrt.mba.atlas

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import gmrt.da.web.atlas.AtlasService

/**
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 16, 2010
 */
class HelpService implements AtlasService {

  def String getLabel(String projectKey, String requestURI) {
    return 'Help';
  }

  def String getContextKey(String requestURI) {
    null;
  }

  def String getTitle(String requestURI) {
    null;
  }

  def String getHref(String contextKey, String requestURI) {
    return 'http://code.bankofamerica.com/docs/display/CODE/Managed+Build+Appliance+(MBA)';
  }

  def void performSearch(String requestURI, String query, HttpServletRequest request, HttpServletResponse response) {
    //To change body of implemented methods use File | Settings | File Templates.
  }


}
