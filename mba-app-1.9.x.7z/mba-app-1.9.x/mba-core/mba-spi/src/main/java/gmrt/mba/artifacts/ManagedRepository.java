package gmrt.mba.artifacts;

import java.util.LinkedList;
import java.util.List;

/**
 * A "registry" of repositories that are managed within the appliance.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/28/11
 */
public enum ManagedRepository {

    REPO2_CENTRAL("mba-repo2-central", "MBA Repo2 - Maven Central", Policy.RELEASE, "http://repo2.bankofamerica.com/content/repositories/central/"),
    REPO2_EFS("mba-repo2-efs", "MBA Repo2 - EFS", Policy.RELEASE, "http://repo2.bankofamerica.com/content/repositories/efs-maven/"),
    REPO2_OLEX("mba-repo2-olex", "MBA Repo2 - Olex", Policy.RELEASE, "http://repo2.bankofamerica.com/content/repositories/olex/"),
    //REPO2_TOOLS("mba-repo2-tools", "MBA Repo2 - Tools", Policy.RELEASE, "http://repo2.bankofamerica.com/content/repositories/mba-tools/"),
	REPO2_TOOLS("mba-repo2-tools", "MBA Repo2 - Tools", Policy.RELEASE, "http://nysmba001.usnyctd.amrs.bankofamerica.com:8000/artifacts/content/repositories/mba-tools/"),

    RELEASES(Type.HOSTED, "mba-releases", "MBA Releases", Policy.RELEASE),
    SNAPSHOTS(Type.HOSTED, "mba-snapshots", "MBA Snapshots", Policy.SNAPSHOT),
    THIRDPARTY(Type.HOSTED, "mba-thirdparty", "MBA Thirdparty", Policy.RELEASE),

	//Added new Hosted Managed Repo to contain the backup zip archives to be uploaded/deployed from the MBA backup job
	//BACKUP_SNAPSHOTS(Type.HOSTED, "mba-backup-snapshots", "MBA Backup Snapshots", Policy.SNAPSHOT),
	BACKUP(Type.HOSTED, "mba-backup", "MBA Backup", Policy.SNAPSHOT),
	//GROUP_BACKUP("mba-backup-group","MBA Backup Group", null, new ManagedRepository[] {BACKUP_SNAPSHOTS,BACKUP_RELEASES}),

    GROUP("mba-group", "MBA Group", null, new ManagedRepository[] {RELEASES, SNAPSHOTS, THIRDPARTY, REPO2_OLEX, REPO2_CENTRAL, REPO2_EFS});

    public static enum Type {
        PROXY, GROUP, HOSTED
    }

    public static enum Policy {
        RELEASE, SNAPSHOT
    }

    /**
     * The "type" indicates whether we are dealing with a group or just a straight repository
     */
    public final Type type;

    /**
     * Identifier for the repository, includes the "type" and unique id: "<strong>groups/mba-group</strong>".
     */
    public final String id;

    /**
     * Display name
     */
    public final String name;

    /**
     * Indicates the policy for the repository
     */
    public final Policy policy;

    /**
     * When type == GROUP you will have children repositories that make up the group.
     */
    public final ManagedRepository[] children;

    /**
     * When type == PROXY you will have a url to be proxied.
     */
    public final String url;

    ManagedRepository(Type type, String id, String name, Policy policy) {
        this(type, id, name, policy, new ManagedRepository[]{}, null);
    }

    ManagedRepository(String id, String name, Policy policy, ManagedRepository[] children) {
        this(Type.GROUP, id, name, policy, children, null);
    }

    ManagedRepository(String id, String name, Policy policy, String url) {
        this(Type.PROXY, id, name, policy, new ManagedRepository[]{}, url);
    }

    ManagedRepository(Type type, String id, String name, Policy policy, ManagedRepository[] children, String url) {
        this.type = type;
        this.id = id;
        this.name = name;
        this.policy = policy;
        this.children = children;
        this.url = url;
    }

    public static ManagedRepository[] values(Type type) {
        List<ManagedRepository> ofType = new LinkedList<ManagedRepository>();
        for (ManagedRepository mr : values()) {
            if (mr.type.equals(type))
                ofType.add(mr);
        }
        return ofType.toArray(new ManagedRepository[ofType.size()]);
    }

}
