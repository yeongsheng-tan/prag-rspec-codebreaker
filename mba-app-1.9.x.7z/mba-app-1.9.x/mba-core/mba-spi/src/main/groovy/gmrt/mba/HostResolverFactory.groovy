package gmrt.mba

import org.springframework.beans.factory.FactoryBean
import org.springframework.beans.factory.InitializingBean
import org.springframework.beans.factory.annotation.Autowired

/**
 * A factory for {@link HostResolver}s that handles the "default" behavior for the resolver- namely that
 * related to port being derived from the current appliance version.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 12/30/10
 */
class HostResolverFactory {

  /**
   * The base or prefix for calculating the HTTP host port.
   */
  public static final Integer HTTP_BASE = 80;

  /**
   * When calculating the serv port for the container we will add this amount to the port indicated by
   * {@link HostResolver#getPort()}
   */
  public static final int SERV_PORT_ADDS = 1000;

  private gmrt.mba.HostResolver hostResolver;

  HostResolverFactory(Config config) {
    String verNums = HTTP_BASE + "${config.version.base.replaceAll('\\D', '')}".substring(0, (4 - HTTP_BASE.toString().length()));
    def httpPort = config.httpPort ?: Integer.valueOf(verNums);
    def servPort = config.servPort ?: httpPort + SERV_PORT_ADDS;

    this.hostResolver = new gmrt.mba.HostResolver(config.httpHost, httpPort, servPort);
  }

  HostResolver build() {
    return this.hostResolver;
  }

}
