package gmrt.mba.auth

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/8/11
 */
class WorkerCredentials {

  def String username;
  def String password;
  def String remoteAddr;

  boolean equals(o) {
    if (this.is(o)) return true;
    if (!(o instanceof WorkerCredentials)) return false;

    WorkerCredentials that = (WorkerCredentials) o;

    if (password != that.password) return false;
    if (remoteAddr != that.remoteAddr) return false;
    if (username != that.username) return false;

    return true;
  }

  int hashCode() {
    int result;
    result = username.hashCode();
    result = 31 * result + password.hashCode();
    result = 31 * result + remoteAddr.hashCode();
    return result;
  }

}
