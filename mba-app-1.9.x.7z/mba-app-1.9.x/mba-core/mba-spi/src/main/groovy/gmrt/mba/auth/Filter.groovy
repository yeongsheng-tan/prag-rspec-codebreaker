package gmrt.mba.auth

import gmrt.da.auth.Auth
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import javax.servlet.FilterChain
import gmrt.mba.Appliance
import javax.servlet.ServletRequest
import javax.servlet.ServletResponse

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/23/11
 */
class Filter extends gmrt.da.auth.Filter {

  @Override
  Auth getAuth(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
    Appliance.instance.auth;
  }

}
