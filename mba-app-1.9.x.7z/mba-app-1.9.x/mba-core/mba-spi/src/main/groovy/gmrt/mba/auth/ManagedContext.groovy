package gmrt.mba.auth

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/23/11
 */
public interface ManagedContext extends gmrt.da.ManagedContext {}