package gmrt.mba.auth

import gmrt.da.auth.NameRoleMapper
import gmrt.da.auth.Role

/**
 * Maps group memberships from Crowd with a list of "contexts" that are basically just a prefix for the groups being
 * matched. Matches groups of the form (with a list of groupPrefixes == ["code-mbs","code-code"]:
 *
 * <li><b>code-mbs-developers</b>: {@link MbaRole#DEVELOPER}
 * <li><b>code-code-administrators</b>: {@link MbaRole#ADMINISTRATOR}.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 1/23/11
 */
class MbaRoleMapper extends NameRoleMapper {

  private List<String> groupPrefixes;
  private String systemGroup;

  MbaRoleMapper(String systemGroup, String[] groupPrefixes) {
    super(Arrays.asList(MbaRole.values()) as List<MbaRole>);
    this.systemGroup = systemGroup;
    this.groupPrefixes = Arrays.asList(groupPrefixes).collect {it.trim()}
  }

  @Override
  protected Role match(String entitlementName) {

    if (this.systemGroup.toLowerCase() == entitlementName.toLowerCase())
      return MbaRole.SYSTEM;

    def (String groupName, String roleName) = (entitlementName.toLowerCase() =~ /(.*)-([administrators|developers|collaborators]+)/).with {
      if (!matches())
        return [];
      return [group(1), group(2)];
    };

    if (!groupName || !roleName)
      return null;

    if (!groupPrefixes.find { it.toLowerCase() == groupName.toLowerCase() })
      return null;

    return roles.find { Role role -> "${role.name}s".toString().toLowerCase().equals(roleName)  };
  }

}
