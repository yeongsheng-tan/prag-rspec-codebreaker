package gmrt.mba

import org.codehaus.cargo.container.deployable.DeployableType
import org.codehaus.cargo.container.deployable.WAR
import org.codehaus.cargo.generic.deployable.DefaultDeployableFactory
import org.codehaus.cargo.generic.deployable.DeployableFactory
import org.codehaus.cargo.container.configuration.ConfigurationType
import org.codehaus.cargo.container.ContainerType
import org.codehaus.cargo.container.configuration.LocalConfiguration
import org.codehaus.cargo.container.jetty.Jetty6xEmbeddedStandaloneLocalConfiguration
import org.codehaus.cargo.generic.configuration.DefaultConfigurationFactory
import org.codehaus.cargo.generic.configuration.ConfigurationFactory
import org.codehaus.cargo.generic.ContainerFactory
import org.codehaus.cargo.generic.DefaultContainerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.apache.log4j.Logger
import org.codehaus.cargo.container.jetty.Jetty6xEmbeddedLocalContainer
import org.codehaus.cargo.container.State
import org.springframework.beans.factory.DisposableBean
import org.codehaus.cargo.util.log.LogLevel
import org.codehaus.cargo.container.ContainerException
import org.codehaus.cargo.container.deployable.Deployable
import org.apache.log4j.Priority
import org.springframework.beans.factory.InitializingBean
import gmrt.da.ManagedContext

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/22/11
 */
class Container implements ManagedContext, InitializingBean {

  private static final Logger LOG = Logger.getLogger(Container.class);

  /**
   * Time before we give up on starting the container successfully.
   */
  public static final Long CONTAINER_START_TIMEOUT = 300000;
  public static final Long CONTAINER_SLEEP = 1000;

  public static final int CONTAINER_PING = 0;
  public static final int CONTAINER_STOP = 1;
  public static final int CONTAINER_RESTART = 2;

  private transient Jetty6xEmbeddedLocalContainer container;

  @Autowired
  private Config config;

  @Autowired
  private HostResolver hostResolver;

  private boolean pendingRestart = false;
  private AntBuilder ant = new AntBuilder();

  /**
   * Starts the container, blocking until it is stopped (or startup exceeds {@link #CONTAINER_START_TIMEOUT})
   */
  /*package*/

  protected void start() {

    pendingRestart = false;
    LOG.info("Starting container ...");

    listenOnServPort();

    def containerClassLoader = new URLClassLoader([] as URL[], getClass().getClassLoader());

    ConfigurationFactory cfgFactory = new DefaultConfigurationFactory();
    cfgFactory.registerConfiguration('jetty6x', ContainerType.EMBEDDED, ConfigurationType.STANDALONE,
            containerClassLoader.loadClass(Jetty6xEmbeddedStandaloneLocalConfiguration.class.name));

    LocalConfiguration jettyConfig =
    cfgFactory.createConfiguration('jetty6x', ContainerType.EMBEDDED, ConfigurationType.STANDALONE);
    jettyConfig.setProperty('cargo.servlet.port', Integer.toString(hostResolver.port));

    DeployableFactory df = new DefaultDeployableFactory();
    df.registerDeployable('jetty6x', DeployableType.WAR, containerClassLoader.loadClass(WAR.class.name));

    if (config.atlas.war.exists()) {
      WAR atlas = df.createDeployable('jetty6x', config.atlas.war.path, DeployableType.WAR);
      atlas.setContext('/');
      jettyConfig.addDeployable(atlas);
    }

    if (config.artifacts.war.exists()) {
      WAR artifacts = df.createDeployable('jetty6x', config.artifacts.war.path, DeployableType.WAR);
      artifacts.setContext('/artifacts');
      jettyConfig.addDeployable(artifacts);
    }

    if (config.builds.war.exists()) {
      WAR builds = df.createDeployable('jetty6x', config.builds.war.path, DeployableType.WAR);
      builds.setContext('/builds');
      jettyConfig.addDeployable(builds);
    }

    ContainerFactory cf = new DefaultContainerFactory();
    cf.registerContainer('jetty6x', ContainerType.EMBEDDED, containerClassLoader.loadClass(JettyContainer.class.getName()));

    container = cf.createContainer('jetty6x', ContainerType.EMBEDDED, jettyConfig);
    container.setClassLoader(containerClassLoader);
    container.setTimeout(CONTAINER_START_TIMEOUT);
    container.start();

    Runtime.runtime.addShutdownHook([
            run: {
              LOG.info("Shutdown of JVM has been initiated ...");
              //stop();
            }
    ] as Thread);

    LOG.info("Managed Build Appliance ${Appliance.instance.version} container serving at URL: http://${hostResolver.host}/");

    while (container.state != State.STOPPED) {
      try {
        Thread.sleep(CONTAINER_SLEEP);
      } catch (InterruptedException e) {
        LOG.error("Exception occured while monitoring container state", e);
      }
    }

    LOG.info("Container stopped, pausing for 20secs just to make sure ...");
    Thread.sleep(20000);
    container = null;

  }

  /**
   * Stops the {@link Container}. Blocks until completed, or at least it is SUPPOSED to but seldom actually works as
   * Hudson is often shutting down in another thread or something?
   *
   * TODO Add better blocking capability. Perhaps we should just force a block for the {@link #CONTAINER_SLEEP} period?
   */
  /*package*/

  protected void stop() {
    LOG.info("Stopping container ...");
    container.stop();
  }

  /**
   * Checks with the container instance to see if it's reporting started. This method works in the same JVM.
   */
  boolean isStarted() {
    container && container.state == State.STARTED
  }

  /**
   * Attempts to grab the servPort to see if the container is running as another process. This method works across
   * JVMs.
   */
  boolean isRunning() {

    LOG.info("Checking to see if container is running by pinging ${hostResolver.serv} ...");
    try {
      serv(CONTAINER_PING);
      return true;
    } catch (Throwable t) {
      LOG.info("Does not seem to be running as no response on ${hostResolver.serv} ...");
    }

    return false;
  }

  /**
   * Indicates whether a restart has been requested...
   */
  boolean isPendingRestart() {
    return pendingRestart;
  }

  /**
   * Opens a socket listener on the {@link Config#servPort}
   */
  private def listenOnServPort() {

    def ServerSocket servSocket = new ServerSocket();
    servSocket.setReuseAddress(true);
    servSocket.bind(new InetSocketAddress(hostResolver.getServ()));

    Thread.start {

      LOG.info("Listening on ${hostResolver.getServ()} for serv ...");
      try {
        int command = CONTAINER_PING;
        while (command == CONTAINER_PING) {

          servSocket.accept { Socket socket ->

            socket.withStreams { InputStream is, OutputStream os ->

              command = Integer.valueOf(new BufferedReader(new InputStreamReader(is)).readLine());

              try {
                switch (command) {
                  case CONTAINER_PING:
                    LOG.info("Received ping from ${socket.remoteSocketAddress} ...");
                    os.write(CONTAINER_PING);
                    break;
                  case CONTAINER_STOP:
                    LOG.info("Received stop from ${socket.remoteSocketAddress} ...");
                    os.write(CONTAINER_PING);
                    stop();
                    break;
                  case CONTAINER_RESTART:
                    LOG.info("Received restart from ${socket.remoteSocketAddress} ...");
                    os.write(CONTAINER_PING);
                    pendingRestart = true;
                    stop();
                    break;
                }

              } catch (Throwable t) {
                LOG.error("Exception occured stopping container ...", t);
                os.write(1);

              } finally {
                socket.close();
              }

            }
          }

        }

      } finally {

        LOG.info("Closing serv socket on " + hostResolver.serv);

        servSocket.close();
        servSocket = null;
      }


    }
  }

  /**
   * Sends the specified command to the serv port.
   */
  protected void serv(int cmd) {
    LOG.info("Sending code to appliance using ${hostResolver.serv}");
    def returned = new Socket(InetAddress.localHost, hostResolver.serv).withStreams { InputStream is, OutputStream os ->
      new PrintWriter(os, true).println(cmd);
      return new InputStreamReader(is).readLine();
    }
    LOG.info("Appliance responded with code: ${returned}");
  }

  void afterPropertiesSet() {

    assert config, 'config is required';
    assert hostResolver, 'hostResolver is required';

  }

}

/**
 * Wraps around the {@link Jetty6xEmbeddedLocalContainer} to the {@link gmrt.mba.auth.Filter}
 * Also deals with preventing the "default" cargo shutdown hook in favor of one implemented using
 * {@link org.springframework.beans.factory.DisposableBean}.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 12/26/10
 */
class JettyContainer extends Jetty6xEmbeddedLocalContainer implements DisposableBean {

  private static final Logger LOG = Logger.getLogger(Container.class);

  private org.codehaus.cargo.util.log.Logger logger;

  public JettyContainer(LocalConfiguration configuration) {
    super(configuration)
    this.logger = [
            doLog: { LogLevel level, String message, String category ->
              LOG.log(toPriority(level), message);
            },

    ] as org.codehaus.cargo.util.log.SimpleLogger
  }

  /**
   * Overloads the {@link Jetty6xEmbeddedLocalContainer#createServerObject()} method to prevent registering a JVM
   * shutdown hook that isn't needed. We're using {@link DisposableBean} to handle calling {@link #stop}.
   */
  @Override
  protected synchronized void createServerObject() {
    if (getServer() == null) {
      try {
        this.server = getClassLoader().loadClass("org.mortbay.jetty.Server").newInstance();
      }
      catch (Exception e) {
        throw new ContainerException("Failed to create Jetty Server instance", e);
      }
    }
  }

  @Override
  public Object createHandler(Deployable deployable) {
    if (LOG.debugEnabled)
      LOG.debug("Adding the override descriptor to context: ${deployable}");
    Object webApp = super.createHandler(deployable);
    webApp.getClass().getMethod('setDefaultsDescriptor', [String.class] as Class[]).
            invoke(webApp, 'gmrt/mba/Appliance/jetty-web.xml');
    return webApp;
  }

  @Override
  org.codehaus.cargo.util.log.Logger getLogger() {
    return logger;
  }

  /**
   * Converts a {@link LogLevel} to a {@link Priority}.
   */
  def Priority toPriority(LogLevel level) {
    switch (level) {
      case LogLevel.WARN: return Priority.WARN;
      case LogLevel.INFO: return Priority.INFO;
      case LogLevel.DEBUG: return Priority.DEBUG;
      default: throw new IllegalArgumentException("Unmapped level: ${level}");
    }
  }

  /**
   * Stops the container if it is running. Blocks until shutdown is complete or an exception is thrown by
   * {@link org.codehaus.cargo.container.internal.RunnableContainer#stop()}
   */
  void destroy() {

    if (State.STOPPED != getState())
      stop();

  }


}
