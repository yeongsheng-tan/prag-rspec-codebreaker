package gmrt.mba

import gmrt.da.auth.Role
import org.apache.log4j.Logger
import org.springframework.beans.FatalBeanException
import org.springframework.beans.factory.InitializingBean

/**
 * Encapsulates and validates the mba configuration.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 1/22/11
 */
class Config implements InitializingBean {

  private static final Logger LOG = Logger.getLogger(Config.class);

  public static final String TEMPLATE_VALUE = "**TEMPLATE_VALUE**";

  def HostResolver hostResolver;

  def String name;

  def File base;
  def File home;
  def File work;

  protected String logConfig;
  protected String httpHost;
  protected Integer httpPort;
  protected Integer servPort;
  protected Security security;

  def Atlas atlas;
  def Builds builds;
  def Artifacts artifacts;

  def Notifications notifications;

  def Version version = new Version();

  def Grid grid;

  //Config param to define master MBA for update site URL
  def String mbaUpdateHost;
  def Integer mbaUpdatePort;

  //Config param to define CODE/Builds backup/restore strategy (Ant-based or Rsync-timemachine-based)
  def String mbaBackupStrategy

  public void setLogConfig(String logConfig) {
    this.logConfig = logConfig;
  }
  public void setHttpHost(String httpHost) {
    this.httpHost = httpHost;
  }
  public void setHttpPort(Integer httpPort) {
    this.httpPort = httpPort;
  }
  public void setServPort(Integer servPort) {
    this.servPort = servPort;
  }
  public void setSecurity(Security security) {
    this.security = security;
  }

  /**
   * Configures the system environment from the {@link Config} instance that is injected by the root context. Sets
   * the following system properties:
   *
   * <li><b>mba.base</b> Base appliance directory (where the jars/wars, etc.. live)
   * <li><b>mba.home</b> Home directory (where hudson, nexus configs live, log files, work dir, etc..)
   * <li><b>user.home</b> Default is configured to use the <i>mba.home</i>/work/user.home directory, see
   * <i>mba.default.properties</b> for the default value.
   */
  void afterPropertiesSet() {

    // Extract the version information from MANIFEST.MF
    version.name = Config.class.package.specificationTitle ?: version.name;
    version.base = Config.class.package.specificationVersion ?: version.base;
    version.tag = Config.class.package.implementationTitle ?: version.tag;
    version.cl = Config.class.package.implementationVersion ?: version.cl;

    version.full = "${version.name}-${version.base}@${version.cl}"

    hostResolver = new HostResolverFactory(this).build();

    atlas.init(this);
    artifacts.init(this);
    builds.init(this);

  }


}

class Version {
  def String full;
  def String name;
  def String base;
  def String tag;
  def String cl;
}

class Notifications {
  def String smtpHost = '';
  def Integer smtpPort = 0;
  def String smtpUser = '';
  def String smtpPass = '';
  def String replyTo = 'no-reply@mbs.bankofamerica.com';
}

class Atlas extends Service {
  @Override
  void init(Config config) {}
}

class Builds extends Service {
  def boolean masterWorkerEnabled;
  def Integer workerLimit;
  def String workerJdkUnix;
  def String workerJdkWin;
  def String workerJdkArgs;

  @Override
  void init(Config config) {

    System.setProperty('JENKINS_HOME', home.path);

    // http://wiki.hudson-ci.org/display/HUDSON/Features+controlled+by+system+properties
    System.setProperty('hudson.lifecycle', 'gmrt.mba.builds.Lifecycle');
    System.setProperty('hudson.DNSMultiCast.disabled', 'true');
    System.setProperty('hudson.model.DownloadService.never', 'true');
    System.setProperty('hudson.model.UpdateCenter.never', 'true');

  }

}

class Artifacts extends Service {

  def File repos;
  def boolean remoteIndexesEnabled;

  @Override
  void init(Config config) {

    def nexusConf = new File(home, 'conf')
    if (!nexusConf.exists() && !nexusConf.mkdirs())
      throw new FatalBeanException("Could not create conf directory ${nexusConf}");
    System.setProperty('plexus.nexus-work', home.path);
    System.setProperty('plexus.application-conf', nexusConf.path);
    System.setProperty('plexus.configuration-file', new File(nexusConf, 'nexus.xml').path);
    System.setProperty('plexus.security-xml-file', new File(nexusConf, 'security.xml').path);

  }

}

abstract class Service {
  def File war;
  def File home;
  abstract void init(Config config);
}

class Security {
  def boolean enabled;
  def String[] verticals;
  def Role defaultRole;
  def String systemGroup;
  def String logout;
  def String login;
}

class Grid {
    def String defaultDispatcherUrl;
}