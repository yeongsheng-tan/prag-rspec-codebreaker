package gmrt.mba

import org.apache.log4j.xml.DOMConfigurator

import org.apache.log4j.Logger

import gmrt.da.conf.App
import gmrt.da.RootContext
import gmrt.da.ManagedContext
import gmrt.da.auth.Auth

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/22/11
 */
class Appliance extends RootContext<Appliance> implements ManagedContext<Appliance> {

  private static Logger LOG;

  /**
   * The "default" properties that are compiled into the core jar. You need only override the
   * values you want to change.
   */
  public static final String MBA_CONFIG_DEFAULT = 'classpath:META-INF/gmrt.mba.core/mba-spi/mba.default.properties';


  private static Appliance INSTANCE;
  private final transient Config config;

  private Appliance() {
    super();
    config = getBean(getClass(), Config.class);
  }

  Config getConfig() {
    config;
  }

  Auth getAuth() {
    getBean(gmrt.mba.auth.ManagedContext.class, Auth.class);
  }

  /**
   * Returns the "name" of the appliance configured as <i>mba.name</i>
   */
  public String getName() {
    config.name
  }

  /**
   * Returns the full version of the {@link Appliance} as {@link Version#full}.
   */
  public String getVersion() {
    config.version.full;
  }

  public static Appliance getInstance() {
    if (!INSTANCE)
      initialize();
    INSTANCE;
  }

  /**
   * Close the appliance down entirely so it can be re-initialized using {@link #getInstance}. You <strong>must</strong>
   * throw away any "cached" instance of {@link Appliance} after calling this.
   */
  public static synchronized void shutdown() {

    if (!INSTANCE)
      throw new IllegalStateException("Attempted to shutdown() appliance that is not already initialized.");

    getInstance().close();
    INSTANCE = null;

  }

  private static synchronized void initialize() {

    if (INSTANCE)
      return;

    // Basic "sane" logging configuration until we can get everything else set up.
    DOMConfigurator.configure(Appliance.class.getResource("/${Appliance.class.name.replaceAll(/\./, '/')}/log4j.xml"));

    Appliance.LOG = Logger.getLogger(Appliance.class);

    if (!System.getProperty(Sys.MBA_CONFIG)) {
      System.setProperty(App.class.name, MBA_CONFIG_DEFAULT);
    } else {
      System.setProperty(App.class.name, "${MBA_CONFIG_DEFAULT},${System.getProperty(Sys.MBA_CONFIG)}");
    }
    LOG.info("Appliance configuration source will be: ${System.getProperty(App.class.name)}");

    try {

      INSTANCE = new Appliance();
      Config config = INSTANCE.getBean(Appliance.class, Config.class);

      System.setProperty(Sys.MBA_BASE, config.base.path);
      System.setProperty(Sys.MBA_HOME, config.home.path);

      File userHome = new File(new File(config.work, "local"), "master.home");
      userHome.mkdirs();
      System.setProperty('user.home', userHome.path);
      File tmp = new File(userHome, "temp");
      tmp.mkdirs();
      System.setProperty('java.io.tmpdir', tmp.path);

      if (config.logConfig) {
        LOG.info("Reconfiguring logging using: ${config.logConfig} ...");
        DOMConfigurator.configure(config.logConfig.toURL());
      }

    } catch (Throwable t) {
      LOG.error("Exception occured starting root context ...", t);
      throw t;
    };

    LOG.info("Root context initialization complete ...");
  }


}
