package gmrt.mba

import org.apache.commons.lang.StringUtils

/**
 * Resolves the appliance fqhn + port using {@link InetAddress#getLocalHost()} if no values are specified in the
 * constructor.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 12/18/10
 */
class HostResolver {

  public static final int BLANK_PORT = 80;

  private String hostName;
  private int hostPort;
  private int servPort;

  /**
   * Specifying a <code>null</code> or <code>emtpy</code> string for the hostname will result in the 'default'
   * strategy being used.
   * @param hostName Specify hostName or you get a default of {@link InetAddress#getLocalHost()}
   * @param hostPort Specify port or you get {@link #BLANK_PORT}
   * @param servPort Port listening for serv commands
   */
  HostResolver(String hostName, Integer hostPort, Integer servPort) {
    this.hostName = (StringUtils.isBlank(hostName)) ? InetAddress.localHost.canonicalHostName : hostName;
    this.hostPort = hostPort;
    this.servPort = servPort;
  }

  /**
   * Returns the concatenated <code>hostName</code> and <code>hostPort</code>. When port is
   * equal to {@link #BLANK_PORT} (80) you will only be returned the <code>hostName</code>.
   */
  public String getHost() {
    StringBuilder sb = new StringBuilder(hostName);
    if (BLANK_PORT != hostPort)
      sb.append(':').append(hostPort);
    return sb.toString();
  }

  public String getName() { return hostName; }
  public int getPort() { return hostPort; }
  public int getServ() { return servPort; }

}
