package gmrt.mba.auth

import gmrt.da.auth.Role
import gmrt.da.auth.User

/**
 * Represents the roles that are available within a Managed Build Appliance. These roles are "mapped" into the
 * authentication infrastructure by the {@link MbaRoleMapper}.
 *
 * @see MbaRoleMapper
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 1/23/11
 */
enum MbaRole implements Role {

  SYSTEM('System'),
  ADMINISTRATOR('Administrator'),
  DEVELOPER('Developer'),
  WORKER('Worker'),
  COLLABORATOR('Collaborator'),
  ANON('Anonymous')

  private String label;

  MbaRole(String label) {
    this.label = label
  }

  String getName() {
    name();
  }

  String getLabel() {
    label;
  }

  boolean isAtLeast(User user, MbaRole mbaRole) {
    if (user.role.ordinal() <= mbaRole.ordinal())
      return true;
    false;
  }

}