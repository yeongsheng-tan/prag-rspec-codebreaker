package gmrt.mba.auth

import gmrt.da.util.Base64
import java.security.SecureRandom
import javax.servlet.http.HttpServletRequest
import org.apache.log4j.Logger
import org.springframework.beans.factory.InitializingBean
import gmrt.da.auth.*

/**
 * A simple {@link Realm} implementation that will create a single user on initialization that is granted
 * {@link MbaRole#WORKER}. The username and password for this user will change on each startup of the MBA.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 1/8/11
 */
class WorkerRealm implements Realm, InitializingBean {

  private static Logger LOG = Logger.getLogger(WorkerRealm.class);
  private static final String METHOD_PUT = 'put';

  public static final String MBA_WORKER_REALM = "MBA Worker Realm";

  private SecureRandom random = new SecureRandom();

  def User workerUser;
  def Boolean securityEnabled;
  def String mbaHost;
  def String mbaName;

  Object credentials(HttpServletRequest request) {

    if (!securityEnabled)
      throw new NoCredentialsException();

    def authorization = request.getHeader('Authorization');

    if (METHOD_PUT != request.method.toLowerCase() && !authorization)
      throw new NoCredentialsException();
    if (METHOD_PUT == request.method.toLowerCase() && !authorization)
      throw new SendChallengeException(MBA_WORKER_REALM);

    try {

      if (LOG.debugEnabled)
        LOG.debug("Found authorization header: ${authorization}");

      def byte[] decode = Base64.decode(authorization.substring(6));

      if (LOG.debugEnabled)
        LOG.debug("Decoded authorization into bytes ${decode}");

      def (String username, String password) = (new String(decode) =~ /([\w]+)[\W]([\w]+)/).with {
        if (!matches())
          throw new IllegalArgumentException("Invalid authorization format: ${authorization}");
        return [group(1), group(2)]
      }

      if (LOG.debugEnabled)
        LOG.debug("Split authorization header to find ${username} / ${password} from ${request.remoteAddr}");

      return new gmrt.mba.auth.WorkerCredentials(username: username, password: password, remoteAddr: request.remoteAddr);

    } catch (Throwable t) {
      LOG.debug("Unable to handle extracting authorization ${authorization}", t);
      throw new NoCredentialsException("Unable to handle extracting authorization ${authorization}", t);
    };


  }

  User authenticate(Object _credentials) {

    gmrt.mba.auth.WorkerCredentials credentials = (gmrt.mba.auth.WorkerCredentials)_credentials;
    User user = getUser(credentials.username);

    if (LOG.debugEnabled)
      LOG.debug("Authenticating deployer credentials ${credentials} for ${user}");

    if (user.credentials != credentials.password) {
      if (LOG.debugEnabled)
        LOG.debug("User credentials didn't match (${user.credentials} != ${credentials.password})");
      throw new AuthRejectedException(credentials.username, credentials.password, null);
    }

    return user;
  }

  /**
   * Looks the {@link User} up in the "cache"
   * @throws UserNotFoundException
   */
  User getUser(String userId) {
    if (userId == workerUser.userId)
      return workerUser;
    throw new UserNotFoundException(userId);
  }

  List<User> getUsers() {
    return (workerUser) ? [workerUser] : [];
  }

  /**
   * Returns an Authorization header (base64 encoded "username:password" string) for the specified {@link User}.
   */
  String getAuthorization(User user) {
    Base64.encodeToString("${user.userId}:${user.credentials}".toString().bytes, false);
  }

  private String getRandomString() {
    return new BigInteger(85, random).toString(25);
  }

  void afterPropertiesSet() {

    assert securityEnabled != null, 'securityEnabled is required'
    assert mbaHost, 'mbaHost is required'
    assert mbaName, 'mbaName is required'

    workerUser = new User();
    workerUser.userId = randomString;
    workerUser.credentials = randomString;
    workerUser.displayName = "MBA Worker - ${mbaName}";
    workerUser.email = "no-reply@${mbaHost}"
    workerUser.role = MbaRole.WORKER;

  }

}
