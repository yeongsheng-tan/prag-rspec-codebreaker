package gmrt.mba

import org.testng.Assert
import org.testng.annotations.Test

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 12/18/10
 */
class HostResolverTest {

  @Test
  public void verifyApplianceHostnameDefault() throws Exception {
    def HostResolver resolver = new HostResolver('', HostResolver.BLANK_PORT, 99);
    Assert.assertEquals(resolver.host, InetAddress.localHost.canonicalHostName,
            'Hostname should match InetAddress.localHost.canonicalHostName');
    resolver = new HostResolver(null, HostResolver.BLANK_PORT, 99);
    Assert.assertEquals(resolver.host, InetAddress.localHost.canonicalHostName,
            'Hostname should match InetAddress.localHost.canonicalHostName');
    resolver = new HostResolver(null, 5225, 99);
    Assert.assertEquals(resolver.host,
            "${InetAddress.localHost.canonicalHostName}:5225",
            'Hostname should match InetAddress.localHost.canonicalHostName:5225');
  }

  @Test
  public void verifyApplianceHostNameOverride() throws Exception {
    def expected = 'myHostName.bankofamerica.com'
    def HostResolver resolver = new HostResolver(expected, HostResolver.BLANK_PORT, 99);
    Assert.assertEquals(resolver.host, expected, 'Hostname should match expected value');
    resolver = new HostResolver(expected, 6122, 99);
    Assert.assertEquals(resolver.host, "${expected}:6122", 'Hostname should match expected value + port');
  }

}
