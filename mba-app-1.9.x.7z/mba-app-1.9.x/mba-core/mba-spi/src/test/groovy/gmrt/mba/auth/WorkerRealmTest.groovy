package gmrt.mba.auth

import org.testng.annotations.Test
import org.testng.Assert

import net.sf.ehcache.CacheManager
import javax.servlet.http.HttpServletRequest
import net.sf.ehcache.Cache
import org.testng.annotations.BeforeMethod
import gmrt.da.auth.User
import gmrt.da.util.Base64
import gmrt.da.auth.UserNotFoundException
import gmrt.da.auth.NoCredentialsException

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/8/11
 */
class WorkerRealmTest {

  WorkerRealm realm;

  @BeforeMethod
  void reset() {

    realm = new WorkerRealm();
    realm.securityEnabled = true;
    realm.mbaHost = 'localhost:8018'
    realm.mbaName = 'Test MBA'

    realm.afterPropertiesSet();
  }

  /**
   * You can't exceed passwords of 20 chars in http headers via java due to a base64 problem of some sort.
   */
  @Test
  void checkPasswordLength() {

    User user = realm.workerUser;
    Assert.assertTrue(user.credentials.length() < 20, 'Password length is greater than 20: ' + user.credentials);

  }

  @Test
  void validateAuthentication() {

    User user = realm.workerUser
    String auth = String.valueOf("Basic ${Base64.encodeToString(String.valueOf("${user.getUserId()}:${user.getCredentials()}").bytes, false)}");
    def request = [
            getHeader: {Object[] args ->
              if (args[0] == 'Authorization')
                return auth;
              throw new UnsupportedOperationException();
            },
            getAuthType: {Object[] args -> HttpServletRequest.BASIC_AUTH},
            getRemoteAddr: {'127.0.0.1'},
            getMethod: {'PUT'},
            getRequestURI: {'/deploy/something'}
    ] as HttpServletRequest

    User authenticated;
    (1..10).each {
      authenticated = realm.authenticate(realm.credentials(request));
      Assert.assertEquals(authenticated.role, MbaRole.WORKER, 'Role should be WORKER');
    }

  }

  @Test(expectedExceptions = NoCredentialsException.class)
  void invalidAuthorizeHeader() {

    def request = [
            getHeader: {Object[] args ->
              if (args[0] == 'Authorization')
                return UUID.randomUUID().toString();
              throw new UnsupportedOperationException();
            },
            getAuthType: {Object[] args -> HttpServletRequest.BASIC_AUTH},
            getRemoteAddr: {'127.0.0.1'},
            getMethod: {'PUT'},
            getRequestURI: {'/deploy/something'}
    ] as HttpServletRequest

    realm.authenticate(realm.credentials(request))

  }

  @Test(expectedExceptions = UserNotFoundException.class)
  void userNotFound() {

    realm.getUser(UUID.randomUUID().toString());

  }

}
