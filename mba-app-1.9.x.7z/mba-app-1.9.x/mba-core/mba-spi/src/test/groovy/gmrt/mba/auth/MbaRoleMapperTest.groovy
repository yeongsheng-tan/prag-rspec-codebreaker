package gmrt.mba.auth

import org.testng.annotations.Test
import org.testng.Assert
import gmrt.da.auth.RoleMapper
import gmrt.da.auth.Entitlement

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 12/20/10
 */
class MbaRoleMapperTest {

  RoleMapper mapper = new MbaRoleMapper('SYSTEM_ADMIN_GROUP', ['code-abc','code-lmnop','code-MBS','not-our-group','dont-care-bout-this-one'] as String[]);

  /**
   * Makes sure that group prefixes with spaces in them still work.
   */
  @Test
  void trimGroupName() {
    RoleMapper mapper = new MbaRoleMapper('SYSTEM_ADMIN_GROUP', ['code-abc '] as String[]);
    Assert.assertEquals(mapper.map(trans('code-abc-developers')), MbaRole.DEVELOPER);
  }

  @Test
  void highestRoleSelection() throws Exception {
    Assert.assertEquals(mapper.map(trans('code-abc-developers', 'code-lmnop-collaborators')), MbaRole.DEVELOPER)
  }

  @Test
  void matchWithInvalidGroupInList() throws Exception {
    Assert.assertEquals(mapper.map(trans('invalidGroup', 'code-abc-collaborators')), MbaRole.COLLABORATOR);
  }

  @Test
  void nullWhenNoMatches() throws Exception {
    Assert.assertEquals(mapper.map(trans('code-dre-administrators', 'code-omb-developers', 'code-run-collaborators')), null);
  }

  @Test
  void groupMatchesPatternButNotRoleName() throws Exception {
    Assert.assertEquals(mapper.map(trans('code-UMP-noMatchHere')), null);
  }

  @Test
  void mapsSystemAdminWithOthers() {
    Assert.assertEquals(mapper.map(trans('code-mbs-administrators', 'code-sunrise-collaborators', 'SYSTEM_ADMIN_GROUP', 'code-code-developers')), MbaRole.SYSTEM);
  }

  @Test
  void passthroughToDelegate() {
    Assert.assertEquals(mapper.map(trans('code-mbs-developers', 'code-code-collaborators')), MbaRole.DEVELOPER);
  }

  @Test
  void mapsSystemAdminAlone() {
    Assert.assertEquals(mapper.map(trans('SYSTEM_ADMIN_GROUP')), MbaRole.SYSTEM);
  }

  private Entitlement[] trans(String[] entitlements) {
    entitlements.collect {
      new Entitlement(it, it);
    }
  }
}
