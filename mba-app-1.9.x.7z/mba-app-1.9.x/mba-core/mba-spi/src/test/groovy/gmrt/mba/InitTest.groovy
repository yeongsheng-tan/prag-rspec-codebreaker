package gmrt.mba

import org.testng.annotations.Test

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/22/11
 */
class InitTest {

  @Test
  void getInstance() {

    Appliance app = Appliance.instance;
    println app.auth.user;
    app.close()

  }

}
