package gmrt.mba

import org.testng.annotations.Test

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/9/11
 */
class ApplianceTest {

  @Test
  void applianceInitializesShutsDownInitializesShutsDown() {
    Appliance.instance.close();
    Appliance.instance.close();
  }

}
