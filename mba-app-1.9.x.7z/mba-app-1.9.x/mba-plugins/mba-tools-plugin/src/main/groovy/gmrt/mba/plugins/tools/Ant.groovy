package gmrt.mba.plugins.tools

import hudson.tools.ToolInstallation
import hudson.tools.ToolProperty
import hudson.tasks.Ant.AntInstallation
import hudson.tools.ToolInstaller

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/30/11
 */
class Ant extends MbaToolSupport<AntInstallation, AntInstallation.DescriptorImpl>
                implements MbaTool<hudson.tasks.Ant.AntInstallation.DescriptorImpl, hudson.tasks.Ant.AntInstallation> {

  def final String artifactId = 'ant';
  def final String name = 'Apache Ant';

  protected AntInstallation newToolInstallation(String name, String version, String home, List<ToolProperty<ToolInstallation>> toolProperties) {
    new hudson.tasks.Ant.AntInstallation(name, '', toolProperties);
  }

  /**
   * Returns "apache-ant-${version}"
   */
  protected String getId(String platformId, String version, String location) {
    return "apache-ant-${version}";
  }


}
