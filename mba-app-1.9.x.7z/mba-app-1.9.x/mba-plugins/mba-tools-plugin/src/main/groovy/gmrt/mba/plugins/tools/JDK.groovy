package gmrt.mba.plugins.tools;


import hudson.tools.ToolInstallation
import hudson.tools.ToolProperty
import hudson.model.JDK.DescriptorImpl
import hudson.BulkChange
import hudson.model.Hudson

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/2/11
 */
public class JDK extends MbaToolSupport<hudson.model.JDK, hudson.model.JDK.DescriptorImpl>
                            implements MbaTool<hudson.model.JDK.DescriptorImpl, hudson.model.JDK> {

  def final String artifactId = 'jdk';
  def final String name = 'Java JDK';

  private BulkChange bc;

  protected hudson.model.JDK newToolInstallation(String name, String version, String classifier, List<ToolProperty<ToolInstallation>> toolProperties) {
    new hudson.model.JDK(name, '', toolProperties);
  }

  /**
   * Returns "${version}-${platformId}"
   */
  protected String getId(String platformId, String version, String location) {
    return "${version}-${platformId}";
  }

  /**
   * We implement post to start call {@link Hudson#save()} because it won't automagically save the JDKs when we change
   * them.
   */
  void post(DescriptorImpl toolDescriptor) {
    Hudson.getInstance().save();
  }


}
