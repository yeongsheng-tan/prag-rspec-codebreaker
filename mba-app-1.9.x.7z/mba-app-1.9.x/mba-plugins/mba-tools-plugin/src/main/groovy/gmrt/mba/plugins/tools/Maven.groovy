package gmrt.mba.plugins.tools

import hudson.tools.ToolInstallation
import hudson.tools.ToolProperty
import hudson.tasks.Maven.MavenInstallation
import hudson.tools.ToolInstaller

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/30/11
 */
class Maven extends MbaToolSupport<hudson.tasks.Maven.MavenInstallation, hudson.tasks.Maven.MavenInstallation.DescriptorImpl>
            implements MbaTool<hudson.tasks.Maven.MavenInstallation.DescriptorImpl, hudson.tasks.Maven.MavenInstallation> {

  def final String artifactId = 'mvn';
  def final String name = 'Apache Maven';

  protected MavenInstallation newToolInstallation(String name, String version, String classifier, List<ToolProperty<ToolInstallation>> toolProperties) {
    new hudson.tasks.Maven.MavenInstallation(name, '', toolProperties);
  }

  /**
   * Returns "apache-maven-${version}"
   */
  protected String getId(String platformId, String version, String location) {
    return "apache-maven-${version}";
  }

}
