package gmrt.mba.plugins.tools

import hudson.plugins.mercurial.MercurialInstallation

import hudson.tools.ToolInstallation
import hudson.tools.ToolProperty

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/30/11
 */
class Mercurial extends MbaToolSupport<MercurialInstallation, MercurialInstallation.DescriptorImpl>
                      implements MbaTool<MercurialInstallation.DescriptorImpl, MercurialInstallation> {

  def final String artifactId = 'hg';
  def final String name = 'Selenic Mercurial';

  protected MercurialInstallation newToolInstallation(String name, String version, String home, List<ToolProperty<ToolInstallation>> toolProperties) {
    new MercurialInstallation(name, '', 'INSTALLATION/bin/hg', false, false, false, toolProperties);
  }

  /**
   * Returns "${artifactId}_${classifier}"
   */
  protected String getId(String platformId, String version, String location) {
    return "${artifactId}_${location}"
  }


}
