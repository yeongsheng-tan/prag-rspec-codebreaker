package gmrt.mba.plugins.tools

import org.springframework.beans.factory.InitializingBean
import hudson.tools.ToolDescriptor
import hudson.tools.ToolInstallation
import gmrt.code.builds.plugin.builds.labels.PlatformIdLabelMaker
import gmrt.mba.HostResolver
import java.lang.reflect.ParameterizedType
import java.lang.reflect.Type
import hudson.tools.ToolInstaller

import hudson.tools.ToolProperty
import hudson.tools.InstallSourceProperty
import java.lang.reflect.Array
import org.springframework.beans.factory.annotation.Autowired

/**
 * A foundation for tools that are distributed through the local "mba-tools" repository which is a proxy of the
 * http://repo2.bankofamerica.com/content/repositories/mba-tools/ repository. Also deals with "local" installed
 * tools but only on Linux for now.
 *
 * @see NoCheckUrlDownloadInstaller
 * @see CheckExistsViaCommandInstaller
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 1/31/11
 */
abstract class MbaToolSupport<T extends ToolInstallation, D extends ToolDescriptor<T>> implements InitializingBean {

  @Autowired private HostResolver hostResolver;
  @Autowired private PlatformIdLabelMaker labeler;
  private Map<String, Map<String, String>> installations = new HashMap<String, Map<String, String>>();

  /**
   * Returns the artifactId of the tool, ex: <strong>jdk</strong>. We default _all_ groupIds to
   * <strong>gmrt.mba.tools</strong>.
   */
  abstract String getArtifactId();

  /**
   * A friendly or "display" name fragment for the tool.
   */
  abstract String getName();

  /**
   * Gives sub classes a chance to muck around with the parent descriptor before we start pushing tool installations
   * into it.
   */
  public void pre(D toolDescriptor) {}

  /**
   * And another chance to muck around after we've added the toolinstallations to it.
   */
  public void post(D toolDescriptor) {}

  public T[] getToolInstallations() {

      Map<String, T> installationsByName = new HashMap<String, T>();
      try {
          for (Map.Entry<String, Map<String, String>> byLabelExpr : installations.entrySet()) {
              String labelExpression = cleanLabelExpression(byLabelExpr.getKey());
              for (Map.Entry<String, String> byVersion : byLabelExpr.getValue().entrySet()) {

                  String version = byVersion.getKey();
                  String location = byVersion.getValue();
                  String name = new StringBuilder("[MBA] ").append(getName()).append(" ").append(version).toString();

                  if (!installationsByName.containsKey(name))
                      installationsByName.put(name, newToolInstallation(
                              name,
                              version,
                              location,
                              new LinkedList<ToolProperty<ToolInstallation>>(Arrays.asList(new InstallSourceProperty(Collections.emptyList()))
                              )));

                  InstallSourceProperty prop = installationsByName.get(name).getProperties().get(InstallSourceProperty.class);
                  List<ToolInstaller> installers = new LinkedList<ToolInstaller>(prop.installers.toList());
                  if (location.startsWith("local:")) {
                      installers.add(createLocalInstaller(labelExpression, version, location));
                  } else if (location.startsWith("artifact:")) {
                      installers.add(createDownloadInstaller(labelExpression, version, location));
                  }
                  installationsByName.get(name).getProperties().replace(new InstallSourceProperty(installers));
              }

          }
      } catch (IOException e) {
          throw new RuntimeException("Fatal exception occured preparing tool installer sources", e);
      }

      return installationsByName.values().toArray((T[]) Array.newInstance(getToolInstallationType(), installationsByName.size()));
  }

  /**
   * Constructs a new {@link ToolInstallation} instance for the specified attributes.
   */
  protected abstract T newToolInstallation(String name, String version, String home, List<ToolProperty<ToolInstallation>> toolProperties);

  /**
   * Returns the value of the extracted subdir for the specified artifact. Note that any architecture specific archive
   * must be unique or it could overwrite another archive.
   */
  protected abstract String getId(String labelExpression, String version, String location);

  protected String cleanLocation(String location) {
    return location.substring(location.indexOf(':') + 1);
  }

  protected String cleanLabelExpression(String labelExpression) {
    labelExpression = labelExpression.replaceAll("'", "\"");
    return labelExpression;
  }

  /**
   * Overload to create a download installer implementation. Default returns a {@link NoCheckUrlDownloadInstaller}.
   */
  protected ToolInstaller createDownloadInstaller(String labelExpression, String version, String location) {
      return new NoCheckUrlDownloadInstaller(
              labelExpression,
              getId(labelExpression, version, location),
              getDownloadUrl(labelExpression, version, cleanLocation(location))
      );
  }

  /**
   * Overload to create a local installer implementation. Default returns a {@link CheckExistsViaCommandInstaller}.
   */
  protected ToolInstaller createLocalInstaller(String labelExpression, String version, String location) {
      return new CheckExistsViaCommandInstaller(labelExpression, getToolHome(labelExpression, version, cleanLocation(location)));
  }

  /**
   * Location of the tool home, is used from {@link #createLocalInstaller(String, String, String)}. Some tools you need only
   * point to the directory they're installed in, others (like Git) you actually specify the executable as well.
   * <p/>
   * Default implementation returns "${location}"
   */
  protected String getToolHome(String labelExpression, String version, String location) {
    cleanLocation(location);
  }

  protected String getDownloadUrl(String labelExpression, String version, String location) {
      return new StringBuilder("http://").append(hostResolver.getHost()).append("/").
              append("artifacts/content/repositories/mba-repo2-tools").append(location).toString();
  }

  public Class<D> getToolDescriptorType() {
      Type[] typeArguments = ((ParameterizedType)getClass().getGenericInterfaces()[0]).getActualTypeArguments();
      return (Class)typeArguments[0];
  }

  public Class<T> getToolInstallationType() {
      Type[] typeArguments = ((ParameterizedType)getClass().getGenericInterfaces()[0]).getActualTypeArguments();
      return (Class<T>) typeArguments[1];
  }

  public void setHostResolver(HostResolver hostResolver) {
      this.hostResolver = hostResolver;
  }

  public void setLabeler(PlatformIdLabelMaker labeler) {
      this.labeler = labeler;
  }

  public void setInstallations(Map<String, Map<String, String>> installations) {
      this.installations = installations;
  }

  public void afterPropertiesSet() {
      assert hostResolver, 'hostResolver is required';
      assert labeler, 'labeler is required'
      assert installations, 'installations is required'
  }


}
