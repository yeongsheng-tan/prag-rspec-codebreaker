package gmrt.mba.plugins.tools;

import gmrt.code.builds.plugin.builds.ChmodPlusX;
import hudson.Extension;
import hudson.FilePath;
import hudson.model.Node;
import hudson.model.TaskListener;
import hudson.tasks.*;
import hudson.tools.ToolInstallation;

/**
 * Sets the tool/bin/ant script executable.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/18/11
 */
@Extension
public class AntToolListener extends ToolListener {

    @Override
    public void onInstalled(Node node, ToolInstallation tool, FilePath path, TaskListener listener) {

        if (tool instanceof hudson.tasks.Ant.AntInstallation) {
            FilePath executable = path.child("bin").child("ant");
            listener.getLogger().println("[MBA] Setting +X on " + executable.getRemote() + " ...");
            try {
                executable.act(new ChmodPlusX());
            } catch (Exception e) {
                listener.fatalError("[MBA] Failed setting chmod +X on " + executable.getRemote() + ": %s", e);
            }
        }

    }
}
