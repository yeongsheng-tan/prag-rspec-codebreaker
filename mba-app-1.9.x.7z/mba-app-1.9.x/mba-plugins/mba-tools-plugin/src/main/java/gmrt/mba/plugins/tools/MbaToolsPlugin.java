package gmrt.mba.plugins.tools;

import gmrt.code.builds.plugin.builds.BuildsComputer;
import gmrt.mba.Appliance;
import gmrt.mba.builds.ManagedContext;
import hudson.Extension;
import hudson.Plugin;
import hudson.init.InitMilestone;
import hudson.init.Initializer;
import hudson.model.Action;
import hudson.model.Computer;
import hudson.model.Hudson;
import hudson.tools.*;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.*;

/**
 * Installs all the {@link MbaTool}s we can find in the {@link ManagedContext}
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/3/11
 */
public class MbaToolsPlugin extends Plugin {

    private static Logger LOG = Logger.getLogger(MbaToolsPlugin.class);

    public static transient Map<ToolDescriptor, List<ToolInstallation>> MANAGED_INSTALLS =
            new HashMap<ToolDescriptor, List<ToolInstallation>>();

    /**
     * Adds all the installers we have implemented using {@link MbaTool}.
     */
    @Initializer(after = InitMilestone.JOB_LOADED)
    public static void install() throws IOException {

        LOG.info("Configuring Managed Build tools ...");
        ApplicationContext ctx = Appliance.getInstance().getContext(gmrt.code.builds.plugin.builds.ManagedContext.class, gmrt.mba.plugins.tools.ManagedContext.class);

        for (MbaTool mbtool : (Collection<MbaTool>) ctx.getBeansOfType(MbaTool.class).values()) {

            LOG.info("Installing tool: " + mbtool.getName());

            ToolDescriptor desc = (ToolDescriptor) Hudson.getInstance().getDescriptorByType(mbtool.getToolDescriptorType());
            if (desc == null) {
                LOG.warn("No ToolDescriptor found to match MBA tool installation: " + mbtool.getClass().getName());
                continue;
            }

            mbtool.pre(desc);

            Map<String, ToolInstallation> installs = createToolInstallationMap(mbtool, desc.getInstallations());
            MANAGED_INSTALLS.put(desc, Collections.unmodifiableList(new LinkedList<ToolInstallation>(installs.values())));

            if (LOG.isDebugEnabled()) {
                for (Map.Entry<String, ToolInstallation> entry : installs.entrySet()) {
                    LOG.debug("For version: " + entry.getKey());
                    for (ToolInstaller ti : entry.getValue().getProperties().get(InstallSourceProperty.class).installers) {
                        StringBuilder sb = new StringBuilder("\t").append(StringUtils.rightPad(ti.getLabel(), 20));
                        if (ti instanceof ZipExtractionInstaller)
                            sb.append(((ZipExtractionInstaller)ti).getUrl());
                        else if (ti instanceof CheckExistsViaCommandInstaller)
                            sb.append(((CheckExistsViaCommandInstaller)ti).getToolHome());
                        else
                            sb.append("Unknown installer type: " + ti.getClass());
                        LOG.debug(sb.toString());
                    }
                }
            }

            desc.setInstallations(wrap(mbtool.getToolInstallationType(), installs.values()));

            mbtool.post(desc);
        }

    }

    protected static Map<String, ToolInstallation> createToolInstallationMap(MbaTool mbtool, ToolInstallation[] existingInstalls)
            throws IOException {

        Map<String, ToolInstallation> installs = new HashMap<String, ToolInstallation>();
        for (ToolInstallation existing : existingInstalls) {
            installs.put(existing.getName(), existing);
        }
        for (ToolInstallation ti : mbtool.getToolInstallations()) {
            installs.put(ti.getName(), ti);
        }
        return installs;
    }

    static <T extends ToolInstallation> T[] wrap(Class<T> installationType, Collection<T> installs) {
        T[] empty = (T[]) Array.newInstance(installationType, 0);
        T[] full = new LinkedList<T>(installs).toArray(empty);
        return full;
    }

    /**
     * Adds the {@link ManagedToolsAction} to any {@link BuildsComputer} instances.
     */
    @Extension
    public static class TransientComputerActionFactory extends hudson.model.TransientComputerActionFactory {

        @Override
        public Collection<? extends Action> createFor(Computer target) {

            if (target instanceof BuildsComputer) {
                return Arrays.asList(new ManagedToolsAction((BuildsComputer)target));
            }

            return Collections.emptyList();
        }

    }

}
