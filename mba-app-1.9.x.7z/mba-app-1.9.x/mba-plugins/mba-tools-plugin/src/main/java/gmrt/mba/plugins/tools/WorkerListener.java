package gmrt.mba.plugins.tools;

import hudson.Extension;
import hudson.FilePath;
import hudson.model.Computer;
import hudson.model.TaskListener;
import hudson.slaves.ComputerListener;
import hudson.tools.*;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Creates {@link hudson.tools.ToolLocationNodeProperty.ToolLocation}s for a worker as they comes online by grabbing
 * all our {@link CheckExistsViaCommandInstaller} and (when they exist) adding the tool location to the node.
 * <p/>
 * <strong>This listener is disabled currently as there seems to be no value in pre-registering tool locations on
 * workers at this time.</strong>
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/12/11
 */
//@Extension
public class WorkerListener extends ComputerListener {

    private static Logger LOG = Logger.getLogger(WorkerListener.class);

    @Override
    public void onOnline(Computer c, TaskListener listener) throws IOException, InterruptedException {

        for (Map.Entry<ToolDescriptor, List<ToolInstallation>> entry : MbaToolsPlugin.MANAGED_INSTALLS.entrySet()) {

            for (ToolInstallation ti : entry.getValue()) {

                List<ToolLocationNodeProperty> toolLocations = new LinkedList<ToolLocationNodeProperty>();
                for (InstallSourceProperty isp : ti.getProperties().getAll(InstallSourceProperty.class)) {

                    for (CheckExistsViaCommandInstaller ce : isp.installers.getAll(CheckExistsViaCommandInstaller.class)) {

                        LOG.info("Checking for application of ti " + ti.getName() + " (" + ce.getLabel() + ")");

                        if (ce.appliesTo(c.getNode())) {

                            FilePath home = null;
                            try {
                                home = ce.performInstallation(ti, c.getNode(), listener);
                            } catch (IOException e) {
                                // Command will return status != 0 if not available at location.
                                listener.getLogger().println("[MBA] Location " + ce.getToolHome() + " is not available on this worker ...");
                                continue;
                            }

                            listener.getLogger().println("[MBA] Location " + ce.getToolHome() + " seems to exist, let's add a node property for path: " + home.getRemote());

                            ToolLocationNodeProperty tlnp = new ToolLocationNodeProperty(
                                    new ToolLocationNodeProperty.ToolLocation(entry.getKey(), ti.getName(), home.getRemote()));

                            toolLocations.add(tlnp);

                        } else {

                            listener.getLogger().println("[MBA] This tool installer does not apply to this worker ...");

                        }

                    }

                }

                if (!toolLocations.isEmpty()) {
                    c.getNode().getNodeProperties().addAll(toolLocations);
                }

            }

        }

    }

}
