package gmrt.mba.plugins.tools;

import hudson.tools.ToolDescriptor;
import hudson.tools.ToolInstallation;

import java.io.IOException;

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/30/11
 */
public interface MbaTool<D extends ToolDescriptor<T>, T extends ToolInstallation> {

    /**
     * Returns a name for the tool, ex: <strong>Apache Maven</strong>
     */
    public String getName();

    /**
     * Returns the {@link ToolDescriptor} these {@link ToolInstallation}s are "for".
     */
    public Class<D> getToolDescriptorType();

    /**
     * Returns the {@link ToolInstallation} type
     */
    public Class<T> getToolInstallationType();

    /**
     * Returns an immutable representation of an appliance standard tool installation.
     */
    public T[] getToolInstallations() throws IOException;

    /**
     * Provides a hook for filtering the list of existing tool installations before we set the new ones in.
     */
    public void pre(D toolDescriptor);

    /**
     * Provides a hook for working on the descriptor _after_ we've set the new versions in (to save perhaps?)
     */
    public void post(D toolDescriptor);
}
