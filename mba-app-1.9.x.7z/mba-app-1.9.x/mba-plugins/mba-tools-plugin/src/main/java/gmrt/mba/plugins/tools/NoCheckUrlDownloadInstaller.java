package gmrt.mba.plugins.tools;

import gmrt.code.builds.plugin.builds.BuildsPlugin;
import gmrt.code.builds.plugin.builds.BuildsWorkerAction;
import hudson.*;
import hudson.model.*;
import hudson.tools.*;
import org.kohsuke.stapler.DataBoundConstructor;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.util.List;

/**
 * Because we're proxying tool installer URLs through the local binary repository we can't really "check" for the
 * existence of the URL without causing Nexus to download the whole thing. So we're short circuiting this built-in
 * check with our mba tools. We'll verify their existence in repo2 using a unit test or something.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/7/11
 */
public class NoCheckUrlDownloadInstaller extends ZipExtractionInstaller {

    @Extension
    public static class DescriptorImpl extends ToolInstallerDescriptor<NoCheckUrlDownloadInstaller> {
        @Override
        public String getDisplayName() {
            return ("[MBA] Managed Downloadable Tool");
        }
    }

    final String id;

    @DataBoundConstructor
    public NoCheckUrlDownloadInstaller(String label, String id, String url) {
        super(label, url, id);
        this.id = id;
    }

    @Override
    public FilePath performInstallation(ToolInstallation tool, Node node, TaskListener log)
            throws IOException, InterruptedException {

        BuildsWorkerAction bwa = BuildsWorkerAction.getInstance(node);
        String toolName = tool.getName().replaceAll("[^A-Za-z0-9_.-]+", "_");

        if (bwa.getProperty(toolName + "_path") != null)
            return new FilePath(node.getChannel(), bwa.getProperty(toolName + "_path"));

        FilePath dir = bwa.getTool().child(toolName);

        log.getLogger().println("[MBA] Checking status of managed tool: " + tool.getName());
        boolean ranInstall = dir.installIfNecessaryFrom(new URL(getUrl()), log, "[MBA] Unpacking managed tool " + getUrl() + " to " + dir + " on " + node.getDisplayName());
        dir = findPullUpDirectory(dir);
        bwa.setProperty(toolName + "_path", dir.getRemote());

        if (ranInstall) {
            for (ToolListener listener : ToolListener.all()) {
                listener.onInstalled(node, tool, dir, log);
            }
        }

        return dir;
    }

    public String getId() {
        return id;
    }

    @Override
    public ToolInstallerDescriptor<?> getDescriptor() {
        return new DescriptorImpl();
    }

    /**
     * Borrowed from {@link DownloadFromUrlInstaller} and modified to deal with the .timestamp file that will be present
     * in the top-level tool directory.
     */
    protected FilePath findPullUpDirectory(FilePath root) throws IOException, InterruptedException {

        List<FilePath> children = root.list(new Filter());
        if (children.size() != 1) return root;
        if (children.get(0).isDirectory())
            return children.get(0);

        return root;
    }

    private static class Filter implements FileFilter, Serializable {
        public boolean accept(File pathname) {
            return !".timestamp".equals(pathname.getName());
        }
    }
}
