package gmrt.mba.plugins.tools;

import hudson.Extension;
import hudson.model.Node;
import hudson.model.TaskListener;
import hudson.tools.ToolInstallation;

import java.io.IOException;

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 8/23/11
 */
@Extension
public class LocationTranslator extends hudson.tools.ToolLocationTranslator {

    @Override
    public String getToolHome(Node node, ToolInstallation installation, TaskListener log) throws IOException, InterruptedException {

//        System.out.println("!!!!!!! Looking on " + node.getNodeName() + " for " + installation.getHome());

        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
