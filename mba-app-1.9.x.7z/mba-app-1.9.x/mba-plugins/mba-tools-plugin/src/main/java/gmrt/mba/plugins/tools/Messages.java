package gmrt.mba.plugins.tools;

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/6/11
 */
public class Messages {

    public static String ApplianceInstaller_Install() {
        return "MBA Tools";
    }

}
