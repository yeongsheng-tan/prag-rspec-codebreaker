package gmrt.mba.plugins.tools;

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 2/3/11
 */
public interface ManagedContext extends gmrt.da.ManagedContext {}
