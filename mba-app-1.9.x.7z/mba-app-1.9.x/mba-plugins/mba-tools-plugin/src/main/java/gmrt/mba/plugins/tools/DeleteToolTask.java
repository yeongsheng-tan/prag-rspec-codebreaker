package gmrt.mba.plugins.tools;

import hudson.FilePath;
import hudson.remoting.VirtualChannel;

import java.io.File;
import java.io.IOException;

/**
 * Does nothing more than a recursive {@link java.io.File#delete()}
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/23/11
 */
public class DeleteToolTask implements FilePath.FileCallable<Void> {

    public Void invoke(File f, VirtualChannel channel) throws IOException, InterruptedException {
        process(f);
        return null;
    }

    protected void process(File f) {
        if (f.isDirectory()) {
            for (File child : f.listFiles()) {
                process(child);
            }
        }
        if (!f.delete())
            f.deleteOnExit();
    }

}
