package gmrt.mba.plugins.tools;

import gmrt.code.builds.plugin.builds.BuildsWorkerAction;
import hudson.Extension;
import hudson.FilePath;
import hudson.model.Node;
import hudson.model.TaskListener;
import hudson.tools.ToolInstallation;
import hudson.tools.ToolInstaller;
import hudson.tools.ToolInstallerDescriptor;
import org.kohsuke.stapler.DataBoundConstructor;

import java.io.IOException;

/**
 * Checks the remote worker to see if the specified toolHome exists.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/7/11
 */
public class CheckExistsViaCommandInstaller extends ToolInstaller {

    @Extension
    public static class DescriptorImpl extends ToolInstallerDescriptor<CheckExistsViaCommandInstaller> {

        @Override
        public String getDisplayName() {
            return ("[MBA] Pre-Installed Tool");
        }

    }

    public final String toolHome;

    @DataBoundConstructor
    public CheckExistsViaCommandInstaller(String label, String toolHome) {
        super(label);
        this.toolHome = toolHome;
    }

    /**
     * Overloads to provide an implementation that can handle label expressions rather than parsing the expressions
     * we're using as a single {@link hudson.model.labels.LabelAtom}.
     */
    @Override
    public boolean appliesTo(Node node) {
        return super.appliesTo(node);
    }

    // TODO Add support for Windows workers.
    public FilePath performInstallation(ToolInstallation tool, Node node, TaskListener log) throws IOException, InterruptedException {

        BuildsWorkerAction bwa = BuildsWorkerAction.getInstance(node);
        String toolName = tool.getName().replaceAll("[^A-Za-z0-9_.-]+", "_");

        if (bwa.getProperty(toolName + "_path") != null)
            return new FilePath(node.getChannel(), bwa.getProperty(toolName + "_path"));

        FilePath dir = node.getRootPath();
        FilePath script = dir.createTextTempFile("hudson", ".sh", getCommand(toolHome));
        try {
            String[] cmd = {"sh", "-e", script.getRemote()};

            log.getLogger().println("[MBA] Checking availability of " + tool.getName() + " at " + toolHome);

            int r = node.createLauncher(log).launch().cmds(cmd).stdout(log).pwd(dir).join();
            if (r != 0) {
                log.getLogger().println("[MBA] Failed finding tool at " + toolHome);
                return null;
            }
        } finally {
            script.delete();
        }

        bwa.setProperty(toolName + "_path", toolHome);
        return new FilePath(node.getChannel(), toolHome);
    }

    // TODO Add support for Windows workers.
    protected String getCommand(String toolHome) {
        return new StringBuffer().
                append("if [ -d ").append(toolHome).append(" ]; then\n").
                append("    exit 0\n").
                append("fi\n").append("exit 1").toString();
    }

    public String getToolHome() {
        return toolHome;
    }
}
