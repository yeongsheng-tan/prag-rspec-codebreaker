package gmrt.mba.plugins.tools;

import gmrt.code.builds.plugin.builds.BuildsComputer;
import gmrt.code.builds.plugin.builds.BuildsWorker;
import gmrt.code.builds.plugin.builds.BuildsWorkerAction;
import hudson.FilePath;
import hudson.model.Action;
import hudson.model.DirectoryBrowserSupport;
import hudson.model.Hudson;
import hudson.security.Permission;
import org.kohsuke.stapler.StaplerRequest;
import org.kohsuke.stapler.StaplerResponse;

import javax.servlet.ServletException;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

/**
 * An {@link hudson.model.Action} for managing the tools installed on a node.
 */
public class ManagedToolsAction implements Action {

    public final BuildsComputer parent;

    public ManagedToolsAction(BuildsComputer parent) {
        this.parent = parent;
    }

    /**
     * Lists the tools directory via the channel (assuming the channel is connected, otherwise returns empty)
     */
    public List<String> getInstalledTools() throws IOException, InterruptedException {

        BuildsWorkerAction bwa = BuildsWorkerAction.getInstance(parent);

        List<String> installed = new LinkedList<String>();
        if (bwa.getTool() != null) {
            for (FilePath dir : bwa.getTool().listDirectories()) {
                installed.add(dir.getName());
            }
        }

        return installed;
    }

    /**
     * Deletes a managed tool on the worker.
     */
    public void doDelete(StaplerRequest req, StaplerResponse rsp) throws IOException, ServletException {

        if (!Hudson.getInstance().hasPermission(Hudson.ADMINISTER))
            rsp.sendError(401, "Not authorized");

        BuildsWorkerAction bwa = BuildsWorkerAction.getInstance(parent);

        String toolName = req.getRestOfPath().substring(1);  // Strips off the leading slash in the tool name.
        try {
            bwa.getTool().child(toolName).actAsync(new DeleteToolTask());
        } catch (InterruptedException e) {
            bwa.getListener().error("Exception occured deleting Managed Tool " + toolName + ": " + e.getMessage());
        }

        bwa.setProperty(toolName + "_path", null);

        rsp.forwardToPreviousPage(req);
    }

    /**
     * Uses {@link DirectoryBrowserSupport} to implement browsing of the
     * {@link gmrt.code.builds.plugin.builds.BuildsWorkerAction#getTool()} directory.
     */
    public void doDynamic(StaplerRequest req, StaplerResponse rsp) throws IOException, ServletException {
        BuildsWorkerAction bwa = BuildsWorkerAction.getInstance(parent);
        new DirectoryBrowserSupport(this, bwa.getTool(), "Managed Tools", "folder.gif", true).generateResponse(req,rsp,this);
    }

    public String getIconFileName() {
        return "/plugin/mba-tools-plugin/images/24x24/tools.png";
    }

    public String getDisplayName() {
        return "Managed Tools";
    }

    public String getUrlName() {
        return "managedTools";
    }
}
