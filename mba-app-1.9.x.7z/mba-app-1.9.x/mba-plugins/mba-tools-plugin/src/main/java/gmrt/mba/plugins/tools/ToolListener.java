package gmrt.mba.plugins.tools;

import hudson.ExtensionList;
import hudson.ExtensionPoint;
import hudson.FilePath;
import hudson.model.Hudson;
import hudson.model.Node;
import hudson.model.TaskListener;
import hudson.tools.ToolInstallation;

import java.io.IOException;

/**
 * An {@link ExtensionPoint} that is notified of tool installations that are installed by the
 * {@link NoCheckUrlDownloadInstaller}.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/18/11
 */
public abstract class ToolListener implements ExtensionPoint {

    /**
     * Called when an {@link ToolInstallation} is installed.
     */
    public abstract void onInstalled(Node node, ToolInstallation tool, FilePath path, TaskListener listener)
            throws IOException, InterruptedException;

    public static ExtensionList<ToolListener> all() {
        return Hudson.getInstance().getExtensionList(ToolListener.class);
    }

}
