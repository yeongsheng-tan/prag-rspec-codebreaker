package gmrt.mba.plugins.tools

import gmrt.mba.Appliance
import org.testng.Assert

import org.apache.log4j.Logger
import org.jvnet.hudson.test.HudsonTestCase

import hudson.model.Hudson
import org.testng.annotations.AfterSuite
import org.testng.annotations.BeforeSuite
import org.testng.annotations.Test

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/31/11
 */
class MbaToolLabelsTest {

  private static Logger LOG = Logger.getLogger(MbaToolLabelsTest.class);

  Appliance appliance;

  //@BeforeSuite
  protected void setUp() {
    // Having the master worker deploy causes an issue with the hudson tearDown process :-(
    LOG.info("Disabling the master worker ...");
    System.setProperty("mba.builds.masterWorker.enabled", "false");
    appliance = Appliance.instance;
    appliance.start();
    //super.setUp()
  }

  //@AfterSuite
  protected void tearDown() {
    //super.tearDown()
    Appliance.shutdown();
    System.getProperties().remove("mba.builds.masterWorker.enabled");
    LOG.info("Re-enabling the master worker ...");
  }

  @Test(enabled = false, description = 'Disabled until we get a better test suite setup for the MBA.')
  void testManagedToolLabels() {

    appliance.getContext(gmrt.code.builds.plugin.builds.ManagedContext.class, gmrt.mba.plugins.tools.ManagedContext.class);
    def tools = appliance.getBeans(gmrt.mba.plugins.tools.ManagedContext.class, gmrt.mba.plugins.tools.MbaTool.class);
    Assert.assertNotNull(tools.find { it.class == gmrt.mba.plugins.tools.Ant.class && it.toolInstallations.length })
    Assert.assertNotNull(tools.find { it.class == gmrt.mba.plugins.tools.JDK.class && it.toolInstallations.length })
    Assert.assertNotNull(tools.find { it.class == gmrt.mba.plugins.tools.Maven.class && it.toolInstallations.length })
    Assert.assertNotNull(tools.find { it.class == gmrt.mba.plugins.tools.Mercurial.class && it.toolInstallations.length })
//    Assert.assertNotNull(tools.find { it.class == gmrt.mba.plugins.tools.Git.class && it.toolInstallations.length })

    tools.each { MbaTool tool ->
      tool.toolInstallations.each { installation ->
        println "${installation.name}: ";
        installation.properties.each { tp ->
          tp.installers.each { installer ->
            println "        ${installer.getClass().name}, ${installer.label}"
            def label = Hudson.getInstance().getLabel(installer.label)
            println "        - Label compiles to: ${label} which is a ${label.getClass()}";
          }
        }
      }
    }

  }

}
