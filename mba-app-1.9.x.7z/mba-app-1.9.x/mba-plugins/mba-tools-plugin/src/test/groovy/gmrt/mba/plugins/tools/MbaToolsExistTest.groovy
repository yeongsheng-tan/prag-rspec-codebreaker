package gmrt.mba.plugins.tools

import gmrt.mba.Appliance
import hudson.tools.InstallSourceProperty
import hudson.tools.ToolInstallation
import hudson.tools.ToolInstaller
import org.apache.log4j.Logger
import org.testng.Assert
import org.testng.annotations.AfterSuite
import org.testng.annotations.BeforeSuite
import org.testng.annotations.Test

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 2/13/11
 */
class MbaToolsExistTest {

  private static Logger LOG = Logger.getLogger(MbaToolsExistTest.class);

  Appliance appliance;

  @BeforeSuite
  void setUp() {
    appliance = Appliance.instance;
  }

  @AfterSuite
  void tearDown() {
    Appliance.shutdown();
  }

  @Test
  void remoteManagedToolsExist() {

    appliance.getContext(gmrt.code.builds.plugin.builds.ManagedContext.class, gmrt.mba.plugins.tools.ManagedContext.class);
	  for (MbaTool tool in appliance.getBeans(gmrt.mba.plugins.tools.ManagedContext.class, gmrt.mba.plugins.tools.MbaTool.class)) {
		  new MbaToolsPlugin().createToolInstallationMap(tool, [] as ToolInstallation[]).each { java.lang.String name, ToolInstallation install ->
			  install.getProperties().each { InstallSourceProperty prop ->
				  prop.installers.each { ToolInstaller toolInstaller ->
					  if (toolInstaller instanceof NoCheckUrlDownloadInstaller) {
						  NoCheckUrlDownloadInstaller dlInstaller = (NoCheckUrlDownloadInstaller) toolInstaller;
						  println "${name.padRight(32)} (${dlInstaller.label.padRight(20)}) ${dlInstaller.id.padRight(10)} ${dlInstaller.url}"

						  def localUrl = dlInstaller.url.toURL();

						  // We're mangling our "local" url into the matching repo2 url here.
						  //def repo2Url = "${localUrl.toString().replace(localUrl.host, 'repo2.bankofamerica.com').replace("${localUrl.port}", '80').replace('/artifacts','').replace('mba-repo2-tools', 'mba-tools')}"
						  def repo2Url = "${localUrl.toString().replace(localUrl.host, 'nysmba001.usnyctd.amrs.bankofamerica.com').replace("${localUrl.port}", '8000').replace('mba-repo2-tools', 'mba-tools')}"

						  LOG.info("Validating http 200 on url: ${repo2Url}");

						  URLConnection conn = repo2Url.toURL().openConnection();
						  conn.connect();
						  Assert.assertEquals(conn.getResponseCode(), java.net.HttpURLConnection.HTTP_OK, "Failed on ${repo2Url}");

					  } else if (toolInstaller instanceof CheckExistsViaCommandInstaller) {
						  CheckExistsViaCommandInstaller cmdToolInstaller = (CheckExistsViaCommandInstaller) toolInstaller;
						  println "${name.padRight(32)} (${cmdToolInstaller.label.padRight(20)}) ${cmdToolInstaller.toolHome}"
					  }
				  }
			  }
		  }
	  }

  }

}
