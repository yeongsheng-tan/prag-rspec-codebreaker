package gmrt.mba.plugins.sshtunnel;

import com.trilead.ssh2.Connection;
import hudson.AbortException;
import hudson.Extension;
import hudson.Launcher;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.tasks.BuildWrapper;
import hudson.tasks.BuildWrapperDescriptor;
import org.kohsuke.putty.PuTTYKey;
import org.kohsuke.stapler.DataBoundConstructor;

import java.io.File;
import java.io.IOException;

/**
 * Opens an SSH tunnel during a build. This is equivalent to running a command like:
 * <pre><code>
 *     ssh -f -N -L 3307:localhost:3307 server.chp.bankofamerica.com
 * </code></pre>
 * With port 3307 on your MBA master being a tunnel to port 3307 on the remote machine. Future versions of this plugin
 * will enable tunneling from a slave to another or perhaps just allowing slaves to tunnel through the MBA master.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 4/28/11
 */
public class SSHTunnelBuildWrapper extends BuildWrapper {

    @Extension
    public static class DescriptorImpl extends BuildWrapperDescriptor {

        @Override
        public boolean isApplicable(AbstractProject<?, ?> item) {
            return true;
        }

        @Override
        public String getDisplayName() {
            return "Open an SSH tunnel during this build";
        }
    }

    private transient Connection connection;

    public final String username;
    public final String host;
    public final int port;
    public final String keyPath;
    public final int localPort;
    public final int remotePort;

    @DataBoundConstructor
    public SSHTunnelBuildWrapper(String username, String host, int port, String keyPath, int localPort, int remotePort) {
        this.username = username;
        this.host = host;
        this.port = port;
        this.keyPath = keyPath;
        this.localPort = localPort;
        this.remotePort = remotePort;
    }

    @Override
    public Environment setUp(AbstractBuild build, Launcher launcher, BuildListener listener) throws IOException, InterruptedException {

        listener.getLogger().println("[MBA] Opening SSH tunnel on port " + localPort + " to " + host + ":" + remotePort);

        connection = new Connection(host, port);

        File key = new File(keyPath);
        if (!key.exists())
            throw new AbortException("[MBA] Failed creating SSH tunnel, no public key found at " + keyPath);

        try {
            connection.connect();

            listener.getLogger().println("[MBA] Authenticating using key: " + key.getAbsolutePath());
            boolean isAuthenticated = false;
            if (PuTTYKey.isPuTTYKeyFile(key)) {
                String puttyKey = new PuTTYKey(key, null).toOpenSSH();
                isAuthenticated = connection.authenticateWithPublicKey(username, puttyKey.toCharArray(), null);
            } else {
                isAuthenticated = connection.authenticateWithPublicKey(username, key, null);
            }

            if (!isAuthenticated)
                throw new AbortException("[MBA] Could not authenticate with remote host ...");

            listener.getLogger().println("[MBA] Creating port forwarder ...");
            connection.createLocalPortForwarder(localPort, "localhost", remotePort);

        } catch (Throwable e) {
            connection.close();
            connection = null;
            throw new AbortException("[MBA] Fatal exception opening SSH tunnel to host " + host + ": " + e);
        }

        return new Environment() {

            @Override
            public boolean tearDown(AbstractBuild build, BuildListener listener) throws IOException, InterruptedException {

                if (connection != null) {
                    listener.getLogger().println("[MBA] Closing SSH tunnel to host " + host);
                    connection.close();
                    connection = null;
                }

                return true;
            }
        };
    }

}
