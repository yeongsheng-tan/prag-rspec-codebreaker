package gmrt.mba.plugins.dispatcher;

import gmrt.mba.Appliance;
import gmrt.mba.HostResolver;
import org.junit.Test;
import java.net.URI;

import static org.junit.Assert.*;


/**
 * Created by IntelliJ IDEA.
 * User: nbk1qeu
 * Date: 12/5/11
 * Time: 4:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class DispatcherFactoryTest {

    @Test
    public void testCreationOfFactory(){
        DispatcherFactory dispatcherFactory = new ConcreteManagementDispatcher();

        Dispatcher dispatcher = dispatcherFactory.FactoryMethod();

        assertNotNull(dispatcher);
        ConcreteDispatcher concreteDispatcher = new ConcreteDispatcher();
        assertEquals(concreteDispatcher.getClass(), dispatcher.getClass());
    }

    @Test
    public void testDispatcherUri(){
        DispatcherFactory dispatcherFactory = new ConcreteManagementDispatcher();
        Dispatcher dispatcher = dispatcherFactory.FactoryMethod();

        dispatcherFactory.queryStringLabelOS = "test_label";

        dispatcher.Initialize(
                dispatcherFactory.labelOS,
                dispatcherFactory.jnlpUrl,
                dispatcherFactory.slaveJarUrl,
                dispatcherFactory.queryStringLabelOS
        );

        URI uri = dispatcher.createUri();

        HostResolver hostResolver = Appliance.getInstance().getBean(Appliance.class, HostResolver.class);
        //http://B78E7D1CC214E.corp.bankofamerica.com:8019/builds/job/dedicated_linux_job/buildWithParameters?token=P90X&JnlpUrl=null&delay=10&SlaveJarUrl=http://B78E7D1CC214E.corp.bankofamerica.com:8019
        assertEquals(
                uri.toString(),
                String.format(
                        "http://%s/builds/job/dedicated_job_test_label/buildWithParameters?token=P90X&JnlpUrl=null&delay=0&SlaveJarUrl=http://%s",
                        hostResolver.getHost(),
                        hostResolver.getHost()));
    }

}
