package gmrt.mba.plugins.dispatcher;

import gmrt.mba.Appliance;
import gmrt.mba.HostResolver;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.kohsuke.stapler.StaplerRequest;
import org.kohsuke.stapler.StaplerResponse;

import javax.servlet.ServletException;
import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import org.apache.log4j.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: nbk1qeu
 * Date: 12/5/11
 * Time: 4:05 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class Dispatcher {

    protected static final Logger LOGGER = Logger.getLogger(Dispatcher.class);

    public abstract void Initialize(
            WorkerTypes labelOS,
            String jnlpUrl,
            String slaveJarUrl,
            String queryStringLabelOS);

    protected String JOB_NAME_PREFIX;
    protected String TOKEN_NAME = "P90X";
    protected static final String LABELOS_REQUEST = "labelOS";
    protected static final String JNLP_URL_REQUEST = "JnlpUrl";
    protected static final String SlaveJarUrl_Request = "SlaveJarUrl";
    protected WorkerTypes LabelOS;
    protected String QueryStringLabelOS;
    protected String JnlpUrl;
    protected String SlaveJarUrl;

    public URI createUri()
    {
        LOGGER.info("Creating Uri to execute.");
        //See here for more on parameterized jobs:
        //https://wiki.jenkins-ci.org/display/JENKINS/Parameterized+Build

        try{
            HostResolver hostResolver = Appliance.getInstance().getBean(Appliance.class, HostResolver.class);
            String splitHostname = hostResolver.getHost().split(":")[0];
            int port = hostResolver.getPort();
            SlaveJarUrl = "http://"+splitHostname+":"+port;

            String urlPath = String.format(
                    "/builds/job/%s/buildWithParameters",
                    JOB_NAME_PREFIX
            );

            String urlQuery = String.format(
                    "token=%s&%s=%s&delay=0&%s=%s",
                    TOKEN_NAME,
                    JNLP_URL_REQUEST,
                    JnlpUrl,
                    SlaveJarUrl_Request,
                    SlaveJarUrl
            );

            URI UriToExecute = new URI(
                    "http", null, splitHostname,
                    port,
                    urlPath,
                    urlQuery, null);

            return UriToExecute;


        } catch (URISyntaxException use) {
            LOGGER.error("URI syntax exception: " + use.getMessage());
            throw new RuntimeException("URI syntax exception: " + use.getMessage());
        }
    }//public URI createUri()

    public void executeJob(URI jobExecuteUri)
        throws IOException
    {
        LOGGER.info("Executing the dispatcher job.");

        HttpGet executeJobRequest = new HttpGet(jobExecuteUri);
        HttpClient httpClient = new DefaultHttpClient();
        HttpResponse response = httpClient.execute(executeJobRequest);
        if (response.getStatusLine().getStatusCode() == 200) {
            LOGGER.info("Successfully executed the dispatcher job: " + jobExecuteUri.toURL());
        } else {
            LOGGER.info("Failed to execute the dispatcher job: " + jobExecuteUri.toURL());
            throw new RuntimeException("Failed to execute the dispatcher job " + jobExecuteUri.toURL());
        }
    }//public boolean executeJob

    public void doProvision(StaplerRequest req, StaplerResponse rsp)
            throws ServletException, IOException
    {
        LOGGER.info("Provisioning Worker.");
        executeJob(createUri());
    }
}
