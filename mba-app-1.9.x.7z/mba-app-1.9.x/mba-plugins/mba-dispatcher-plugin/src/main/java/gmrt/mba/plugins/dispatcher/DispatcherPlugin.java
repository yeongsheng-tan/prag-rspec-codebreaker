package gmrt.mba.plugins.dispatcher;

import hudson.Extension;
import hudson.Plugin;
import org.kohsuke.stapler.StaplerRequest;
import org.kohsuke.stapler.StaplerResponse;

import javax.servlet.ServletException;
import java.io.*;
import org.apache.log4j.Logger;


/**
 * Widget the displays boxes in the left margin providing details on the connected Managed Build Clouds.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 13, 2010
 */
@Extension
public class DispatcherPlugin extends Plugin {

    private static final Logger LOGGER = Logger.getLogger(DispatcherPlugin.class);

    public DispatcherPlugin() {}

    public void doProvision(StaplerRequest req, StaplerResponse rsp)
            throws ServletException, IOException
    {
        LOGGER.info("Received request to provision a worker from " + req.getRemoteHost());

        DispatcherFactory dispatcherFactory = new ConcreteManagementDispatcher();
        Dispatcher dispatcher = dispatcherFactory.FactoryMethod(
                req);

        dispatcher.Initialize(
                dispatcherFactory.labelOS,
                dispatcherFactory.jnlpUrl,
                dispatcherFactory.slaveJarUrl,
                dispatcherFactory.queryStringLabelOS
        );

        dispatcher.doProvision(req, rsp);
    }
}
