package gmrt.mba.plugins.dispatcher;

import org.apache.log4j.Logger;
import org.kohsuke.stapler.StaplerRequest;

/**
 * Created by IntelliJ IDEA.
 * User: nbk1qeu
 * Date: 12/5/11
 * Time: 4:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class ConcreteManagementDispatcher extends DispatcherFactory {

    protected static final Logger LOGGER = Logger.getLogger(Dispatcher.class);

    @Override
    public Dispatcher FactoryMethod(StaplerRequest req) {
        LOGGER.info(String.format("ConcreteManagementDispatcher.FactoryMethod, return Concrete from FactoryMethod for query string."));
        if (GetRequest(req)) {
            LOGGER.info(String.format("Setting up FactoryMethod from StaplerRequest for %s ", labelOS));
            return new ConcreteDispatcher();
        }//if (GetRequest(req)){

        return null;
    }//public Dispatcher FactoryMethod(StaplerRequest req)

    @Override
    public Dispatcher FactoryMethod() {
        LOGGER.info(String.format("ConcreteManagementDispatcher.FactoryMethod, return Concrete."));
        return new ConcreteDispatcher();
    }//public Dispatcher FactoryMethod(StaplerRequest req)

    private boolean GetRequest(StaplerRequest req) {
        LOGGER.info(String.format("Checking request for %s and %s ",
                Dispatcher.JNLP_URL_REQUEST, Dispatcher.LABELOS_REQUEST));

        boolean returnValue = false;

        if (req.hasParameter(Dispatcher.JNLP_URL_REQUEST) &&
                req.hasParameter(Dispatcher.LABELOS_REQUEST)) {

            jnlpUrl = req.getParameter(Dispatcher.JNLP_URL_REQUEST);
            labelOS = convertToWorkerTypes(
                    req.getParameter(Dispatcher.LABELOS_REQUEST));
            queryStringLabelOS = req.getParameter(Dispatcher.LABELOS_REQUEST);

            LOGGER.info(String.format("Request values %s= %s, %s= %s ",
                    Dispatcher.JNLP_URL_REQUEST,
                    jnlpUrl,
                    Dispatcher.LABELOS_REQUEST,
                    labelOS));

            returnValue = true;
        }

        return returnValue;
    }//private boolean GetRequest(StaplerRequest req)

    protected WorkerTypes convertToWorkerTypes(String workerTypes) {

        if (WorkerTypes.forName(workerTypes) == null) {
            return WorkerTypes.custom;
        } else {
            return Enum.valueOf(WorkerTypes.class, workerTypes.toLowerCase());
        }
    }
}
