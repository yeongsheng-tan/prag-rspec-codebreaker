package gmrt.mba.plugins.dispatcher;

/**
 * Created by IntelliJ IDEA.
 * User: nbk1qeu
 * Date: 12/5/11
 * Time: 5:57 PM
 * To change this template use File | Settings | File Templates.
 */
public enum WorkerTypes {
    custom;

    private static final WorkerTypes[] copyOfValues = values();

    public static WorkerTypes forName(String name) {
        for (WorkerTypes value : copyOfValues) {
            if (value.name().equals(name)) {
                return value;
            }
        }
        return null;
    }
}
