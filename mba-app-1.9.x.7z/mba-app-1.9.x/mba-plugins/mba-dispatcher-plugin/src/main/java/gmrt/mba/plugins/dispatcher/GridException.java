package gmrt.mba.plugins.dispatcher;

public class GridException extends Exception
{

	public GridException() {
		super();
	}

	public GridException(String message) {
		super(message);
	}

	public GridException(String message, Throwable cause) {
		super(message, cause);
	}

}
