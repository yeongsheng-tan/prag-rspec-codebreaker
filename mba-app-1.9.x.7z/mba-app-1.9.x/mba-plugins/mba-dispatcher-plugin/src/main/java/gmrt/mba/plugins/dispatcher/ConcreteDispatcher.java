package gmrt.mba.plugins.dispatcher;

/**
 * Created by IntelliJ IDEA.
 * User: nbk1qeu
 * Date: 1/18/12
 * Time: 11:37 AM
 * To change this template use File | Settings | File Templates.
 */
public class ConcreteDispatcher extends Dispatcher{

    @Override
    public void Initialize(
            WorkerTypes labelOS,
            String jnlpUrl,
            String slaveJarUrl,
            String queryStringLabelOS)
    {
        this.LabelOS = labelOS;
        this.JnlpUrl = jnlpUrl;
        this.SlaveJarUrl = slaveJarUrl;
        this.QueryStringLabelOS = queryStringLabelOS;

        JOB_NAME_PREFIX = "dedicated_job_" + this.QueryStringLabelOS;
    }

}
