package gmrt.mba.plugins.dispatcher;

import org.kohsuke.stapler.StaplerRequest;

/**
 * Created by IntelliJ IDEA.
 * User: nbk1qeu
 * Date: 12/5/11
 * Time: 4:16 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class DispatcherFactory {

    public abstract Dispatcher FactoryMethod(StaplerRequest req);
    public abstract Dispatcher FactoryMethod();

    public WorkerTypes labelOS;
    public String jnlpUrl;
    public String slaveJarUrl;
    public String queryStringLabelOS;
}
