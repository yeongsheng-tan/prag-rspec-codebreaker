package gmrt.bhive.plugins.bhive.artifacts

import org.sonatype.aether.artifact.ArtifactType
import org.sonatype.aether.util.artifact.DefaultArtifactType

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/31/11
 */
class DefaultPromotable implements Promotable {

  def final String groupId;
  def final String artifactId;
  def final String version;
  def final ArtifactType type;
  def final Promotable pom;
  private List<Promotable> attached = [];

  /**
   * Defaults the extension to 'jar' to mirror typical Maven patterns.
   */
  DefaultPromotable(String groupId, String artifactId, String version) {
    this(groupId, artifactId, version, 'jar');
  }

  DefaultPromotable(String groupId, String artifactId, String version, String type, String classifier) {
    this(groupId, artifactId, version, new DefaultArtifactType(type, null, classifier, null));
  }

  /**
   * When extension != 'pom' will create a new artifact for {@link #getPom()} matching this but with a 'pom' extension.
   */
  DefaultPromotable(String groupId, String artifactId, String version, ArtifactType type) {

    this.groupId = groupId;
    this.artifactId = artifactId;
    this.version = version;
    this.type = type;

    if (type.id != 'pom')
      pom = new DefaultPromotable(groupId, artifactId, version, 'pom', null);
    else
      pom = this;
  }

  DefaultPromotable(Promotable main, ArtifactType type) {
    this(main.groupId, main.artifactId, main.version, type);
  }

  void attach(ArtifactType type) {
    attached << new DefaultPromotable(this, type);
  }

  Promotable[] getAttached() {
    attached as Promotable[];
  }


}
