package gmrt.mba.builds.plugin.artifacts

import org.apache.maven.wagon.events.TransferEvent
import org.apache.maven.wagon.WagonConstants
import java.text.NumberFormat

/**
 * A basic listener that kicks the status out to a {@link PrintStream}. Haven't tested it out with anything but
 * {@link System#out} yet so not sure it will actually work with a Jenkins {@link hudson.model.TaskListener}
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 9/3/11
 */
class TransferListener implements org.apache.maven.wagon.events.TransferListener {

  final NumberFormat nf = NumberFormat.instance
  final PrintStream out;

  private long complete;

  TransferListener(PrintStream out) {
    this.out = out
  }

  public void transferInitiated(TransferEvent e) {
    out.println("${(e.getRequestType() == TransferEvent.REQUEST_PUT) ? 'Uploading' : 'Downloading'}: ${e.wagon.repository.url}/${e.getResource().getName()}");
    complete = 0;
  }

  public void transferStarted(TransferEvent transferEvent) {}

  public void transferProgress(TransferEvent e, byte[] buffer, int length) {
    complete += length;
    if (e.resource.contentLength >= 1024) {
      out.print(nf.format(Math.floor(complete / 1024)) + "/" + (e.resource.contentLength == WagonConstants.UNKNOWN_LENGTH ? "?" : nf.format(Math.floor(e.resource.contentLength / 1024)) + "K") + "\r");
    } else
      out.print(nf.format(Math.floor(complete)) + "/" + (e.resource.contentLength == WagonConstants.UNKNOWN_LENGTH ? "?" : nf.format(Math.floor(e.resource.contentLength)) + "b") + "\r");
  }

  public void transferCompleted(TransferEvent e) {
    long contentLength = Math.floor(e.resource.contentLength);
    if (contentLength != WagonConstants.UNKNOWN_LENGTH) {
      String type = (e.requestType == TransferEvent.REQUEST_PUT ? "uploaded" : "downloaded");
      String l = contentLength >= 1024 ? nf.format(Math.floor(contentLength / 1024)) + "K" : nf.format(Math.floor(contentLength)) + "b";
      out.println(l + " " + type);
    }
  }

  public void transferError(TransferEvent e) {
    e.exception.printStackTrace(out);
  }

  public void debug(String message) {}

}
