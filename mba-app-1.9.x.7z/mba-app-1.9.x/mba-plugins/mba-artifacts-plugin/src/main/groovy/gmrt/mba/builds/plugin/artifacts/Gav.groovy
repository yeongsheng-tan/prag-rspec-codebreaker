package gmrt.mba.builds.plugin.artifacts

import org.sonatype.aether.util.version.GenericVersionScheme
import org.sonatype.aether.version.Version
import org.sonatype.aether.version.VersionScheme

/**
 * Represents the unique-ness of an artifact group and version. Acts as a factory for {@link Coords} instances which
 * are more specific and can be used to actually resolve an artifact.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 9/3/11
 */
class Gav extends Ga implements Comparable {

  private static VersionScheme gvs = new GenericVersionScheme();

  final String version;

  /**
   * "{@link #groupId}:{@link #artifactId}:{@link #version}"
   */
  final String gav;

  final String name;
  final String description;
  final boolean hasSources;
  final boolean hasDocs;
  final boolean hasSignature;

  private final Version v;

  Gav(String groupId, String artifactId, String version) {
    this(groupId, artifactId, version, null, null, false, false, false);
  }

  Gav(String groupId, String artifactId, String version, String name, String description, boolean hasSources, boolean hasDocs, boolean hasSignature) {
    super(groupId, artifactId)
    this.version = version
    this.name = name
    this.description = description
    this.hasSources = hasSources
    this.hasDocs = hasDocs
    this.hasSignature = hasSignature

    this.gav = "${groupId}:${artifactId}:${version}"
    this.v = gvs.parseVersion(version);
  }

  Ga widen() {
    new Ga(groupId, artifactId)
  }

  Coords narrow(String type, String classifier) {
    new Coords(groupId, artifactId, version, type, classifier)
  }

  /**
   * First compares against the {@link #ga} fragment. If those match (i.e. it's the same artifact) then we'll compare
   * {@link #version} using {@link org.sonatype.aether.util.version.GenericVersion}
   */
  int compareTo(Object o) {

    def c = super.compareTo(o);
    if (c != 0)
      return c;

    return this.v.compareTo(o.v);
  }

  String toString() {
    gav
  }

  boolean equals(o) {
    if (this.is(o)) return true;
    if (!(o instanceof Gav)) return false;
    if (!super.equals(o)) return false;

    Gav gav1 = (Gav) o;

    if (gav != gav1.gav) return false;

    return true;
  }

  int hashCode() {
    int result = super.hashCode();
    result = 31 * result + gav.hashCode();
    return result;
  }
}
