package gmrt.bhive.plugins.bhive.artifacts

import gmrt.da.auth.User
import groovyx.net.http.RESTClient
import net.sf.json.JSON
import org.apache.maven.repository.internal.DefaultServiceLocator
import org.apache.maven.repository.internal.MavenRepositorySystemSession
import org.sonatype.aether.RepositorySystem
import org.sonatype.aether.RepositorySystemSession
import org.sonatype.aether.artifact.Artifact
import org.sonatype.aether.connector.file.FileRepositoryConnectorFactory
import org.sonatype.aether.connector.wagon.WagonProvider
import org.sonatype.aether.connector.wagon.WagonRepositoryConnectorFactory
import org.sonatype.aether.deployment.DeployRequest
import org.sonatype.aether.graph.Dependency
import org.sonatype.aether.repository.Authentication
import org.sonatype.aether.repository.LocalRepository
import org.sonatype.aether.repository.RemoteRepository
import org.sonatype.aether.resolution.ArtifactDescriptorRequest
import org.sonatype.aether.resolution.ArtifactDescriptorResult
import org.sonatype.aether.resolution.ArtifactRequest
import org.sonatype.aether.resolution.ArtifactResult
import org.sonatype.aether.spi.connector.RepositoryConnectorFactory
import org.sonatype.aether.util.artifact.DefaultArtifact
import org.sonatype.aether.util.artifact.SubArtifact

/**
 * Uses the Sonatype Aether API to perform various operations against a Nexus repository.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 1/31/11
 */
class ArtifactsLogic {

  public static final String MBA_ARTIFACTS_SNAPSHOTS_ID = "repositories/mba-snapshots";
  public static final String MBA_ARTIFACTS_RELEASES_ID = "repositories/mba-releases";
  public static final String MBA_ARTIFACTS_GROUP_ID = "groups/mba-group";
  public static final String MBA_ARTIFACTS_TOOLS_ID = "repositories/mba-repo2-tools";
  public static final String MBA_ARTIFACTS_BACKUP_ID = "repositories/mba-backup";

  private final File localRepo;
  private final String applianceHost;

  private transient RepositorySystem system;
  private transient MavenRepositorySystemSession session;

  private PrintStream out;
  /**
   * @param localPath Local repository location, temporarily used to resolve remote artifacts
   * @param applianceHost Appliance host as returned by {@link gmrt.mba.HostResolver#getHost()}, should include
   * hostname and port.
   */
  ArtifactsLogic(File localRepo, String applianceHost, PrintStream out) {
    this.localRepo = localRepo;
    this.applianceHost = applianceHost;

    this.system = newRepositorySystem();
    this.session = newRepositorySession(system, localRepo);

    session.setTransferListener(new TransferListener(out));
    session.setRepositoryListener(new RepositoryListener(out));
  }

  /**
   * Finds a list of artifacts using the specified criteria as a standard Nexus "GAV Search" where wildcards are valid.
   *
   * @deprecated See {@link gmrt.mba.builds.plugin.artifacts.Repository#find}.
   */
  public Set<Artifact> find(String mbaRepositoryId, String groupId, String artifactId, String version,
                            String packaging, String classifier) {
    def url = "http://${applianceHost}/artifacts/service/local/data_index/${mbaRepositoryId}/content?";
    if (groupId)
      url = "${url}g=${groupId}&"
    if (artifactId)
      url = "${url}a=${artifactId}&"
    if (version)
      url = "${url}v=${version}&"
    if (packaging)
      url = "${url}p=${packaging}&"
    if (classifier)
      url = "${url}c=${classifier}&"
    url = "${url}collapseResults=true"

    def results = new XmlParser().parseText(url.toURL().text);

    if (Boolean.valueOf(results.tooManyResults.text()))
      throw new TooManyResultsException();

    Set<Artifact> artifacts = new HashSet<Artifact>();
    results.data.artifact.each {
      artifacts << new DefaultArtifact("${it.groupId.text()}:${it.artifactId.text()}:${it.version.text()}");
    }
    artifacts;
  }

  /**
   * Promotes a {@link Promotable} by resolving it against the local repository, then deploying it to the remote
   * one.
   *
   * @deprecated Check out the {@link gmrt.mba.builds.plugin.artifacts.Promoter} as it's much more capable than this
   */
  public void promote(User worker, Promotable main) {

    //def mbaRepositoryId = main.version.endsWith('SNAPSHOT') ? MBA_ARTIFACTS_SNAPSHOTS_ID : MBA_ARTIFACTS_RELEASES_ID
	def mbaRepositoryId = getMatchingMbaRepositoryByArtifactType(main)
    List<Artifact> toDeploy = [];

    Artifact mainArtifact = resolveLocalArtifact(
            new DefaultArtifact(main.groupId, main.artifactId, null, null, main.version, main.type));
    toDeploy << mainArtifact;

    main.attached.each {
      Artifact attArtifact = resolveLocalArtifact(
              new DefaultArtifact(it.groupId, it.artifactId, null, null, it.version, it.type));
      toDeploy << attArtifact;
    }

    // For some reason I'm thinking it's better to deploy the pom last as sort of a transactional thing.. Could be
    // pointless but seems right.
    if (main.type.id != 'pom') {
      toDeploy << getPom(mbaRepositoryId, mainArtifact);
    }

    RemoteRepository repository = getMbaRepository(mbaRepositoryId);
    repository.setAuthentication(new Authentication(worker.userId, worker.credentials.toString()));
    DeployRequest deploy = new DeployRequest();
    deploy.setRepository(repository);
    toDeploy.each {
      deploy.addArtifact(it)
    }

    system.deploy(session, deploy);

  }

  /**
   * We "keep it local" by not providing the remote repository to the resolver.
   */
  public Artifact resolveLocalArtifact(Artifact artifact) {
    ArtifactRequest ar = new ArtifactRequest();
    ar.setArtifact(artifact)
    ArtifactResult result = system.resolveArtifact(session, ar);
    if (!result.isResolved())
      throw new IllegalArgumentException("Failed to resolve artifact (${artifact}) in ${localRepo}");
    return result.artifact;
  }

  /**
   * Resolves an artifact using the specified mba repository id.
   *
   * @param mbaRepositoryId Should be one of the constants here like {@link #MBA_ARTIFACTS_RELEASES_ID} but it's not
   * locked down to allow you to reference other groups or repos of the appliance.
   *
   * @deprecated See {@link gmrt.mba.builds.plugin.artifacts.Repository#resolve}
   */
  public Artifact resolveArtifact(String mbaRepositoryId, Artifact artifact) {
    ArtifactRequest ar = new ArtifactRequest();
    ar.setArtifact(artifact)
    ar.setRepositories([getMbaRepository(mbaRepositoryId)]);
    ArtifactResult result = system.resolveArtifact(session, ar);
    if (!result.isResolved())
      throw new IllegalArgumentException("Failed to resolve artifact (${artifact}) in ${getMbaRepository(mbaRepositoryId)}");
    return result.artifact;
  }

  /**
   * Lists the immediate dependencies of an artifact
   */
  public Set<Dependency> getDependencies(String mbaRepositoryId, Artifact artifact) {
    ArtifactDescriptorResult adr = system.readArtifactDescriptor(session,
            new ArtifactDescriptorRequest(artifact, [getMbaRepository(mbaRepositoryId)], null));
    adr.dependencies.unique();
  }

  /**
   * Resolves the pom for the specified artifact
   */
  public Artifact getPom(String mbaRepositoryId, Artifact artifact) {
    resolveArtifact(mbaRepositoryId, new SubArtifact(artifact, null, 'pom').setVersion(artifact.baseVersion));
  }

  private RemoteRepository getMbaRepository(String mbaRepositoryId) {
    String url = "http://${applianceHost}/artifacts/content/${mbaRepositoryId}";
    new RemoteRepository(mbaRepositoryId, 'default', url);
  }

  private RepositorySystem newRepositorySystem() {
    DefaultServiceLocator locator = new DefaultServiceLocator();
    locator.addService(RepositoryConnectorFactory.class, FileRepositoryConnectorFactory.class);
    locator.addService(RepositoryConnectorFactory.class, WagonRepositoryConnectorFactory.class);
    locator.setServices(WagonProvider.class, [
            lookup: { new PreEmpAuthWagon() },
            release: {}
    ] as WagonProvider);
    return locator.getService(RepositorySystem.class);
  }

  private RepositorySystemSession newRepositorySession(RepositorySystem repositorySystem, File localRepo) {
    MavenRepositorySystemSession session = new MavenRepositorySystemSession();
    LocalRepository localRepository = new LocalRepository(localRepo);
    session.setLocalRepositoryManager(repositorySystem.newLocalRepositoryManager(localRepository));
    return session;
  }

  private String getMatchingMbaRepositoryByArtifactType(Promotable p){
	  if(p.version.endsWith('SNAPSHOT')){
	    return MBA_ARTIFACTS_SNAPSHOTS_ID
      }else if(p.artifactId.startsWith('mba-backup')){
		return MBA_ARTIFACTS_BACKUP_ID
	  }else{
		return MBA_ARTIFACTS_RELEASES_ID
	  }
  }

	private RESTClient getArtifactsRestEndpoint(){
		def artRestClient = new RESTClient('http://${applianceHost}/artifacts/service/local')
		artRestClient.auth.basic(getArtifactsSystemUserCredentials().get("userId"),getArtifactsSystemUserCredentials().get("password"))
		return artRestClient
	}

    public void createDefaultMbaScheduledTask(JSON schedTaskDef){
//		def jsonSlurper = new JsonSlurper()
	    def restEndPoint = getArtifactsRestEndpoint()
		def artifactsSchedulesRestPath = "/schedules"
	    restEndPoint.get(path : artifactsSchedulesRestPath, body : schedTaskDef, requestContentType : groovyx.net.http.ContentType.JSON ) { resp ->
			out.println("[MBA] Artifacts: createDefaultMbaScheduledTasks RESTClient POST response status: ${resp.statusLine}")
	    }
//		List<Resource> nexusSchedTasksDefinitions = Appliance.getInstance().getContext(ManagedContext.class).getResources("classpath:gmrt/bhive/plugins/bhive/ManagedContext");
//		((File)(nexusSchedTasksDefinitions)).eachFileMatch(~/.*.json$/) { jsonFile ->
//			artifactsSchedulesRestEndPoint.post( body : jsonSlurper.parse(jsonFile), requestContentType : groovyx.net.http.ContentType.JSON ) { resp ->
//				out.println("[MBA] Artifacts: createDefaultMbaScheduledTasks RESTClient POST response status: ${resp.statusLine}")
//				//assert resp.statusLine.statusCode == 201
//			}
//		}
	}

	public Map<String,String> getArtifactsSystemUserCredentials(){
		return [userId : "admin", password : "admin"]
	}
}
