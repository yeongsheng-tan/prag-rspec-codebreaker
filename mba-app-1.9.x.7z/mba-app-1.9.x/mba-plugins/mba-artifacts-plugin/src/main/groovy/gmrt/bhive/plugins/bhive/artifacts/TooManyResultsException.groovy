package gmrt.bhive.plugins.bhive.artifacts

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 2/18/11
 */
class TooManyResultsException extends RuntimeException {}
