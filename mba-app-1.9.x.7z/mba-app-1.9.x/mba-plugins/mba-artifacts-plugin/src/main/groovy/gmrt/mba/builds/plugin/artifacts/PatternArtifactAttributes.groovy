package gmrt.mba.builds.plugin.artifacts

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 8/19/11
 */
class PatternArtifactAttributes {

  final String groupIdExpr;
  final String artifactIdExpr;
  final String classifierExpr;
  final String versionExpr;

  PatternArtifactAttributes(String groupIdExpr, String artifactIdExpr, String classifierExpr, String versionExpr) {
    this.groupIdExpr = groupIdExpr
    this.artifactIdExpr = artifactIdExpr
    this.classifierExpr = classifierExpr;
    this.versionExpr = versionExpr
  }


  public String toString ( ) {
  return "PatternArtifactAttributes{" +
  "groupIdExpr='" + groupIdExpr + '\'' +
  ", artifactIdExpr='" + artifactIdExpr + '\'' +
  ", classifierExpr='" + classifierExpr + '\'' +
  ", versionExpr='" + versionExpr + '\'' +
  '}' ;
  }}
