package gmrt.mba.builds.plugin.artifacts

/**
 * @see Gav
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 9/3/11
 */
class Coords extends Gav {

  final String type;
  final String classifier;

  /**
   * "{@link #groupId}:{@link #artifactId}:{@link #type}:{@link #version}[{@link #classifier}]
   */
  final String gatvc

  Coords(String groupId, String artifactId, String version, String type, String classifier) {
    super(groupId, artifactId, version)
    this.type = type
    this.classifier = classifier

    this.gatvc = "${groupId}:${artifactId}:${type}:${version}${(classifier) ? ":${classifier}" : ""}"
  }

  String toString() {
    gatvc;
  }

}
