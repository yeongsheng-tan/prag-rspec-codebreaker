package gmrt.mba.builds.plugin.artifacts

import hudson.model.AbstractBuild
import hudson.model.Action

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 8/22/11
 */
abstract class AbstractPromotionActionFactory {

  protected final boolean deletePromoted;

  AbstractPromotionActionFactory(boolean deletePromoted) {
    this.deletePromoted = deletePromoted
  }

  /**
   * Finds the most recent {@link Action} of the specified type in the build.
   */
  protected Action getNewestAction(AbstractBuild build, Class<? extends Action> actionClazz) {
    build.getActions(actionClazz)?.last();
  }

  /**
   * Returns a string which is the relative URI of the artifact in relation to the
   * directory specified.
   */
  protected String relativize(File directory, File artifact) {
      return directory.absoluteFile.toURI().relativize(artifact.absoluteFile.toURI()).toString();
  }

}
