package gmrt.mba.builds.plugin.artifacts

import org.apache.lucene.search.BooleanClause.Occur
import org.apache.maven.index.MAVEN
import org.apache.maven.index.NexusIndexer
import org.apache.maven.index.expr.StringSearchExpression
import org.apache.maven.index.GroupedSearchRequest
import org.apache.maven.index.search.grouping.GAGrouping
import org.apache.maven.index.ArtifactInfo
import org.apache.maven.index.FlatSearchRequest
import org.apache.maven.index.ArtifactInfoGroup
import org.apache.lucene.search.BooleanQuery
import org.apache.maven.index.ArtifactAvailablility

/**
 * A very basic boolean query builder and result collector.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 9/3/11
 */
class Finder {

  final Repository repo
  final org.apache.lucene.search.BooleanQuery q = new BooleanQuery();

  private Occur join = Occur.MUST;

  public Finder(Repository repo) {
    this.repo = repo;
  }

  /**
   * Sets the join to "and", this is the default.
   */
  Finder and() {
    join = Occur.MUST
    this
  }

  /**
   * Sets the join to "not"
   */
  Finder not() {
    join = Occur.MUST_NOT
    this
  }

  Finder groupId(String groupId) {
    q.add(repo.indexer.constructQuery(MAVEN.GROUP_ID, new StringSearchExpression(groupId)), join);
    this
  }

  Finder artifactId(String artifactId) {
    q.add(repo.indexer.constructQuery(MAVEN.ARTIFACT_ID, new StringSearchExpression(artifactId)), join);
    this
  }

  Finder packaging(String packaging) {
    q.add(repo.indexer.constructQuery(MAVEN.PACKAGING, new StringSearchExpression(packaging)), join);
    this
  }

  Finder version(String version) {
    q.add(repo.indexer.constructQuery(MAVEN.VERSION, new StringSearchExpression(version)), join);
    this
  }

  /**
   * Searches for a flat list of {@link Ga} instances.
   */
  List<Ga> flat() {
    repo.indexer.searchFlat(new FlatSearchRequest(q)).results.collect {
      new Ga(it.groupId, it.artifactId)
    }.unique()
  }

  /**
   * Searches for lists of {@link Gav} grouped by {@link Ga}.
   */
  Map<Ga, List<Gav>> grouped() {

    repo.indexer.searchGrouped(new GroupedSearchRequest(q, new GAGrouping())).results.collect { String g, ArtifactInfoGroup aig ->
      aig.artifactInfos.collect { ArtifactInfo ai ->
        new Gav(ai.groupId, ai.artifactId, ai.version, ai.name, ai.description,
                ai.sourcesExists == ArtifactAvailablility.NOT_PRESENT,
                ai.javadocExists == ArtifactAvailablility.NOT_PRESENT,
                ai.signatureExists == ArtifactAvailablility.NOT_PRESENT)
      }
    }.flatten().unique().groupBy { it.widen() }

  }

  /**
   * Searches for lists of {@link Coords} grouped by {@link Gav} and {@ Ga}.
   */
  Map<Ga, Map<Gav, List<Coords>>> coords() {

       null

  }

}
