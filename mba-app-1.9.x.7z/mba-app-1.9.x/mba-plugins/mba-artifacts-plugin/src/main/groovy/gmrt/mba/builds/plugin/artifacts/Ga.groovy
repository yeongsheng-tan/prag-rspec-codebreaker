package gmrt.mba.builds.plugin.artifacts

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 9/3/11
 */
class Ga implements Comparable {

  final String groupId;
  final String artifactId;

  /**
   * "{@link #groupId}:{@link #artifactId}"
   */
  final String ga;

  /**
   * Convenience constructor that will split on ":"
   */
  Ga(String ga) {
    this(ga.split(":")[0],ga.split(":")[1])
  }

  Ga(String groupId, String artifactId) {
    this.groupId = groupId
    this.artifactId = artifactId
    this.ga = "${groupId}:${artifactId}"
  }

  Gav narrow(String version) {
    new Gav(groupId, artifactId, version)
  }

  /**
   * Compares {@link #ga}
   */
  int compareTo(Object o) {
    this.ga.compareTo(o.ga);
  }

  String toString() {
    ga
  }

  boolean equals(o) {
    if (this.is(o)) return true;
    if (!(o instanceof Ga)) return false;

    Ga ga1 = (Ga) o;

    if (ga != ga1.ga) return false;

    return true;
  }

  int hashCode() {
    return ga.hashCode();
  }
}
