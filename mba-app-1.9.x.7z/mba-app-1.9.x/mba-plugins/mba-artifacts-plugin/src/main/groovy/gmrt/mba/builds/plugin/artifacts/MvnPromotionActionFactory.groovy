package gmrt.mba.builds.plugin.artifacts

import hudson.maven.MavenBuild
import hudson.maven.MavenModuleSetBuild
import hudson.maven.reporters.MavenAbstractArtifactRecord
import hudson.maven.reporters.MavenArtifact
import hudson.maven.reporters.MavenArtifactRecord
import hudson.model.AbstractBuild

import hudson.model.TaskListener

import hudson.maven.AbstractMavenBuild
import hudson.model.Result

/**
 * Translates all {@link MavenAbstractArtifactRecord}s found in a build into {@link Promotable} instances.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/12/11
 */
public class MvnPromotionActionFactory extends AbstractPromotionActionFactory implements PromotionActionFactory {

  MvnPromotionActionFactory(boolean deletePromoted) {
    super(deletePromoted)
  }

  public boolean isApplicable(Class jobType) {
    AbstractMavenBuild.isAssignableFrom(jobType);
  }

  public PromotionAction create(AbstractBuild build, TaskListener listener) {

    def promotables = [];
    getArtifactRecords((AbstractMavenBuild)build, listener).each { MavenArtifactRecord mar ->

      listener.logger.println("[MBA] Creating Promotable instances for module ${mar.parent.parent.moduleName} ...");

      def promotable = getPromotable(mar.parent, mar.mainArtifact)
      promotables << promotable;
      listener.logger.println("[MBA] Main artifact: ${promotable}");

      if (!mar.isPOM() && mar.pomArtifact != null && mar.pomArtifact != mar.mainArtifact) {
        promotable = getPromotable(mar.parent, mar.pomArtifact);
        promotables << promotable;
        listener.logger.println("[MBA] Pom artifact: ${promotable}");
      }

      mar.attachedArtifacts.each {
        promotable = getPromotable(mar.parent, it);
        promotables << promotable;
        listener.logger.println("[MBA] Attached artifact: ${promotable}");
      }

    }

    return new MvnPromotionAction(build, promotables as Promotable[], deletePromoted);
  }

  /**
   * Extracts the {@link MavenAbstractArtifactRecord}s from a {@link MavenModuleSetBuild} or {@link MavenBuild}.
   */
  protected List<MavenArtifactRecord> getArtifactRecords(AbstractMavenBuild build, TaskListener listener) {

    List<MavenArtifactRecord> result = [];
    if (build instanceof MavenModuleSetBuild) {
      build.getModuleLastBuilds().each { mavenModule, mavenBuild ->
        if (Result.NOT_BUILT == mavenBuild.result) {
          listener.logger.println("[MBA] Module ${mavenModule.getModuleName()} was not built, skipping ...");
          return;
        }
        result << getNewestAction(mavenBuild, MavenArtifactRecord.class);
      }
    } else {
      result << getNewestAction(build, MavenArtifactRecord.class);
    }

    result
  }

  protected Promotable getPromotable(MavenBuild mavenBuild, MavenArtifact mavenArtifact) {
    File file = mavenArtifact.getFile(mavenBuild);
    return new Promotable(mavenArtifact.groupId, mavenArtifact.artifactId, mavenArtifact.version,
            mavenArtifact.classifier, relativize(mavenBuild.parent.parent.rootDir, file));
  }

}
