package gmrt.bhive.plugins.bhive.artifacts

import org.sonatype.aether.artifact.ArtifactType

/**
 * Implemented by artifacts that can be promoted to the appliance releases or snapshots repositories. A
 * {@link Promotable} is composed of a "main" artifact, a "pom" artifact and a list of "attached" artifacts. So while
 * it's a little implicit, a {@link Promotable} is essentially an aggregation of all the artifacts within a specific
 * groupId:artifactId:version module.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 1/26/11
 */
public interface Promotable {

  String getGroupId();
  String getArtifactId();
  String getVersion();
  ArtifactType getType();

  /**
   * Will == "this" if the main artifact _is_ a pom. Otherwise returns the actual pom artifact which is the last
   * artifact to be promoted in any given set.
   */
  Promotable getPom();

  /**
   * Attaches an artifact to this promotable with the specified classifier and extension.
   */
  void attach(ArtifactType type);

  /**
   * Any attached artifacts. These should be artifacts attached to the current module and not a recursive tree of
   * anything and everything.
   */
  Promotable[] getAttached();

}
