package gmrt.mba.builds.plugin.artifacts

import gmrt.da.auth.User
import hudson.model.TaskListener
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import org.apache.maven.repository.internal.DefaultServiceLocator
import org.apache.maven.repository.internal.MavenRepositorySystemSession
import org.sonatype.aether.RepositorySystem
import org.sonatype.aether.artifact.Artifact
import org.sonatype.aether.connector.file.FileRepositoryConnectorFactory
import org.sonatype.aether.connector.wagon.WagonProvider
import org.sonatype.aether.connector.wagon.WagonRepositoryConnectorFactory
import org.sonatype.aether.deployment.DeployRequest
import org.sonatype.aether.deployment.DeploymentException
import org.sonatype.aether.repository.Authentication
import org.sonatype.aether.repository.LocalRepository
import org.sonatype.aether.repository.RemoteRepository
import org.sonatype.aether.spi.connector.RepositoryConnectorFactory
import org.sonatype.aether.transfer.AbstractTransferListener
import org.sonatype.aether.transfer.TransferEvent
import org.sonatype.aether.transfer.TransferResource
import org.sonatype.aether.util.artifact.DefaultArtifact

/**
 * Handles deploying a list of {@link Promotable} to a repository. Represents a "session" of sorts since the repository
 * id is specified in the constructor.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/12/11
 */
class Promoter extends AbstractTransferListener {

  final String repositoryHost;
  final User worker;
  final Promotable[] promotables;
  final TaskListener listener;

  private transient File rootDir;

  Promoter(String repositoryHost, User worker, Promotable[] promotables, TaskListener listener) {
    this.repositoryHost = repositoryHost;
    this.worker = worker
    this.promotables = promotables;
    this.listener = listener;
  }

  /**
   * Invokes the promotion using {@link Promotable#path} relative to the specified directory. Each {@link Promotable}
   * will be updated with a {@link PromotionRecord} as the promotions proceed.
   *
   * @param rootDir Root directory of the project, used to resolve the relative {@link Promotable#path} attribute.
   */
  void perform(File rootDir) {

    this.rootDir = rootDir;
    RepositorySystem system = newRepositorySystem();
    MavenRepositorySystemSession session = newRepositorySession(system);

    session.setTransferListener(this);

    // Group the promotables by unique groupId:artifactId:version so we can promote them as a "transaction".
    Map<String, List<Promotable>> grouped = [:];
    promotables.each {
      def gav = "${it.groupId}:${it.artifactId}:${it.version}";
      if (!grouped[gav])
        grouped[gav] = [];
      grouped[gav] << it;
    }

    grouped.each {
      listener.logger.println("[MBA] Promoting artifacts in the ${it.key} coordinates ...");

      String repositoryId = it.value.last().repositoryId;

      RemoteRepository rr = new RemoteRepository(repositoryId, 'default',
              "http://${repositoryHost}/artifacts/content/${repositoryId}");
      rr.setAuthentication(new Authentication(worker.userId, worker.credentials.toString()));

      DeployRequest dr = new DeployRequest(repository: rr);

      it.value.each { promotable ->

        File artifact = new File(rootDir, promotable.path);
        if (!artifact.exists())
          throw new FileNotFoundException(artifact.path);

        def extension = (artifact.name.contains(".")) ? artifact.name.substring(artifact.name.lastIndexOf('.') + 1) : null;
        Artifact art = new DefaultArtifact(promotable.groupId, promotable.artifactId, promotable.classifier, extension, promotable.version, [:], artifact);

        dr.addArtifact(art);

      }

      try {
        system.deploy(session, dr);
      } catch (DeploymentException t) {
        // We'll record exceptions in the {@link PromotionRecord}.
      }

    }

  }

  @Override
  void transferSucceeded(TransferEvent e) {

    String len = e.transferredBytes >= 1024 ? toKB(e.transferredBytes) + " KB" : e.transferredBytes + " B";

    String throughput = "";
    long duration = System.currentTimeMillis() - e.resource.getTransferStartTime();

    if (e.transferredBytes >= 0) {
      if (duration > 0) {
        DecimalFormat format = new DecimalFormat("0.0", new DecimalFormatSymbols(Locale.ENGLISH));
        double kbPerSec = (e.transferredBytes / 1024.0) / (duration / 1000.0);
        throughput = " at " + format.format(kbPerSec) + " KB/sec";
      }
    }

    Promotable p = find(e);
    if (p) {
      String msg = "SUCCESS on promotion of ${e.resource.resourceName} to ${p.repositoryId} (${len} ${throughput})";
      p.createRecord(true, msg, "${e.resource.resourceName}", listener);
      listener.logger.println("[MBA] ${msg}");
    }

  }

  @Override
  void transferFailed(TransferEvent e) {

    Promotable p = find(e);
    if (p) {
      String msg = "FAILURE on promotion of ${e.resource.resourceName} to ${p.repositoryId} with: ${e.exception.message}";
      p.createRecord(false, msg, e.resource.resourceName, listener);
      listener.logger.println("[MBA] ${msg}");
    }

  }

  /**
   * Attempts to derive the correct {@link Promotable} by comparing paths with {@link TransferResource#getFile}.
   */
  Promotable find(TransferEvent event) {
    promotables.find { new File(rootDir, it.path) == event.resource.file }
  }

  long toKB(long bytes) {
    return (bytes + 1023) / 1024;
  }

  private RepositorySystem newRepositorySystem() {
    new DefaultServiceLocator().with {
      addService(RepositoryConnectorFactory.class, FileRepositoryConnectorFactory.class);
      addService(RepositoryConnectorFactory.class, WagonRepositoryConnectorFactory.class);
      setServices(WagonProvider.class, [ lookup: {new PreEmpAuthWagon()}, release: {} ] as WagonProvider)
      getService(RepositorySystem.class);
    }
  }

  private MavenRepositorySystemSession newRepositorySession(RepositorySystem repositorySystem) {
    new MavenRepositorySystemSession(
            localRepositoryManager: repositorySystem.newLocalRepositoryManager(
                    new LocalRepository(new File(System.getProperty('java.io.tmpdir')), 'default')));
  }


}
