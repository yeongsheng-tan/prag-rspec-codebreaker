package gmrt.bhive.plugins.bhive.artifacts

import org.apache.commons.httpclient.HttpMethod

/**
 * An http wagon that actually "works" with pre-emptive authentication.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/15/11
 * @deprecated Moved to the mba-artifacts-plugin.
 */
class PreEmpAuthWagon extends org.apache.maven.wagon.providers.http.HttpWagon {

    @Override
    protected int execute(HttpMethod httpMethod) {
        getClient().getParams().setAuthenticationPreemptive(true);
        return super.execute(httpMethod);
    }

}
