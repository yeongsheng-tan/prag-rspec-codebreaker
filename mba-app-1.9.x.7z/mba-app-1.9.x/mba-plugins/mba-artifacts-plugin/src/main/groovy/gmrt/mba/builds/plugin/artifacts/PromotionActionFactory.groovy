package gmrt.mba.builds.plugin.artifacts

import hudson.model.AbstractBuild
import hudson.model.TaskListener

/**
 * Produces one or more {@link Promotable} instances from an {@link hudson.model.AbstractBuild}.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/12/11
 */
public interface PromotionActionFactory {

  public boolean isApplicable(Class abstractProjectType);

  public PromotionAction create(AbstractBuild build, TaskListener listener);

}