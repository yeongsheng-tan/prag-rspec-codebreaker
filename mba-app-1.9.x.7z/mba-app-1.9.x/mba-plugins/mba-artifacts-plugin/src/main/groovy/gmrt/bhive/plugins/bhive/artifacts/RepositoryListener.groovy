package gmrt.bhive.plugins.bhive.artifacts

import org.sonatype.aether.AbstractRepositoryListener
import org.sonatype.aether.RepositoryEvent

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/31/11
 */
class RepositoryListener extends AbstractRepositoryListener {

  private PrintStream out;

  public RepositoryListener(PrintStream out) {
    this.out = (out != null) ? out : System.out;
  }

  public void artifactDeployed(RepositoryEvent event) {
    out.println("[MBA] Promoted " + event.getArtifact() + " to " + event.getRepository());
  }

  public void artifactDeploying(RepositoryEvent event) {
    out.println("[MBA] Promoting " + event.getArtifact() + " to " + event.getRepository());
  }

  public void artifactDescriptorInvalid(RepositoryEvent event) {
    out.println("[MBA] Invalid artifact descriptor for " + event.getArtifact() + ": "
            + event.getException().getMessage());
  }

  public void artifactDescriptorMissing(RepositoryEvent event) {
    out.println("[MBA] Missing artifact descriptor for " + event.getArtifact());
  }

  public void artifactInstalled(RepositoryEvent event) {
    out.println("[MBA] Installed " + event.getArtifact() + " to " + event.getFile());
  }

  public void artifactInstalling(RepositoryEvent event) {
    out.println("[MBA] Installing " + event.getArtifact() + " to " + event.getFile());
  }

  public void artifactResolved(RepositoryEvent event) {
    out.println("[MBA] Resolved artifact " + event.getArtifact() + " from " + event.getRepository());
  }

  public void artifactDownloading(RepositoryEvent event) {
    out.println("[MBA] Downloading artifact " + event.getArtifact() + " from " + event.getRepository());
  }

  public void artifactDownloaded(RepositoryEvent event) {
    out.println("[MBA] Downloaded artifact " + event.getArtifact() + " from " + event.getRepository());
  }

  public void artifactResolving(RepositoryEvent event) {
    out.println("[MBA] Resolving artifact " + event.getArtifact());
  }

  public void metadataDeployed(RepositoryEvent event) {
    out.println("[MBA] Promoted " + event.getMetadata() + " to " + event.getRepository());
  }

  public void metadataDeploying(RepositoryEvent event) {
    out.println("[MBA] Promoted " + event.getMetadata() + " to " + event.getRepository());
  }

  public void metadataInstalled(RepositoryEvent event) {
    out.println("[MBA] Installed " + event.getMetadata() + " to " + event.getFile());
  }

  public void metadataInstalling(RepositoryEvent event) {
    out.println("[MBA] Installing " + event.getMetadata() + " to " + event.getFile());
  }

  public void metadataInvalid(RepositoryEvent event) {
    out.println("[MBA] Invalid metadata " + event.getMetadata());
  }

  public void metadataResolved(RepositoryEvent event) {
    out.println("[MBA] Resolved metadata " + event.getMetadata() + " from " + event.getRepository());
  }

  public void metadataResolving(RepositoryEvent event) {
    out.println("[MBA] Resolving metadata " + event.getMetadata() + " from " + event.getRepository());
  }

}

