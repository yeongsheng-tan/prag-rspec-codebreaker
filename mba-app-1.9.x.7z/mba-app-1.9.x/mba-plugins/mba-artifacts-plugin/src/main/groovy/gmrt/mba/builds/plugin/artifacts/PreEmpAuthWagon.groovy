package gmrt.mba.builds.plugin.artifacts

import org.apache.commons.httpclient.HttpMethod

/**
 * Sets the {@link org.apache.commons.httpclient.params.HttpClientParams#setAuthenticationPreemptive} to
 * <code>true</code>.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/22/11
 */
class PreEmpAuthWagon extends org.apache.maven.wagon.providers.http.HttpWagon {

    @Override
    protected int execute(HttpMethod httpMethod) {
        client.params.authenticationPreemptive = true;
        super.execute(httpMethod);
    }

}
