package gmrt.mba.builds.plugin.artifacts

import hudson.model.TaskListener
import hudson.maven.reporters.MavenAbstractArtifactRecord
import hudson.model.AbstractBuild
import hudson.maven.MavenModuleSetBuild

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 8/25/11
 */
class MvnPromotionAction extends PromotionAction {

  MvnPromotionAction(AbstractBuild build, Promotable[] promotables, boolean deletePromoted) {
    super(build, promotables, deletePromoted)
  }

  /**
   * Removes the {@link MavenAbstractArtifactRecord}s from the build as they are no longer needed.
   */
  @Override
  boolean onStart(TaskListener listener) {

    listener.logger.println("[MBA] Removing maven artifact records that have been replaced with Promotables ...");
    removeActions(build)
    if (build instanceof MavenModuleSetBuild) {
      build.moduleLastBuilds.each { removeActions(it.value) }
    }

    return super.onStart(listener)
  }

  private void removeActions(AbstractBuild _build) {
    new LinkedList(_build.getActions(MavenAbstractArtifactRecord.class)).each {
      _build.actions.remove(it);
    }
  }

}
