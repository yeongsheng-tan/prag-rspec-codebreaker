package gmrt.mba.builds.plugin.artifacts

import org.apache.log4j.Logger
import org.apache.maven.artifact.Artifact
import org.apache.maven.artifact.DefaultArtifact
import org.apache.maven.artifact.handler.ArtifactHandler
import org.apache.maven.artifact.repository.ArtifactRepository
import org.apache.maven.artifact.repository.ArtifactRepositoryFactory
import org.apache.maven.artifact.repository.ArtifactRepositoryPolicy
import org.apache.maven.artifact.repository.layout.DefaultRepositoryLayout
import org.apache.maven.artifact.resolver.ArtifactResolutionException
import org.apache.maven.artifact.resolver.ArtifactResolutionRequest
import org.apache.maven.artifact.resolver.ArtifactResolutionResult
import org.apache.maven.artifact.resolver.ArtifactResolver
import org.apache.maven.index.NexusIndexer
import org.apache.maven.index.context.IndexCreator
import org.apache.maven.index.context.IndexingContext
import org.apache.maven.index.creator.MinimalArtifactInfoIndexCreator
import org.apache.maven.index.updater.IndexUpdateRequest
import org.apache.maven.index.updater.IndexUpdater
import org.apache.maven.index.updater.WagonHelper
import org.apache.maven.index.updater.WagonHelper.WagonFetcher
import org.codehaus.plexus.ContainerConfiguration
import org.codehaus.plexus.DefaultContainerConfiguration
import org.codehaus.plexus.DefaultPlexusContainer
import org.codehaus.plexus.PlexusContainer
import org.codehaus.plexus.classworlds.ClassWorld

/**
 * A facade for a remote repository
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 9/3/11
 */
class Repository {

  private static final Logger LOG = Logger.getLogger(Repository.class);

  private static final ArtifactRepositoryPolicy POLICY = new ArtifactRepositoryPolicy(true, "always", "warn");

  final String repositoryId;
  final URL repositoryUrl;
  final File repositoryDir;

  /** package **/ NexusIndexer indexer;
  private PlexusContainer plexus;
  private ArtifactRepository local;
  private ArtifactRepository remote;
  private ArtifactResolver resolver;
  private ArtifactHandler handler;
  private IndexingContext ic;

  private int transferredBytes;

  Repository(String repositoryId, URL repositoryUrl, File repositoryDir) {

    this.repositoryId = repositoryId;
    this.repositoryUrl = repositoryUrl;
    this.repositoryDir = repositoryDir;

    if (!repositoryDir.exists())
      repositoryDir.mkdirs();

    ClassWorld classWorld = new ClassWorld("plexus.core", getClass().getClassLoader());
    ContainerConfiguration configuration = new DefaultContainerConfiguration().setClassWorld(classWorld);
    plexus = new DefaultPlexusContainer(configuration);
    indexer = plexus.lookup(NexusIndexer.class);
    resolver = plexus.lookup(ArtifactResolver.class);
    handler = plexus.lookup(ArtifactHandler.class);

    ArtifactRepositoryFactory arf = plexus.lookup(ArtifactRepositoryFactory.class);
    local = arf.createArtifactRepository(ArtifactRepositoryFactory.DEFAULT_LAYOUT_ID,
                  repositoryDir.toURI().toURL().toExternalForm(),
                  new DefaultRepositoryLayout(), POLICY, POLICY);
    remote = arf.createArtifactRepository(ArtifactRepositoryFactory.DEFAULT_LAYOUT_ID, repositoryUrl.toExternalForm(),
            new DefaultRepositoryLayout(), POLICY, POLICY);


    ic = indexer.addIndexingContext(repositoryId, repositoryId, repositoryDir, new File(repositoryDir, ".index"),
            repositoryUrl.toString(), null, [plexus.lookup( IndexCreator.class, MinimalArtifactInfoIndexCreator.ID )] as List<IndexCreator>);

  }

  /**
   * Fetches the remote index from the repository and updates the local cache of it.
   */
  void updateIndex(PrintStream out) {

    LOG.info("Beginning update of ${repositoryId} index from ${repositoryUrl} into ${repositoryDir} ...");
    IndexUpdater id = plexus.lookup(IndexUpdater.class);
    WagonFetcher fetcher = new WagonHelper(plexus).getWagonResourceFetcher(new TransferListener(out));
    id.fetchAndUpdateIndex(new IndexUpdateRequest(ic, fetcher));
    LOG.info("Update complete for ${repositoryId} ...");

  }

  /**
   * Creates a new {@link Finder} instance for this repository that is used to search the local index
   */
  Finder find() {
    return new Finder(this);
  }

  /**
   * Resolves an artifact based on the specified coordinates
   *
   * @todo Need to implement error handling for missing artifacts or resolution failures.
   */
  File resolve(Coords coords) {
    ArtifactResolutionRequest arr = new ArtifactResolutionRequest();
    arr.localRepository = local;
    arr.remoteRepositories = [remote];
    arr.artifact = new DefaultArtifact(coords.groupId, coords.artifactId, coords.version, null, coords.type, coords.classifier, handler);
	// we know for a fact that an artifactId with version String 'SNAPSHOT' is NOT REALLY resolvable to an ACTUAL FILE
	// therefore we throw a ArtifactResolutionException in such situation???
	if(coords.version.contains('SNAPSHOT'))
		throw new ArtifactResolutionException("No actual artifact ending with version String as SNAPSHOT",arr.artifact)
    ArtifactResolutionResult res = resolver.resolve(arr);
	if(res!=null){
        new LinkedList<Artifact>(res.artifacts).first.file
	}else{
		throw new ArtifactResolutionException("Error attempting to resolve the actual artifact",arr.artifact)
	}
  }

}
