package gmrt.mba.builds.plugin.artifacts

import hudson.AbortException

import hudson.model.AbstractBuild
import hudson.model.TaskListener
import org.springframework.util.AntPathMatcher
import groovy.text.SimpleTemplateEngine
import groovy.text.Template
import org.apache.commons.lang.StringUtils

/**
 * Creates {@link Promotable} instances based on patterns run against the build archive dir.
 *
 * @see AntPathMatcher
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/19/11
 */
public class PatternPromotionActionFactory extends AbstractPromotionActionFactory implements PromotionActionFactory {

  def final PatternArtifactAttributes attrs;
  def final IncludesExcludes includesExcludes;

  /**
   * Flip this to turn on debugging of your patterns.
   */
  public static boolean DEBUG = false;

  private Template fakePomTemplate;
  private List<String> gavs = [];

  PatternPromotionActionFactory(PatternArtifactAttributes attrs, IncludesExcludes includesExcludes, boolean deletePromoted) {
    super(deletePromoted);
    this.attrs = attrs;
    this.includesExcludes = includesExcludes
    this.fakePomTemplate = new SimpleTemplateEngine().createTemplate(getClass().getResourceAsStream('fake-pom.xml').text);
  }

  public boolean isApplicable(Class jobType) {
    return true;
  }

  public PromotionAction create(AbstractBuild build, TaskListener listener) {

    listener.logger.println("[MBA] Finding promotables using: ${includesExcludes}");

    List<File> included = new FindArtifactsCallable(includesExcludes).invoke(build.getArtifactsDir());
    def promotables = [];

    Binding binding = new Binding();
    binding.setVariable('build', build);
    binding.setVariable('listener', listener);
    GroovyShell shell = new GroovyShell(binding);

    included.each { File file ->

      binding.setVariable('file', file);
      binding.setVariable('path', file.toURI().toString());
      binding.setVariable('name', file.name);
      binding.setVariable('shortName', file.name.with {
        if (it.contains('.'))
          return it.substring(0, it.lastIndexOf('.'))
        it;
      });
      binding.setVariable('extension', file.name.with {
        if (it.contains('.'))
          return it.substring(it.lastIndexOf('.') + 1);
        it;
      })

      String groupId = evaluate('groupIdExpr', attrs.groupIdExpr, build, listener, shell, binding);
      binding.setVariable('groupId', groupId);
      String artifactId = evaluate('artifactIdExpr', attrs.artifactIdExpr, build, listener, shell, binding);
      binding.setVariable('artifactId', artifactId);
      String version = evaluate('versionExpr', attrs.versionExpr, build, listener, shell, binding);
      binding.setVariable('version', version);
      String classifier = evaluate('classifierExpr', attrs.classifierExpr, build, listener, shell, binding);
      binding.setVariable('classifier', classifier);

      String gav = "${groupId}:${artifactId}:${version}";
      if (!gavs.contains(gav)) {
        gavs << gav;
      }

      Promotable promotable = new Promotable(groupId, artifactId, version, classifier, relativize(build.project.rootDir, file));
      listener.logger.println("[MBA] Created: ${promotable}");
      promotables << promotable;

    }

    new PromotionAction(build, promotables as Promotable[], deletePromoted);
  }

  /**
   * Evaluates the specified expression against the binding. Will throw an {@link AbortException} on failure to
   * evaluate expression.
   */
  private String evaluate(String label, String expression, AbstractBuild build, TaskListener listener,
                          GroovyShell shell, Binding binding) {

    if (StringUtils.isBlank(expression))
      return null;

    try {

      Object result = shell.evaluate(expression, label)
      if (result == null)
        return null;
      return result.toString();

    } catch (Throwable t) {
      listener.error("[MBA] Expression (${expression}) failed to execute with ${t.message}");
      throw new AbortException(t.getMessage());
    };

  }

}
