package gmrt.mba.builds.plugin.artifacts;

import java.io.Serializable;
import java.util.Arrays;

/**
 * Represents include patterns that are applied (empty includes == all possible matches) first followed by excluding
 * anything caught in the excludes patterns.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/19/11
 */
public class IncludesExcludes implements Serializable {

    public final String[] includes;
    public final String[] excludes;

    IncludesExcludes(String[] includes, String[] excludes) {
        this.includes = includes;
        this.excludes = excludes;
    }

    public String toString() {
        return "IncludesExcludes{" +
                "includes=" + (includes == null ? null : Arrays.asList(includes)) +
                ", excludes=" + (excludes == null ? null : Arrays.asList(excludes)) +
                '}';
    }
}
