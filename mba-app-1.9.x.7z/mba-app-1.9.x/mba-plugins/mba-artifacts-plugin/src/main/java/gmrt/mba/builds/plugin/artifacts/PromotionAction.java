package gmrt.mba.builds.plugin.artifacts;

import hudson.model.*;

import java.io.File;

/**
 * Represents the record of an artifact promotion into a Code/Artifacts instance.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/22/11
 */
public class PromotionAction extends InvisibleAction implements Action {

    public final AbstractBuild build;
    public final Promotable[] promotables;
    public final boolean deletePromoted;

    public PromotionAction(AbstractBuild build, Promotable[] promotables, boolean deletePromoted) {
        this.build = build;
        this.promotables = promotables;
        this.deletePromoted = deletePromoted;
    }

    /**
     * Called by the {@link AbstractArtifactPromoter} before passing the action over to the {@link Promoter} for
     * execution. Gives the implementation an opportunity to move artifacts around or whatever needs to be done
     * before the process is begun.
     *
     * @return continues Continue the process? (<code>false</code> will fail the build.)
     */
    protected boolean onStart(TaskListener listener) { return true; }

    /**
     * Called by the {@link AbstractArtifactPromoter} at conclusion of the {@link Promoter#perform(java.io.File)}
     * method. Will be called whether promotion succeeds or not. Gives the implementation an opportunity to clean
     * up or make changes to the build.
     * <p/>
     * Default implement handles failing the build and the {@link #deletePromoted} behavior so any sub-classes should
     * be sure to call this method when overloading.
     *
     * @return success Promotion considered a success?
     */
    protected boolean onComplete(TaskListener listener) {

        if (deletePromoted) {
            for (Promotable promotable : promotables) {
                if (promotable.getRecord().successful) {
                    listener.getLogger().println("[MBA] Deleting promoted artifact from archive: " + promotable.path);
                    if (!new File(getRootDir(), promotable.path).delete()) {
                        listener.error("[MBA] Failed to delete promoted artifact from archive: " + promotable.path);
                    }
                } else {
                    listener.getLogger().println("[MBA] Will not delete artifact " + promotable.getCoordinates() +
                            " due to failed promotion ...");
                }
            }
        }

        if (getFailed() > 0) {
            build.setResult(Result.FAILURE);
            listener.fatalError("[MBA] A promotion failure occurred, failing the build ...");
            return false;
        }

        return true;
    }

    /**
     * Returns the count of successful {@link PromotionRecord}s.
     */
    public int getSuccessful() {
        int successful = 0;
        for (Promotable p : promotables) {
            if (p.getRecord() != null && p.getRecord().successful)
                successful++;
        }
        return successful;
    }

    /**
     * Returns the count of failed {@link PromotionRecord}s.
     */
    public int getFailed() {
        int failed = 0;
        for (Promotable p : promotables) {
            if (p.getRecord() != null && !p.getRecord().successful)
                failed++;
        }
        return failed;
    }

    /**
     * Returns the directory that the {@link Promotable#path} is relative to. This differs between project types, the
     * default implementation just returns the root dir of
     * {@link hudson.model.AbstractBuild#getProject()}.{@link hudson.model.AbstractProject#getRootProject()}
     */
    protected File getRootDir() {
        return build.getProject().getRootProject().getRootDir();
    }

}
