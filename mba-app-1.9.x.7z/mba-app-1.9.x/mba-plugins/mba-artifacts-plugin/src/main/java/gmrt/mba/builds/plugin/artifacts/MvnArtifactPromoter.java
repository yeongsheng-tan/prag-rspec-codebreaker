package gmrt.mba.builds.plugin.artifacts;

import hudson.Extension;
import hudson.Launcher;
import hudson.maven.MavenModule;
import hudson.maven.MavenModuleSet;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.plugins.promoted_builds.PromotionProcess;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.Publisher;
import net.sf.json.JSONObject;
import org.jvnet.hudson.plugins.m2release.M2ReleaseBadgeAction;
import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.StaplerRequest;

import java.io.IOException;

/**
 * Promotes artifacts created by {@link MavenModuleSet} and {@link MavenModule} projects.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/12/11
 */
public class MvnArtifactPromoter extends AbstractArtifactPromoter {

    @Extension
    public static class DescriptorImpl extends BuildStepDescriptor<Publisher> {

        @Override
        public boolean isApplicable(Class<? extends AbstractProject> jobType) {
            return jobType == MavenModuleSet.class || jobType == MavenModule.class || jobType == PromotionProcess.class;
        }

        @Override
        public String getDisplayName() {
            return "Promote archived Maven artifacts to your Code/Artifacts repository";
        }

        @Override
        public MvnArtifactPromoter newInstance(StaplerRequest req, JSONObject formData) throws FormException {
            return req.bindJSON(MvnArtifactPromoter.class, formData);
        }
    }

    public final boolean disableWhenM2release;

    @DataBoundConstructor
    public MvnArtifactPromoter(boolean evenIfUnstable, boolean deletePromoted, boolean disableWhenM2release) {
        super(evenIfUnstable, deletePromoted);
        this.disableWhenM2release = disableWhenM2release;
    }

    @Override
    public boolean perform(AbstractBuild __build, Launcher launcher, BuildListener listener) throws InterruptedException, IOException {

        if (disableWhenM2release && __build.getAction(M2ReleaseBadgeAction.class) != null) {
            listener.getLogger().println("[MBA] Artifact promotion is disabled on an M2 release run ...");
            return true;
        }

        return super.perform(__build, launcher, listener);
    }

    /**
     * Returns the {@link MvnPromotionActionFactory} for the specified build.
     */
    protected PromotionActionFactory getFactory(AbstractBuild build) {
        return new MvnPromotionActionFactory(deletePromoted);
    }

}

