package gmrt.mba.builds.plugin.artifacts;

import groovy.lang.GroovyShell;
import hudson.Extension;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.Publisher;
import hudson.util.FormValidation;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.codehaus.groovy.control.CompilationFailedException;
import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;
import org.kohsuke.stapler.StaplerRequest;

import java.util.regex.Pattern;

/**
 * Promotes any archived artifacts by pattern.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/12/11
 */
public class PatternArtifactPromoter extends AbstractArtifactPromoter {

    @Extension
    public static class DescriptorImpl extends BuildStepDescriptor<Publisher> {

        private static final Pattern GROUP_ID_PATTERN = Pattern.compile("[A-Za-z\\.]+");
        private static final Pattern ARTIFACT_ID_PATTERN = Pattern.compile("[A-Za-z]+");

        private transient final GroovyShell shell = new GroovyShell();

        @Override
        public boolean isApplicable(Class<? extends AbstractProject> jobType) {
            return true;
        }

        @Override
        public String getDisplayName() {
            return "Promote archived artifacts by pattern to your Code/Artifacts repository";
        }

        @Override
        public PatternArtifactPromoter newInstance(StaplerRequest req, JSONObject formData) throws FormException {
            return req.bindJSON(PatternArtifactPromoter.class, formData);
        }

        public FormValidation doCheckGroupIdExpr(@QueryParameter String value) {
            return validateExpression(value);
//            if (GROUP_ID_PATTERN.matcher(value).matches())
//                return FormValidation.ok();
//            return FormValidation.error("Invalid GroupId");
        }

        public FormValidation doCheckArtifactIdExpr(@QueryParameter String value) {
            return validateExpression(value);
//            if (ARTIFACT_ID_PATTERN.matcher(value).matches())
//                return FormValidation.ok();
//            return FormValidation.error("Invalid ArtifactId");
        }

        public FormValidation doCheckClassifierExpr(@QueryParameter String value) {
            if (StringUtils.isBlank(value))
                return FormValidation.ok();
            return validateExpression(value);
        }
        public FormValidation doCheckVersionExpr(@QueryParameter String value) {
            return validateExpression(value);
        }

        private FormValidation validateExpression(String value) {
            if (!StringUtils.isBlank(value)) {
                try {
                    shell.parse(value);
                    return FormValidation.ok();
                } catch (CompilationFailedException e) {
                    return FormValidation.error("Invalid Expression: " + e.getMessage());
                }
            }
            return FormValidation.error("Invalid Expression");
        }

    }

    public final String includes;
    public final String excludes;
    public final String groupIdExpr;
    public final String artifactIdExpr;
    public final String classifierExpr;
    public final String versionExpr;

    @DataBoundConstructor
    public PatternArtifactPromoter(String groupIdExpr, String artifactIdExpr, String classifierExpr, String versionExpr,
                                   String includes, String excludes,
                                   boolean evenIfUnstable, boolean deletePromoted) {
        super(evenIfUnstable, deletePromoted);
        this.includes = includes;
        this.excludes = excludes;
        this.groupIdExpr = groupIdExpr;
        this.artifactIdExpr = artifactIdExpr;
        this.classifierExpr = classifierExpr;
        this.versionExpr = versionExpr;
    }

    /**
     * Returns the {@link PatternPromotionActionFactory}.
     */
    protected PromotionActionFactory getFactory(AbstractBuild build) {
        return new PatternPromotionActionFactory(
                new PatternArtifactAttributes(groupIdExpr, artifactIdExpr, classifierExpr, versionExpr),
                new IncludesExcludes((!StringUtils.isBlank(includes)) ? StringUtils.split(includes, "\\n") : new String[]{},
                                    (!StringUtils.isBlank(excludes)) ? StringUtils.split(excludes, "\\n") : new String[]{}),
                deletePromoted);
    }

}

