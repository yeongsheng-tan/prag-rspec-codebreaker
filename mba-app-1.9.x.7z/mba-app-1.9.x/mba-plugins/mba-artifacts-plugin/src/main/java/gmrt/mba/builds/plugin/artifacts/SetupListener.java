package gmrt.mba.builds.plugin.artifacts;

import hudson.Extension;
import hudson.maven.RedeployPublisher;
import hudson.model.Descriptor;
import hudson.model.Hudson;
import hudson.model.listeners.ItemListener;
import hudson.plugins.promoted_builds.tasks.RedeployBatchTaskPublisher;
import hudson.tasks.Publisher;
import org.apache.log4j.Logger;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * Sets up the environment for using Builds with an Artifacts instance.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/12/11
 */
@Extension
public class SetupListener extends ItemListener {

    private static final Logger LOG = Logger.getLogger(SetupListener.class);

    /**
     * List of descriptors that we want to remove from Jenkins during startup. Examples would be the silly maven
     * {@link RedeployPublisher} that doesn't work well at all on repositories that require credentials.
     */
    public static final List<Class<? extends Descriptor>> UNWANTED_DESCRIPTORS =
            new LinkedList<Class<? extends Descriptor>>(Arrays.asList(
                    RedeployPublisher.DescriptorImpl.class, RedeployBatchTaskPublisher.DescriptorImpl.class));

    /**
     * Delegates to the methods below to handle startup tasks.
     */
    @Override
    public void onLoaded() {
        removeUnwantedDescriptors();
    }

    /**
     * Removes descriptors found in the {@link #UNWANTED_DESCRIPTORS} list.
     */
    public void removeUnwantedDescriptors() {

        Hudson hudson = Hudson.getInstance();
        for (Descriptor<Publisher> candidate : new LinkedList<Descriptor<Publisher>>(hudson.getDescriptorList(Publisher.class))) {
            if (UNWANTED_DESCRIPTORS.contains(candidate.getClass())) {
                LOG.info("Removing unwanted descriptor instance of type: " + candidate.getClass());
                hudson.getDescriptorList(Publisher.class).remove(candidate);
            }
        }

    }
}
