package gmrt.mba.builds.plugin.artifacts;

import gmrt.code.builds.plugin.builds.BuildsEnvAction;
import gmrt.mba.Appliance;
import gmrt.mba.HostResolver;
import gmrt.mba.auth.WorkerRealm;
import hudson.Launcher;
import hudson.model.AbstractBuild;
import hudson.model.BuildListener;
import hudson.model.Result;
import hudson.tasks.BuildStepMonitor;
import hudson.tasks.Recorder;

import java.io.File;
import java.io.IOException;

/**
 * Promotes artifacts from the {@link hudson.model.Run#getArtifactsDir()} into a Code/Artifacts repository, optionally
 * removing any artifacts that were successfully promoted. Supports delayed promotion using the
 * <a href="https://wiki.jenkins-ci.org/display/JENKINS/Promoted+Builds+Plugin">Promoted Builds Plugin</a>
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/19/11
 */
public abstract class AbstractArtifactPromoter extends Recorder {

    public final boolean evenIfUnstable;
    public final boolean deletePromoted;

    AbstractArtifactPromoter(boolean evenIfUnstable, boolean deletePromoted) {
        this.evenIfUnstable = evenIfUnstable;
        this.deletePromoted = deletePromoted;
    }

    public boolean perform(AbstractBuild __build, Launcher launcher, BuildListener listener) throws InterruptedException, IOException {

        listener.getLogger().println("[MBA] Artifact promotion Begins ...");

        HostResolver hr = Appliance.getInstance().getBean(Appliance.class, HostResolver.class);
        WorkerRealm workerRealm = Appliance.getInstance().getBean(gmrt.mba.auth.ManagedContext.class, WorkerRealm.class);

        if (__build.getResult().isWorseThan(getTreshold())) {
            listener.getLogger().println("[MBA] Artifact promotion skipped- Build is not stable ...");
            return false;
        }

        File rootDir = __build.getProject().getRootDir();

        PromotionAction promAction = getFactory(__build).create(__build, listener);
        __build.addAction(promAction);

        try {

            if (!promAction.onStart(listener)) {
                listener.getLogger().println("[MBA] Promotion was cancelled by the promotion action ...");
                __build.setResult(Result.FAILURE);
                return false;
            }

            BuildsEnvAction pa = __build.getAction(BuildsEnvAction.class);
            gmrt.da.auth.User worker = workerRealm.getUser(pa.env.get(BuildsEnvAction.MBA_WORKER_USER));

            Promoter promoter = new Promoter(hr.getHost(), worker, promAction.promotables, listener);
            promoter.perform(rootDir);

            return promAction.onComplete(listener);

        } finally {
            listener.getLogger().println("[MBA] Artifact Promotion Complete ...");
        }

    }

    /**
     * Returns the {@link PromotionActionFactory} for the particular <code>AbstractArtifactPromoter</code> implementation.
     */
    protected abstract PromotionActionFactory getFactory(AbstractBuild build);

    public BuildStepMonitor getRequiredMonitorService() {
        return BuildStepMonitor.NONE;
    }

    protected Result getTreshold() {
        if (evenIfUnstable) {
            return Result.UNSTABLE;
        } else {
            return Result.SUCCESS;
        }
    }

}
