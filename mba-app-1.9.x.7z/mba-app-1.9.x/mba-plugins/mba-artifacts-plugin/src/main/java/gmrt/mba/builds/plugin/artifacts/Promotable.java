package gmrt.mba.builds.plugin.artifacts;

import hudson.model.TaskListener;
import org.apache.commons.lang.StringUtils;

import java.io.Serializable;

/**
 * A single artifact that will be or was promoted.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/22/11
 */
public class Promotable implements Serializable {

    public static final String MBA_SNAPSHOTS_ID = "repositories/mba-snapshots";
    public static final String MBA_RELEASES_ID = "repositories/mba-releases";

    public final String groupId;
    public final String artifactId;
    public final String version;
    public final String classifier;
    public final String path;

    private PromotionRecord record;

    /**
     * @param groupId GroupId of the promotable (required)
     * @param artifactId ArtifactId of the promotable (required)
     * @param version Version of the promotable (required)
     * @param classifier Classifier of the promotable (optional)
     * @param path Path of the promotable, relative to the parent project root directory
     */
    Promotable(String groupId, String artifactId, String version, String classifier, String path) {
        this.groupId = groupId;
        this.artifactId = artifactId;
        this.version = version;
        this.classifier = classifier;
        this.path = path;
    }

    /**
     * Builds the {@link PromotionRecord} for this <code>Promotable</code> and calls either
     * {@link #onSuccess(hudson.model.TaskListener)} or {@link #onFailure(hudson.model.TaskListener)}
     */
    /** package **/ PromotionRecord createRecord(boolean successful, String msg, String path, TaskListener listener) {
        this.record = new PromotionRecord(this, successful, msg, path);

        if (successful) {
            onSuccess(listener);
        } else {
            onFailure(listener);
        }

        return this.record;
    }

    /**
     * Can be overloaded to implement logic on the successful promotion of the artifact. This is called by
     * {@link #createRecord(boolean, String, String, TaskListener)} so you'll have the {@link PromotionRecord}
     * to look at.
     *
     * Default is no-op.
     *
     * @see #onFailure(TaskListener)
     * @see #createRecord(boolean, String, String, hudson.model.TaskListener)
     */
    protected void onSuccess(TaskListener listener) {}

    /**
     * Can be overloaded to implement logic on the failed promotion of the artifact. Default is no-op.
     *
     * @see #onSuccess(hudson.model.TaskListener)
     * @see #createRecord(boolean, String, String, hudson.model.TaskListener)
     */
    protected void onFailure(TaskListener listener) {}

    /**
     * Returns the repositoryId this <code>Promotable</code> is headed for or was deployed in. You can overload this
     * method if you wish to return something aside from {@link #MBA_SNAPSHOTS_ID} or {@link #MBA_RELEASES_ID}.
     */
    public String getRepositoryId() {
        return version.endsWith("-SNAPSHOT") ? MBA_SNAPSHOTS_ID : MBA_RELEASES_ID;
    }

    /**
     * Returns the coordinates of the artifact as a single string: "${groupId}:${artifactId}:${version}[:${classifier}]
     */
    public String getCoordinates() {
        StringBuilder sb = new StringBuilder(groupId).append(":").append(artifactId).append(":").append(version);
        if (!StringUtils.isBlank(classifier))
            sb.append(":").append(classifier);
        return (sb.toString());
    }

    /**
     * Returns the {@link PromotionRecord} for the <code>Promotable</code>. This will be <code>null</code> if promotion
     * has not been attempted.
     */
    public PromotionRecord getRecord() {
        return record;
    }

    @Override
    public String toString() {
        return "Promotable{" +
                "groupId='" + groupId + '\'' +
                ", artifactId='" + artifactId + '\'' +
                ", version='" + version + '\'' +
                ", classifier='" + classifier + '\'' +
                ", path='" + path + '\'' +
                ", record=" + record +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Promotable)) return false;

        Promotable that = (Promotable) o;

        if (!artifactId.equals(that.artifactId)) return false;
        if (classifier != null ? !classifier.equals(that.classifier) : that.classifier != null) return false;
        if (!groupId.equals(that.groupId)) return false;
        if (!version.equals(that.version)) return false;
        if (!path.equals(that.path)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = groupId.hashCode();
        result = 31 * result + artifactId.hashCode();
        result = 31 * result + version.hashCode();
        result = 31 * result + path.hashCode();
        result = 31 * result + (classifier != null ? classifier.hashCode() : 0);
        return result;
    }
}
