package gmrt.mba.builds.plugin.artifacts;

import hudson.FilePath;
import hudson.Util;
import hudson.remoting.VirtualChannel;
import org.apache.tools.ant.types.FileSet;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Recursively lists all files relative to the indicated root. Can also be used locally by calling
 * {@link #invoke(java.io.File)}.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/19/11
 */
public class FindArtifactsCallable implements FilePath.FileCallable<List<String>> {

    final IncludesExcludes includesExcludes;

    public FindArtifactsCallable(IncludesExcludes includesExcludes) {
        this.includesExcludes = includesExcludes;
    }

    public List<File> invoke(File root) {

        String includes = joinPatterns(includesExcludes.includes).toString();
        String excludes = joinPatterns(includesExcludes.excludes).toString();

        FileSet fs = Util.createFileSet(root, includes, excludes);
        List<File> results = new LinkedList<File>();
        for (String f : fs.getDirectoryScanner().getIncludedFiles())
            results.add(new File(root, f).getAbsoluteFile());

        return results;

    }

    public List<String> invoke(File root, VirtualChannel channel) throws IOException, InterruptedException {
        List<File> found = invoke(root);
        List<String> uris = new ArrayList<String>(found.size());
        for (File file : found)
            uris.add(file.toURI().toString());
        return uris;
    }

    private StringBuilder joinPatterns(String[] patterns) {
        StringBuilder joined = new StringBuilder();
        for (String pattern : patterns) {
            if (joined.length() != 0) joined.append(",");
            joined.append(pattern);
        }
        return joined;
    }

}
