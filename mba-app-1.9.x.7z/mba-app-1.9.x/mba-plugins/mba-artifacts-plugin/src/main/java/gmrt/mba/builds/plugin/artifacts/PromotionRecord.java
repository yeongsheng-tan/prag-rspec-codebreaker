package gmrt.mba.builds.plugin.artifacts;

import gmrt.mba.Appliance;
import gmrt.mba.HostResolver;

import java.util.Date;

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 8/25/11
 */
public class PromotionRecord {

    public final Promotable parent;
    public final Date occurred;
    public final boolean successful;
    public final String msg;
    public final String path;

    public PromotionRecord(Promotable parent, boolean successful, String msg, String path) {
        this.parent = parent;
        this.occurred = new Date();
        this.successful = successful;
        this.msg = msg;
        this.path = path;
    }

    /**
     * Returns a URL that will search for the coordinates of the <code>Promotable</code> (minus classifier), relative
     * to the host returned by {@link gmrt.mba.HostResolver#getHost()}.
     */
    public String getSearchUrl() {
        HostResolver hr = Appliance.getInstance().getBean(Appliance.class, HostResolver.class);
        StringBuilder sb = new StringBuilder("http://").append(hr.getHost()).append("/artifacts/index.html#nexus-search;gav~").
                append(parent.groupId).append("~").append(parent.artifactId).append("~").append(parent.version).append("~~");
        return sb.toString();
    }

    /**
     * Returns a composed URL to access the promoted artifact.
     *
     * @return url <code>null</code> when promotion failed.
     */
    public String getUrl() {
        if (!successful)
            return null;
        HostResolver hr = Appliance.getInstance().getBean(Appliance.class, HostResolver.class);
        StringBuilder sb = new StringBuilder("http://").append(hr.getHost()).append("/artifacts/content/").
                append(parent.getRepositoryId()).append("/").append(path);
        return sb.toString();
    }

    @Override
    public String toString() {
        return "PromotionRecord{" +
                "occurred=" + occurred +
                ", successful=" + successful +
                ", msg='" + msg + '\'' +
                ", path='" + path + '\'' +
                '}';
    }
}
