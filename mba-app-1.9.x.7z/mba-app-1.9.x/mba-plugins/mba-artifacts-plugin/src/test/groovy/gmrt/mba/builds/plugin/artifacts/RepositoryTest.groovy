package gmrt.mba.builds.plugin.artifacts

import org.apache.log4j.Logger
import org.testng.Assert
import org.testng.annotations.BeforeSuite
import org.testng.annotations.Test

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 9/3/11
 */
class RepositoryTest {

  private static Logger LOG = Logger.getLogger(RepositoryTest.class);

  Repository repo;

  /**
   * Constructs a new {@link Repository} instance using the MBA_ARTIFACTS_GROUP environment variable. Will call
   * {@link Repository#updateIndex} if there is no local copy of it.
   */
  @BeforeSuite(groups = "SYSTEM_INTEGRATION")
  void prepare() {

    def repoDir = new File("target/test-data/${getClass().getName()}/mba-group")
    def idxExists = (new File(repoDir, ".index")).exists()

    repo = new Repository('mba-group',
            System.getenv()['MBA_ARTIFACTS_GROUP'].toURL(),
            repoDir);
    if (!idxExists)
      repo.updateIndex(System.out)

  }

  @Test(groups = "SYSTEM_INTEGRATION")
  void findPackagedAndResolveLatest() {

    def results = repo.find().groupId("gmrt.mba.plugins").packaging("hpi").grouped().collect { Ga ga, List<Gav> gavs ->
      println "${ga}:"
      gavs.each { gav ->
        println "\t${gav}"
      }

      if(!gavs.last().version.endsWith('-SNAPSHOT')){
          print "Resolving ${gavs.last()}: "
          repo.resolve(gavs.last().narrow('hpi', null)).with {
            Assert.assertTrue(it.exists())
            Assert.assertTrue(it.name.endsWith('.hpi'))
            println path
            it
          }
      }
    }
    Assert.assertTrue(results.size() > 0)


  }

  @Test(groups = "SYSTEM_INTEGRATION")
  void findFlat() {

    def results = repo.find().groupId("gmrt.mba.plugins").packaging("hpi").flat().collect { ga ->
      println ga
      Assert.assertEquals(ga.groupId, 'gmrt.mba.plugins')
    }
    Assert.assertTrue(results.size() > 0)

  }

  @Test(groups = "SYSTEM_INTEGRATION")
  void findGrouped() {

    repo.find().version("1.0-SNAPSHOT").grouped().each { Ga ga, List<Gav> gavs ->
      println "${ga}:"
      gavs.each { gav ->
        println "\t${gav}: ${gav.name} ${gav.description}"
      }
    }

  }

  @Test(groups = "SYSTEM_INTEGRATION")
  void findOneNotAnother() {
    def results = repo.find().groupId("gmrt.mba.plugins").not().artifactId("mba-artifacts-plugin").flat().collect { ga ->
      println ga
      Assert.assertNotSame("mba-artifacts-plugin", ga.artifactId);
    }
    Assert.assertTrue(results.size() > 0)
  }

}
