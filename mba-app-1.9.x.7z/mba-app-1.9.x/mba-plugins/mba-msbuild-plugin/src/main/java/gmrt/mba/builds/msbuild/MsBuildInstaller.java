package gmrt.mba.builds.msbuild;

import hudson.tools.DownloadFromUrlInstaller;
import hudson.tools.ToolInstallation;
import org.kohsuke.stapler.DataBoundConstructor;

/**
 * I'm not sure we event want to implement this. Doesn't msbuild have to be installed on the box already? If I'm
 * wrong you'll want to implement this class then fix
 * {@link MsBuildInstallation.DescriptorImpl#getDefaultInstallers()}
 *
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 6, 2010
 */
public class MsBuildInstaller extends DownloadFromUrlInstaller {

    /**
     * Will need to uncomment the extension if you wish to have an installer.
     */
    //@Extension
    public static class DescriptorImpl extends DownloadFromUrlInstaller.DescriptorImpl<MsBuildInstaller> {
        
        @Override
        public String getDisplayName() {
            return "Default MsBuild.exe in the system path";
        }

        @Override
        public boolean isApplicable(Class<? extends ToolInstallation> toolType) {
            return toolType.isAssignableFrom(MsBuildInstallation.class);
        }

    }

    @DataBoundConstructor
    public MsBuildInstaller(String id) {
        super(id);
    }
}
