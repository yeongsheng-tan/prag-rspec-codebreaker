package gmrt.mba.builds.msbuild;

//import hudson.ivy.builder.IvyBuilderType;
import hudson.Extension;
import hudson.ivy.builder.IvyBuilderType;
import hudson.ivy.builder.IvyBuilderTypeDescriptor;
import hudson.model.Environment;
import hudson.model.Hudson;
import hudson.tasks.Builder;
import net.sf.json.JSONObject;
import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.StaplerRequest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * Adapts the MSBuild plugin to the {@link IvyBuilderType} so we can call our {@link Builder} impl from Ivy.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 12/23/10
 */
public class MsBuildIvyBuilder extends IvyBuilderType {

    private transient MsBuildBuilder builder;

    @Extension
    public static class DescriptorImpl extends IvyBuilderTypeDescriptor {
        @Override
        public String getDisplayName() {
            return MsBuildBuilder.DescriptorImpl.DISPLAY_NAME;
        }

        public MsBuildInstallation[] getInstallations() {
            return Hudson.getInstance().getDescriptorByType(MsBuildInstallation.DescriptorImpl.class).getInstallations();
        }

        @Override
        public boolean configure(StaplerRequest req, JSONObject json) throws FormException {
            return super.configure(req, json);
        }
    }

    @DataBoundConstructor
    public MsBuildIvyBuilder(String name, String file, String cmdArgs) {
        this.builder = new MsBuildBuilder(name, file, cmdArgs);
    }

    @Override
    public Map<String, String> getEnvironment() {
        return new HashMap<String, String>();
    }

    @Override
    public Builder getBuilder(Properties additionalProperties, String overrideTargets, List<Environment> environment) {
        return builder;
    }
}
