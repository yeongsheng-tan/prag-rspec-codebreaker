package gmrt.mba.builds.msbuild;

import hudson.EnvVars;
import hudson.Extension;
import hudson.Launcher;
import hudson.model.EnvironmentSpecific;
import hudson.model.Hudson;
import hudson.model.Node;
import hudson.model.TaskListener;
import hudson.remoting.Callable;
import hudson.slaves.NodeSpecific;
import hudson.tools.ToolDescriptor;
import hudson.tools.ToolInstallation;
import hudson.tools.ToolInstaller;
import hudson.tools.ToolProperty;
import org.kohsuke.stapler.DataBoundConstructor;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

/**
 * Represents an installation of the msbuild tool on a slave.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 6, 2010
 */
public class MsBuildInstallation extends ToolInstallation
        implements EnvironmentSpecific<MsBuildInstallation>, NodeSpecific<MsBuildInstallation> {

    @Extension
    public static class DescriptorImpl extends ToolDescriptor<MsBuildInstallation> {

        @Override
        public String getDisplayName() {
            return "MsBuild";
        }

        /**
         * Shouldn't {@link ToolDescriptor} be handling this?
         */
        @Override
        public MsBuildInstallation[] getInstallations() {
            return Hudson.getInstance().getDescriptorByType(MsBuildBuilder.DescriptorImpl.class).getInstallations();
        }

        /**
         * Shouldn't {@link ToolDescriptor} be handling this?
         */
        @Override
        public void setInstallations(MsBuildInstallation... installations) {
            Hudson.getInstance().getDescriptorByType(MsBuildBuilder.DescriptorImpl.class).setInstallations(installations);
        }

        /**
         * Returns an empty list currently. I'm assuming you have to install MsBuild.exe from the Visual Studio
         * installer and it's not possible to "zip it up" for distribution? If I'm wrong we'll want to finish
         * implementing {@link MsBuildInstaller}.
         */
        @Override
        public List<? extends ToolInstaller> getDefaultInstallers() {
            //return Arrays.asList(new MsBuildInstaller(null));
            return Collections.emptyList();
        }
    }

    @DataBoundConstructor
    public MsBuildInstallation(String name, String home, List<? extends ToolProperty<?>> properties) {
        super(name, home, properties);
    }

    public MsBuildInstallation forEnvironment(EnvVars envVars) {
        return new MsBuildInstallation(getName(), envVars.expand(getHome()), getProperties().toList());
    }

    public MsBuildInstallation forNode(Node node, TaskListener taskListener) throws IOException, InterruptedException {
        return new MsBuildInstallation(getName(), translateFor(node, taskListener), getProperties().toList());
    }

    /**
     * Resolves the executable into a filepath on the executing node.
     */
    public String getExecutablePath(Launcher launcher, final String executableName)
            throws IOException, InterruptedException {
        return launcher.getChannel().call(new Callable<String, IOException>() {
            public String call() throws IOException {
                File exec = new File(getHome(), executableName);
                if (!exec.exists())
                    return null;
                return exec.getPath();
            }
        });
    }
}
