package gmrt.mba.builds.msbuild;

import hudson.CopyOnWrite;
import hudson.Extension;
import hudson.Launcher;
import hudson.Util;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.Builder;
import hudson.util.ArgumentListBuilder;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.StaplerRequest;

import java.io.IOException;
import java.util.Map;

/**
 * Implements a build step using MsBuild. This entire plugin was based on the existing Hudson MSBuild plugin that
 * seemed to have fallen far behind Hudson development.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 6, 2010
 */
public class MsBuildBuilder extends Builder {

    protected final static String MSBUILD_EXE = "MSBuild.exe";

    private String name;
    private String file;
    private String cmdArgs;

    @Extension
    public static class DescriptorImpl extends BuildStepDescriptor<Builder> {

        public static final String DISPLAY_NAME = "Execute MsBuild";

        @CopyOnWrite
        private volatile MsBuildInstallation[] installations = new MsBuildInstallation[0];

        public DescriptorImpl() {
            load();
        }

        @Override
        public String getDisplayName() {
            return DISPLAY_NAME;
        }

        @Override
        public boolean configure(StaplerRequest req, JSONObject formData) throws FormException {
            installations = req.bindParametersToList(MsBuildInstallation.class, "msbuild.").toArray(new MsBuildInstallation[0]);
            save();
            return true;
        }

        public MsBuildInstallation[] getInstallations() {
            return installations;
        }

        public void setInstallations(MsBuildInstallation[] installations) {
            this.installations = installations;
            save();
        }

        @Override
        public boolean isApplicable(Class<? extends AbstractProject> aClass) {
            return true;
        }
    }

    @DataBoundConstructor
    public MsBuildBuilder(String name, String file, String cmdArgs) {
        this.name = name;
        this.file = file;
        this.cmdArgs = cmdArgs;
    }

    @Override
    public boolean perform(AbstractBuild<?, ?> build, Launcher launcher, BuildListener listener)
            throws InterruptedException, IOException {

		// launcher instance refers to the MBA Appliance where the build was triggered
	    // To check/test if a target slave that will be running a build is a Unix box, assert if the
	    // leading build workspace remote path begins with a '/'
	    listener.getLogger().println("launcher.isUnix()" + launcher.isUnix());
	    if(StringUtils.startsWith(build.getWorkspace().getRemote(),"/")){
			listener.fatalError("MsBuild is not available on Unix slaves.");
			return false;
		}

        ArgumentListBuilder args = new ArgumentListBuilder();

        MsBuildInstallation mbi = (getMsBuildInstallation() != null) ?
                getMsBuildInstallation().forNode(build.getBuiltOn(), listener) : null;
        if (mbi == null) {
            listener.getLogger().println("MsBuild.exe installed path not defined for the tooling selected");
	        listener.getLogger().println("Assuming MsBuild.exe in the system path");
            args.add(getExecutableName());

        } else {

            String execPath = mbi.getExecutablePath(launcher, getExecutableName());
            if (execPath == null) {
                listener.fatalError(execPath + " doesn't exist");
                return false;
            }

            listener.getLogger().println("Using path to MsBuild.exe: " + execPath);
            args.add(execPath);

        }

        //Remove all tabs, carriage returns, and newlines and replace them with
        //whitespaces, so that we can add them as parameters to the executable
        String normalizedTarget = getCmdArgs().replaceAll("[\t\r\n]+", " ");
        if (normalizedTarget.trim().length() > 0)
            args.addTokenized(normalizedTarget);

        //If a msbuild file is specified, then add it as an argument, otherwise
        //msbuild will search for any file that ends in .proj or .sln
        if (getFile() != null && getFile().trim().length() > 0) {
            args.add(getFile());
        }

        //According to the Ant builder source code, in order to launch a program
        //from the command line in windows, we must wrap it into cmd.exe.  This
        //way the return code can be used to determine whether or not the build failed.
        args.prepend("cmd.exe", "/C");
        args.add("&&", "exit", "%%ERRORLEVEL%%");

        //Try to execute the command
        listener.getLogger().println("Executing command: " + args.toStringWithQuote());
        try {
            Map<String, String> env = build.getEnvironment(listener);
            int r = launcher.launch().cmds(args).envs(env).stdout(listener).pwd(build.getModuleRoot()).join();
            return r == 0;

        } catch (IOException e) {
            Util.displayIOException(e, listener);
            e.printStackTrace(listener.fatalError("command execution failed"));
            return false;
        }

    }

    /**
     * Returns the {@link MsBuildInstallation} specified by {@link #getName()}
     */
    protected MsBuildInstallation getMsBuildInstallation() {
        for (MsBuildInstallation mbi : ((DescriptorImpl) getDescriptor()).getInstallations()) {
            if (mbi.getName().equals(getName())) {
                return mbi;
            }
        }
        return null;
    }

    /**
     * The name of the {@link MsBuildInstallation} this step should execute.
     */
    public String getName() {
        return name;
    }

    /**
     * The build file to execute.
     */
    public String getFile() {
        return file;
    }

    /**
     * Arguments appended to the command executed.
     */
    public String getCmdArgs() {
        return cmdArgs;
    }

    /**
     * Name of the executable, defaults to {@link #MSBUILD_EXE}. Allowing configuration of this value is a security
     * risk and as such is not supported by default.
     */
    public String getExecutableName() {
        return MSBUILD_EXE;
    }
}
