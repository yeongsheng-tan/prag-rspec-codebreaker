package gmrt.mba.builds.msbuild;

import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;

/**
 * Beginnings of a project implementation for MSBuilds. This will get finished eventually, in the meantime we
 * should focus on the the new {@link hudson.tasks.Builder} we're creating: {@link MsBuildBuilder}.  
 *
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 6, 2010
 */
public class MsBuild<P extends AbstractProject<P,B>,B extends AbstractBuild<P,B>> extends AbstractBuild<P, B> {

    protected MsBuild(P job) throws IOException {
        super(job);
    }

    protected MsBuild(P job, Calendar timestamp) {
        super(job, timestamp);
    }

    protected MsBuild(P project, File buildDir) throws IOException {
        super(project, buildDir);
    }

    @Override
    public void run() {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
