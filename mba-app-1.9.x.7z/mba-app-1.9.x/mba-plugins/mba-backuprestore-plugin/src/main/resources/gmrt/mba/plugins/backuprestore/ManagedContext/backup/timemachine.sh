#!/bin/bash

date=`date "+%Y-%m-%dT%H_%M_%S"`

MBA_BACKUP_SRC=$JENKINS_HOME/..
MBA_BACKUP_TGT_ROOT=$JENKINS_HOME/../../backups
MBA_BACKUP_TGT=$MBA_BACKUP_TGT_ROOT/mba.backup-$date
SNAPSHOTS_COUNT_LIMIT=16
PURGE_OLDEST_COUNT=4

echo "JENKINS_HOME is defined as $JENKINS_HOME"
echo "Rsync backup source: $MBA_BACKUP_SRC"
echo "Rsync backup target root: $MBA_BACKUP_TGT_ROOT"
echo "Rsync backup target: $MBA_BACKUP_TGT"

# Attempt to locate $MBA_BACKUP_TGT_ROOT dir to where backups will be rsynced to, and create it if it is missing
if [ ! -d "$MBA_BACKUP_TGT_ROOT" ]; then
    mkdir $MBA_BACKUP_TGT_ROOT
fi

ls -lrt $MBA_BACKUP_TGT_ROOT

# Perform the rsync backup from $MBA_BACKUP_SRC to $MBA_BACKUP_TGT
rsync -avzP --stats --delete --delete-excluded --exclude-from './timemachine-exclude-list' --link-dest=$MBA_BACKUP_TGT_ROOT/current $MBA_BACKUP_SRC $MBA_BACKUP_TGT
rm -rf $MBA_BACKUP_TGT_ROOT/current
ln -s mba.backup-$date $MBA_BACKUP_TGT_ROOT/current

ls -lrt $MBA_BACKUP_TGT_ROOT

echo "Latest rsync backup snapshots available at $MBA_BACKUP_TGT_ROOT/current"

# Perform a purge on the oldest $PURGE_OLDEST_COUNT backup snapshots when the number of snapshots increases beyond $SNAPSHOTS_COUNT_LIMIT
if [ $(($SNAPSHOTS_COUNT_LIMIT - $PURGE_OLDEST_COUNT)) -gt 2 ] && [ $(($SNAPSHOTS_COUNT_LIMIT - $PURGE_OLDEST_COUNT)) -gt $PURGE_OLDEST_COUNT ]; then
	if [[ $(ls $MBA_BACKUP_TGT_ROOT | wc -l) -gt $SNAPSHOTS_COUNT_LIMIT ]]; then
		echo "Purging oldest $PURGE_OLDEST_COUNT MBA backup snapshots..."
		cd $MBA_BACKUP_TGT_ROOT
		stat -c "%Y %n" * | sort -n | head -n +$PURGE_OLDEST_COUNT | cut -d ' ' -f 1 --complement | xargs -d '\n' rm -rf
		echo "Purge completed."
		ls -lrt $MBA_BACKUP_TGT_ROOT
	fi
fi
