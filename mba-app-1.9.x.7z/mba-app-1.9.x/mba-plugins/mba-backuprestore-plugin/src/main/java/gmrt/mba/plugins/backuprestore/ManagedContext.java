package gmrt.mba.plugins.backuprestore;

/**
 * @author yeongsheng.tan@baml.com
 * @since 4/8/11
 */
public interface ManagedContext extends gmrt.da.ManagedContext  {
}
