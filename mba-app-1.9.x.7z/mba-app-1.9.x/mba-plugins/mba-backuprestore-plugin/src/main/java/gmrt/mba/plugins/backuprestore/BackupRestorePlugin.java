package gmrt.mba.plugins.backuprestore;

import gmrt.code.builds.plugin.builds.BuildsEnvAction;
import gmrt.code.builds.plugin.builds.BuildsWorkerAction;
import gmrt.code.builds.plugin.builds.ChmodPlusX;
import gmrt.code.builds.plugin.builds.SettingsHelper;
import gmrt.mba.Appliance;
import gmrt.mba.Config;
import gmrt.mba.HostResolver;
import gmrt.mba.auth.WorkerRealm;
import hudson.BulkChange;
import hudson.FilePath;
import hudson.Plugin;
import hudson.model.*;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author yeongsheng.tan@baml.com
 * @since 4/6/11
 */
public class BackupRestorePlugin extends Plugin {
	private static Logger LOG = Logger.getLogger(BackupRestorePlugin.class);
	private static final String mbaBackupJobName = "_mba.backup";
	private static final String mbaRestoreJobName = "_mba.restore";

	//Backup-Restore jobs config map
	private static Map<String,List> jobsConfigMap=new HashMap();

	private transient SettingsHelper settingsHelper = new SettingsHelper();

	@Override
	public void postInitialize() throws Exception {
		//Begin the transaction context for a Hudson config bulk change
		Hudson jenkins_instance = Hudson.getInstance();
		BulkChange bc = new BulkChange(jenkins_instance);

		//delete deprecated MBA.Backup and MBA.Restore jobs
		LOG.info("[MBA] Delete deprecated Backup & Restore jobs.");
		doDeleteDeprecatedBackupRestoreJobs(jenkins_instance);

		//Setup and initialize the jobsConfigMap
		Config config = Appliance.getInstance().getConfig();
		String backupJobConfigXmlPath="";
		String restoreJobConfigXmlPath="";
		List<Resource> backupJobRunSupportFiles = new ArrayList();
		List<Resource> restoreJobRunSupportFiles = new ArrayList();

		if(BackupRestorePluginConstants.mbaAntBackupStrategy.equalsIgnoreCase(config.getMbaBackupStrategy())){
			//backup job config
			// Ant-based CODE/Builds backup strategy
			backupJobConfigXmlPath = "classpath:gmrt/mba/plugins/backuprestore/ManagedContext/backup/config.ant.xml";
			String backupJobAntBuildXmlPath = "classpath:gmrt/mba/plugins/backuprestore/ManagedContext/backup/build.backup.mba.nexus.xml";
			backupJobRunSupportFiles.add(Appliance.getInstance().getContext(ManagedContext.class).getResource(backupJobAntBuildXmlPath));

			//restore job config
			restoreJobConfigXmlPath = "classpath:gmrt/mba/plugins/backuprestore/ManagedContext/restore/config.ant.xml";
			String restoreJobAntBuildXmlPath = "classpath:gmrt/mba/plugins/backuprestore/ManagedContext/restore/build.restore.mba.nexus.xml";
			restoreJobRunSupportFiles.add(Appliance.getInstance().getContext(ManagedContext.class).getResource(restoreJobAntBuildXmlPath));
		}else{
			//backup job config
			// Rsync-timemachine-based CODE/Builds backup strategy
			backupJobConfigXmlPath = "classpath:gmrt/mba/plugins/backuprestore/ManagedContext/backup/config.timemachine.xml";
			String backupJobRsyncShellPath = "classpath:gmrt/mba/plugins/backuprestore/ManagedContext/backup/timemachine.sh";
			String backupJobRsyncExcludeFilesetPath = "classpath:gmrt/mba/plugins/backuprestore/ManagedContext/backup/timemachine-exclude-list";

			backupJobRunSupportFiles.add(Appliance.getInstance().getContext(ManagedContext.class).getResource(backupJobRsyncShellPath));
			backupJobRunSupportFiles.add(Appliance.getInstance().getContext(ManagedContext.class).getResource(backupJobRsyncExcludeFilesetPath));
		}
		jobsConfigMap.put(mbaBackupJobName,backupJobRunSupportFiles);
		jobsConfigMap.put(mbaRestoreJobName,restoreJobRunSupportFiles);

		//first delete any existing jobs
		LOG.info("[MBA] Delete existing Job: " + mbaBackupJobName);
		doDeleteMbaBackupRestoreJob(jenkins_instance, mbaBackupJobName);
		LOG.info("[MBA] Delete existing Job: " + mbaRestoreJobName);
		doDeleteMbaBackupRestoreJob(jenkins_instance, mbaRestoreJobName);

		//recreate both the Backup and Restore jobs
		LOG.info("[MBA] Create new Job: " + mbaBackupJobName);
		doCreateMbaBackupRestoreJob(jenkins_instance,mbaBackupJobName,Appliance.getInstance().getContext(ManagedContext.class).getResource(backupJobConfigXmlPath).getInputStream());
		//LOG.info("Create new Job: " + mbaRestoreJobName);
		//doCreateMbaBackupRestoreJob(mbaRestoreJobName,Appliance.getInstance().getContext(ManagedContext.class).getResource(restoreJobConfigXmlPath).getInputStream());

		//Perform the Hudson config bulk change transaction commit
		bc.commit();
	}

	private void doDeleteDeprecatedBackupRestoreJobs(Hudson jenkins){
		BuildJob job = new BuildJob(jenkins);
		job.deleteDeprecatedBackupRestoreJobs();
	}

	public void doCreateMbaBackupRestoreJob(Hudson jenkins, String jobName, InputStream jobConfigXmlPath) throws InterruptedException, IOException{
		BuildJob j = new BuildJob(jenkins);
		TopLevelItem t = j.createJob(jobName,jobConfigXmlPath);
		j.writeBuildXmlSettings(jobName);
		LOG.info("[MBA] Successfully created Job: " + jobName);
	}

	public void doDeleteMbaBackupRestoreJob(Hudson jenkins, String jobName) throws IOException{
		BuildJob jb = new BuildJob(jenkins);
		jb.deleteJob(jobName);
		LOG.info("[MBA] Successfully deleted Job: " + jobName);
	}

	private Map<String, Object> getSettingsBinding() {
        Map<String, Object> binding = new HashMap<String, Object>();
        binding.put("appliance", Appliance.getInstance());
        binding.put("hostResolver", Appliance.getInstance().getBean(Appliance.class, HostResolver.class));
        return binding;
    }

	private void writeSettings(String id, String template, Map<String, Object> binding, FilePath target, TaskListener listener)
            throws IOException, InterruptedException {

        String buildSupportResource = settingsHelper.processTemplate(id, template, binding, listener);

        listener.getLogger().println("[MBA] Writing " + id + " to: " + target.getRemote());
        target.write(buildSupportResource, "UTF-8");
		// if resource is a shell or executable to be run on linux node, make it executable
		if(target.getName().endsWith(".sh")){
			listener.getLogger().println("[MBA] Setting executable bit +X on " + target.getRemote() + " ...");
			target.act(new ChmodPlusX());
		}
    }

	private String getBuildSettingsSupportContents(Resource buildSupportResource) throws IOException{
		return FileUtils.readFileToString(buildSupportResource.getFile(),"UTF-8");
	}

    /**
     * Returns the absolute path of the ant build.xml/rsync shell and exclude fileset filter file/s for the given build (either build.backup.mba.nexus.xml or build.restore.mba.nexus.xml, or whatever the desired build xml settings).
     */
    public FilePath getBuildSettingsPath(Node node, String jobName, String buildSupportFileName) throws IOException, InterruptedException {
	    BuildsWorkerAction bwa = BuildsWorkerAction.getInstance(node);
	    LOG.info("[MBA] Build support filename: "+buildSupportFileName);
	    LOG.info("[MBA] Builds worker HOME: "+bwa.getHome());
	    LOG.info("[MBA] Path to stream and output build support file: "+bwa.getHome().getParent().getParent().child("workspace").child(jobName).child(buildSupportFileName).absolutize());
	    return bwa.getHome().getParent().getParent().child("workspace").child(jobName).child(buildSupportFileName).absolutize();
    }

	/**
     * Writes the CODE/Builds Backup/Restore job ant build.xml/rsync shell and exclude fileset filter file/s to the expected location for the specified build.
     */
    public FilePath writeJobBuildSupportSettings(Node node, AbstractBuild build, TaskListener listener)throws IOException, InterruptedException {
        WorkerRealm realm = Appliance.getInstance().getBean(gmrt.mba.auth.ManagedContext.class, WorkerRealm.class);
        BuildsEnvAction ba = build.getAction(BuildsEnvAction.class);

        Map<String, Object> binding = getSettingsBinding();
        binding.put("build", build);
        binding.put("worker", realm.getUser(ba.env.get(BuildsEnvAction.MBA_WORKER_USER)));

	    String jobName=build.getProject().getName();
	    //LOG.info("jobName="+jobName);
	    //LOG.info("jobsConfigMap.get(jobName).getFilename()=" + jobsConfigMap.get(jobName).getFilename());
	    FilePath remoteSettings = null;
	    List<Resource> resourceList = (List<Resource>)jobsConfigMap.get(jobName);
	    for (Resource r : resourceList){
            remoteSettings = getBuildSettingsPath(node,jobName,r.getFilename());
            writeSettings("CODE/Builds backup/restore build job support settings resources", getBuildSettingsSupportContents(r), binding, remoteSettings, listener);
	    }
        return remoteSettings;
    }

    public static BackupRestorePlugin getInstance() {
        return Hudson.getInstance().getPlugin(BackupRestorePlugin.class);
    }
}

