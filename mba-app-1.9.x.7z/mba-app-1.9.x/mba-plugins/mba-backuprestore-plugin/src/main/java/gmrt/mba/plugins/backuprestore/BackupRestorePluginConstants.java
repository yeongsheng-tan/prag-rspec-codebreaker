package gmrt.mba.plugins.backuprestore;

/**
 * @author yeongsheng.tan@baml.com
 * @since 10/31/11
 */
public class BackupRestorePluginConstants {
	public static final String mbaAntBackupStrategy="ant";
	public static final String mbaRsyncBackupStrategy="rsync";
}
