package gmrt.mba.plugins.backuprestore

import hudson.model.Hudson
import hudson.model.TopLevelItem
import org.apache.log4j.Logger

/**
 * Convenience class to construct/destroy a Jenkins build project.
 *
 * @author yeongsheng.tan@baml.com
 * @since 4/7/11
 */
class BuildJob {
	def static Logger LOG = Logger.getLogger(BuildJob.class)
	private Hudson h;

	public BuildJob(Hudson jenkins_instance){
		h = jenkins_instance
	}

	public TopLevelItem createJob(String jobName, InputStream jobConfig){
		if (getJob(jobName)!=null) {
            LOG.info("Job '${jobName}' already exists")
            return null
        }
		TopLevelItem tli = h.createProjectFromXML(jobName,jobConfig)
		h.save()
		h.reload()
		return tli
	}

	public TopLevelItem getJob(String jobName){
		return h.getItem(jobName)
	}

	public void deleteJob(String jobName){
		TopLevelItem job = h.getItem(jobName)
		if(job!=null){
			job.delete()
			h.save()
			h.reload()
		}
	}

	public void createJobWorkspaceDir(TopLevelItem tli){
		def fp = h.getWorkspaceFor(tli)
		if(!fp.exists())
			fp.mkdirs()
	}

	public void writeBuildXmlSettings(String jobName){
		def project = h.projects.find{ jobName.equals(it.getDisplayName()) }
		if(project!=null)
			project.getBuildWrappersList().replace(new BackupRestoreBuildWrapper())
		h.save()
		h.reload()
	}

	public void deleteDeprecatedBackupRestoreJobs(){
		deleteJob("MBA.Backup")
		deleteJob("MBA.Restore")
	}
}
