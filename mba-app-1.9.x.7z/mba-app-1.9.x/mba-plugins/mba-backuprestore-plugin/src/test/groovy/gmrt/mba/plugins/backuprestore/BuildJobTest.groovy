package gmrt.mba.plugins.backuprestore

import gmrt.mba.Appliance
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil
import hudson.model.Hudson
import org.apache.commons.io.FileUtils
import org.apache.log4j.Logger
import org.mockito.Mock
import org.mockito.Mockito
import org.powermock.api.mockito.PowerMockito
import org.powermock.core.classloader.annotations.PrepareForTest
import org.powermock.modules.testng.PowerMockTestCase
import org.testng.annotations.AfterSuite
import org.testng.annotations.BeforeMethod
import org.testng.annotations.BeforeSuite
import org.testng.annotations.Test

/**
 * @author yeongsheng.tan@baml.com
 * @since 9/6/11
 */
@PrepareForTest([Hudson.class, BuildJob.class])
class BuildJobTest extends PowerMockTestCase {
	private static Logger LOG = Logger.getLogger(BuildJobTest.class)
	Appliance appliance
	@Mock
	Hudson jenkinsMock
	@Mock
	BuildJob buildJobMock

	@BeforeSuite
	void setUp() {
		appliance = Appliance.instance
	}

	@AfterSuite
	void tearDown() {
		appliance.close()
	}

    @BeforeMethod
    void setupBuildJobConfigXml() {
		def xmlBuilder = new StreamingMarkupBuilder()
		xmlBuilder.encoding = "UTF-8"
		def project = {
			project(){
				actions()
				description()
				logRotator()
				keepDependencies(false)
				scm(class:"hudson.scm.NullSCM")
				canRoam(true)
				disabled(false)
				blockBuildWhenDownstreamBuilding(false)
				blockBuildWhenUpstreamBuilding(false)
				jdk("default")
				triggers()
				concurrentBuild(false)
				builders()
				publishers()
				buildWrappers()
			}
		}
	    def writer = new FileWriter("config.xml")
	    writer << xmlBuilder.bind(project)
	}

	@Test
	void createAJob(){
		PowerMockito.mockStatic(Hudson.class);
		PowerMockito.when(Hudson.getInstance()).thenReturn(jenkinsMock);

		PowerMockito.mock(BuildJob.class);
		PowerMockito.whenNew(BuildJob.class).withArguments(Hudson.getInstance()).thenReturn(buildJobMock);

		appliance.getContext(gmrt.code.builds.plugin.builds.ManagedContext.class, gmrt.mba.plugins.backuprestore.ManagedContext.class);
		File jobConfigFile = new File("config.xml")
		if(jobConfigFile.exists() && jobConfigFile.size()>0){
			LOG.info("Contents of Job config.xml:\n" + XmlUtil.serialize(new StreamingMarkupBuilder().bind { mkp.yield new XmlSlurper().parseText(FileUtils.readFileToString(jobConfigFile))}))
			LOG.info("Test create a new job 'testjob'")
			// Invoke doCreateMbaBackupRestoreJob method
			BackupRestorePlugin brp = new BackupRestorePlugin()
			FileInputStream fisJobConfig = new FileInputStream(jobConfigFile)
			brp.doCreateMbaBackupRestoreJob(jenkinsMock, "testjob",fisJobConfig)
			// Verify on mocked jenkins object that the createProjectFromXML() method was invoked
			Mockito.verify(jenkinsMock).createProjectFromXML("testjob",fisJobConfig);
		}
	}
}
