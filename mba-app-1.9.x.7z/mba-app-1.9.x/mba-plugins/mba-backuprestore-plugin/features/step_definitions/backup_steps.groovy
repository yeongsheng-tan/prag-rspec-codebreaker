package gmrt.mba.plugins.backuprestore

import static org.junit.Assert.assertThat
import static org.junit.matchers.JUnitMatchers.containsString

//import gmrt.mba.plugins.backuprestore.pages.*

/**
 * 	This is the steps definition code implementation
 *
 * @author yeongsheng.tan@baml.com
 * @since 9/6/11
*/

this.metaClass.mixin(cuke4duke.GroovyDsl)

Given(~"I am on the MBA Master Computer") { ->
	to MBAHomePage
	waitFor { at(MBAHomePage) }
}

When(~"I trigger a \"(.*)\"") { String query ->
	//TO-DO: Implement geb page access to locate the backup job and click on the job run button/link
	//page.projects.value(query)
	//page.runJobButton.click()
}

Then(~"I will get a job run to \"(.*)\" completion") { String text ->
	waitFor { page.results }
	assertThat page.resultLink(0).text(), containsString(text)
}

Then(~"I will get a  \"(.*)\" archive containing the configuration files") { String text ->
	//TO-DO: Implement geb page access to locate the mba-backup.zip archive in Artifacts mba-backup repository
}