package gmrt.code.builds.plugin.builds;

import com.trilead.ssh2.Connection;
import gmrt.mba.Appliance;
import gmrt.mba.Config;
import hudson.Extension;
import hudson.init.InitMilestone;
import hudson.init.Initializer;
import hudson.model.TaskListener;
import hudson.plugins.sshslaves.JavaProvider;
import hudson.plugins.sshslaves.SSHLauncher;
import hudson.remoting.Callable;
import hudson.slaves.SlaveComputer;
import org.apache.log4j.Logger;

import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Points to a "known" Java location for ssh workers. Removes the {@link SSHLauncher.DefaultJavaProvider} from
 * {@link JavaProvider#all} because it's not very intelligent and adds the comma delimited list of paths found in the
 * {@link gmrt.mba.Builds#getWorkerJdkUnix()} or {@link gmrt.mba.Builds#getWorkerJdkWin()} attributes.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/13/11
 */
@Extension
public class SshJavaProvider extends JavaProvider {

    private static final Logger LOG = Logger.getLogger(SshJavaProvider.class);

    @Initializer(after = InitMilestone.PLUGINS_PREPARED)
    public static void Setup() {

        SSHLauncher.DefaultJavaProvider defaultJavaProvider =
                JavaProvider.all().get(SSHLauncher.DefaultJavaProvider.class);
        if (defaultJavaProvider != null) {
            LOG.info("Removing the " + defaultJavaProvider.getClass().getName());
            JavaProvider.all().remove(defaultJavaProvider);
        }

    }

    @Override
    public List<String> getJavas(SlaveComputer computer, TaskListener listener, Connection connection) {

        Config config = Appliance.getInstance().getConfig();

        // We can't use {@link SlaveComputer#isUnix()} yet because technically we're not "connected" so we're doing
        // our own test.
        Boolean isUnix;
        try {
            listener.getLogger().println("[MBA] Attempting to determine worker OS type ...");
            isUnix = (connection.exec("uname -a", listener.getLogger()) == 0);
        } catch (Throwable throwable) {
            listener.error("[MBA] An exception occured attempting to determine the worker OS type: %s", throwable);
            return new LinkedList<String>();
        }

        List<String> javas = Arrays.asList((isUnix) ?
                config.getBuilds().getWorkerJdkUnix().split(",") : config.getBuilds().getWorkerJdkWin().split(","));
        for (String java : javas) {
            listener.getLogger().println("[MBA] Providing worker JDK option: " + java);
        }
        return javas;

    }

}
