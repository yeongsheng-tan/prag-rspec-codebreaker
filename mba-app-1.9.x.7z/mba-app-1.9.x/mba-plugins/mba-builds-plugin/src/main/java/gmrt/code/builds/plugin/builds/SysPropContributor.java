package gmrt.code.builds.plugin.builds;

import hudson.ExtensionList;
import hudson.ExtensionPoint;
import hudson.model.Hudson;
import hudson.model.Node;

import java.io.IOException;
import java.util.Map;

/**
 * An {@link ExtensionPoint} that is called when Nodes come online so their system properties can be modified.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/23/11
 */
public abstract class SysPropContributor implements ExtensionPoint {

    /**
     * Make changes to the {@link Map} instance as needed- they will be sent back to the worker and set.
     */
    public abstract void contribute(Node node, Map<String,String> properties) throws IOException, InterruptedException;

    public static ExtensionList<SysPropContributor> all() {
        return Hudson.getInstance().getExtensionList(SysPropContributor.class);
    }

}
