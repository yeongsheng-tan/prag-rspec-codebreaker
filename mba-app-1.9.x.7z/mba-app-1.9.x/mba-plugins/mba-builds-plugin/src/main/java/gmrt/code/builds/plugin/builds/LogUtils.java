//package gmrt.code.builds.plugin.builds;
//
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
//
//import java.io.PrintStream;
//
///*
// * Maintains a handle to log and streams to workers being launched.
// *
// * @author Eladio Martin
// */
//public class LogUtils {
//
//    private static Log LOGGER = null;
//
//    public PrintStream printStreamLogger = null;
//
//    public LogUtils() {
//    }
//
//    public void setLogger(java.lang.Class clazz) {
//        LOGGER = LogFactory.getLog(clazz);
//    }
//
//    public void setLogger(java.lang.Class clazz, PrintStream printStreamLogger) {
//        setLogger(clazz);
//
//        if (this.printStreamLogger == null) {
//            this.printStreamLogger = printStreamLogger;
//        }
//    }
//
//    public void printLogger(String message) {
//        LOGGER.info(message);
//        printStreamLogger.println(message);
//    }//private void printLogger
//
//    public void printLoggerError(String message) {
//        LOGGER.error(message);
//        printStreamLogger.println(message);
//    }//private void printLoggerError
//}