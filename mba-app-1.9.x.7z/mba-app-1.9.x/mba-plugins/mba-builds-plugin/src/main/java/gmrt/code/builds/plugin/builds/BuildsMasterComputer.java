package gmrt.code.builds.plugin.builds;

/**
 * Represents a {@link hudson.model.Computer} that runs as a process on the master node.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/25/11
 */
public class BuildsMasterComputer extends BuildsComputer {

    public BuildsMasterComputer(BuildsMasterWorker slave) {
        super(slave);
    }

    @Override
    public BuildsMasterWorker getWorker() {
        return (BuildsMasterWorker)super.getWorker();
    }
}
