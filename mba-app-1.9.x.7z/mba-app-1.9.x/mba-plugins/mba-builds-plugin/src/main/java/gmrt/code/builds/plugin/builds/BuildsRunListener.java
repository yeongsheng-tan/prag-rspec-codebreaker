package gmrt.code.builds.plugin.builds;

import gmrt.mba.Appliance;
import gmrt.mba.HostResolver;
import gmrt.mba.auth.WorkerRealm;
import hudson.Extension;
import hudson.Launcher;
import hudson.model.*;
import hudson.model.listeners.RunListener;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Adds the {@link BuildsEnvAction} and {@link BuildsWrapper} to all (wrappable) builds.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 7/19/11
 */
@Extension
public class BuildsRunListener extends RunListener<AbstractBuild<? extends AbstractProject<?, ?>, ?>> {

    /**
     * Adds the {@link BuildsWrapper} to wrappable projects that don't already have it.
     */
    @Override
    public void onStarted(AbstractBuild<? extends AbstractProject<?, ?>, ?> build, TaskListener listener) {

        if (build.getProject() instanceof BuildableItemWithBuildWrappers) {
            BuildableItemWithBuildWrappers project = (BuildableItemWithBuildWrappers) build.getProject();
            if (project.getBuildWrappersList().get(BuildsWrapper.class) == null) {
                try {
                    project.getBuildWrappersList().add(new BuildsWrapper());
                } catch (IOException e) {
                    listener.fatalError("[MBA] Exception occured adding the BuildsWrapper: %s", e.getMessage());
                }
            }
        }

    }

    /**
     * Configures the environment variables and add the {@link BuildsEnvAction} to all builds.
     */
    @Override
    public Environment setUpEnvironment(final AbstractBuild build, final Launcher launcher, final BuildListener listener)
            throws IOException, InterruptedException {

        if (build.getExecutor() != null) {
            Computer workerComputer = build.getExecutor().getOwner();
            BuildsWorkerAction bac = BuildsWorkerAction.getInstance(workerComputer);

            listener.getLogger().println("[MBA] Configuring build environment for worker " + workerComputer.getHostName());

            HostResolver hostResolver = Appliance.getInstance().getBean(Appliance.class, HostResolver.class);

	        if (workerComputer == Hudson.getInstance().toComputer()) {
                listener.error("[MBA] Executing builds on the master node is not supported. Please use the label " + BuildsMasterWorker.MBA_MASTER_WORKER_LABEL + " to run builds on the master.");
                throw new InterruptedException("Attempt to execute build on the master node.");
            }

	        /* CODE-2048
            // 2) allows 2 executors per slave
            */
            int numExecutors = workerComputer.getNumExecutors();
            //if (numExecutors > 1) {
	        if (numExecutors > 2) {
                listener.error("[MBA] The worker this build is executing on has " + numExecutors + " executors configured where only 2 executors per worker is supported.");
                throw new InterruptedException("Attempt to execute build on node with " + numExecutors + " executors configured.");
            }

            WorkerRealm realm = Appliance.getInstance().getBean(gmrt.mba.auth.ManagedContext.class, WorkerRealm.class);
            gmrt.da.auth.User worker = realm.getWorkerUser();

            HashMap<String, String> env = new HashMap<String, String>();

            env.put(BuildsEnvAction.MBA_HOSTNAME, hostResolver.getName());
            env.put(BuildsEnvAction.MBA_HOSTPORT, Integer.toString(hostResolver.getPort()));
            env.put(BuildsEnvAction.MBA_ARTIFACTS_RELEASES, "http://" + hostResolver.getHost() + "/artifacts/content/repositories/mba-releases");
            env.put(BuildsEnvAction.MBA_ARTIFACTS_SNAPSHOTS, "http://" + hostResolver.getHost() + "/artifacts/content/repositories/mba-snapshots");
            env.put(BuildsEnvAction.MBA_ARTIFACTS_GROUP, "http://" + hostResolver.getHost() + "/artifacts/content/groups/mba-group");
            env.put(BuildsEnvAction.MBA_ARTIFACTS_BACKUP, getMbaBackupRepoUrl(hostResolver));

            env.put(BuildsEnvAction.MBA_WORKER_USER, worker.getUserId());
            env.put(BuildsEnvAction.MBA_WORKER_CRED, worker.getCredentials().toString());
            env.put(BuildsEnvAction.MBA_WORKER_REALM, WorkerRealm.MBA_WORKER_REALM);

            env.put(BuildsEnvAction.MBA_WORKER_HOME, bac.getHome().getRemote());
            env.put(BuildsEnvAction.MBA_WORKER_HOST, workerComputer.getHostName());

            env.put(BuildsEnvAction.MBA_VERSION, getMbaVersion());
            env.put(BuildsEnvAction.MBA_UPDATE_CENTER_URL, getMbaUpdateCenterUrl());

            BuildsEnvAction action = new BuildsEnvAction(env);
            build.getActions().add(action);
        }

        return new Environment() {
            @Override
            public void buildEnvVars(Map<String, String> existingEnv) {
                BuildsEnvAction buildsAction = build.getAction(BuildsEnvAction.class);
                existingEnv.putAll(buildsAction.env);
            }
        };
    }

    public String getMbaVersion() {
        return Appliance.getInstance().getConfig().getVersion().getBase();
    }

    public String getMbaBackupRepoUrl(HostResolver hr) {
        return "http://" + hr.getHost() + "/artifacts/content/repositories/mba-backup";
    }

    public String getMbaUpdateCenterUrl() {
        return "http://" + Appliance.getInstance().getConfig().getMbaUpdateHost() + ":" + Appliance.getInstance().getConfig().getMbaUpdatePort() + "/builds/userContent/updateCenter";
    }
}
