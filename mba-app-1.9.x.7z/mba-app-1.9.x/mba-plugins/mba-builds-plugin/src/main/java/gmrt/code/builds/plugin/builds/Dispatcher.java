//package gmrt.code.builds.plugin.builds;
//
///**
// * Data object for worker connecting to dispatcher.
// *
// * User: Eladio Martin
// * Date: 1/25/12
// * Time: 8:57 AM
// */
//public class Dispatcher {
//    public String workerName;
//    public String computerUrl;
//    public String label;
//    public ConnectStatusTypes status;
//    public long timeStamp;
//
//     /**
//     * Number of times the request is in the wait state...
//     */
//    public long retryCount=0;
//
//    public Dispatcher(){}
//}
