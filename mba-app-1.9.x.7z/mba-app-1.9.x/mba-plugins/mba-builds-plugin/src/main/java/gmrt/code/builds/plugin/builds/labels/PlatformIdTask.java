package gmrt.code.builds.plugin.builds.labels;

import hudson.remoting.Callable;

import java.io.IOException;

/**
 * Retrieves the system properties needed to compute a platform id for the remote worker.
 *
 * @author jason.stiefel@bankofamerica.com
 * @see PlatformIdComposer
 * @since 2/3/11
 */
public class PlatformIdTask implements Callable<String, IOException> {

    /**
     * Returns "${osArch}|${osBits}|${osName}|${osVersion}
     */
    public String call() {
        String osArch = System.getProperty("os.arch");
        String osBits = System.getProperty("sun.arch.data.model");
        String osName = System.getProperty("os.name");
        String osVersion = System.getProperty("os.version");
        return new StringBuilder(osArch).append("|").append(osBits).append("|").append(osName).append("|").append(osVersion).toString();
    }

}

