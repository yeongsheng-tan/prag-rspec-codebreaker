//package gmrt.code.builds.plugin.builds;
//
///**
// * Possible states for worker connecting to dispatcher
// *
// * User: Eladio Martin
// * Date: 1/26/12
// * Time: 1:38 PM
// */
//public enum ConnectStatusTypes {
//    connecting,
//    connected,
//    error;
//}
