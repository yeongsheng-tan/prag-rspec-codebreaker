//package gmrt.code.builds.plugin.builds;
//
//import hudson.Extension;
//import hudson.model.Descriptor;
//import hudson.model.TaskListener;
//import hudson.slaves.ComputerLauncher;
//import hudson.slaves.SlaveComputer;
//import org.kohsuke.stapler.DataBoundConstructor;
//
//import java.io.IOException;
//import java.net.URISyntaxException;
//import java.util.Date;
//
///**
// * {@link hudson.slaves.ComputerLauncher} that submits remote slave requests to the Dispatcher.
// *
// * @author Rob Futrick <robert.futrick@baml.com>
// */
//public class DispatcherWorkerLauncher extends ComputerLauncher {
//
//    private final LogUtils logUtils = new LogUtils();
//
//    @Extension
//    public static final Descriptor<ComputerLauncher> DESCRIPTOR = new Descriptor<ComputerLauncher>() {
//        public String getDisplayName() {
//            return "MBS Grid Launcher";
//        }
//    };
//
//    @DataBoundConstructor
//    public DispatcherWorkerLauncher() {}
//
//    @Override
//    public boolean isLaunchSupported() {
//        return true;
//    }
//
//    @Override
//    public void afterDisconnect(SlaveComputer computer, TaskListener listener) {
//        logUtils.printLogger(String.format(
//                "afterDisconnect: Disconnecting Worker for : %s",
//                computer.getName()));
//
//        DispatcherAvailability.getInstance().removeWorkerFromLaunchTracker(computer.getName());
//    }
//
//    @Override
//    public void launch(SlaveComputer computer, TaskListener listener)
//            throws IOException {
//        logUtils.setLogger(DispatcherWorkerLauncher.class, listener.getLogger());
//        logUtils.printLogger(String.format(
//                "launch: thread id: %s \t Worker : %s",
//                Thread.currentThread().getName(),
//                computer.getName()));
//
//        Dispatcher dispatcher = new Dispatcher();
//        dispatcher.workerName = computer.getName();
//        dispatcher.computerUrl = computer.getUrl();
//        dispatcher.label = computer.getNode().getLabelString();
//
//        Date date = new Date();
//        dispatcher.timeStamp = date.getTime();
//
//        dispatcherExecution(dispatcher);
//    }//public void launch
//
//    private synchronized void dispatcherExecution(Dispatcher dispatcher) {
//        while (DispatcherAvailability.getInstance().getAvailable) {
//            try {
//                wait(10000);
//                dispatcher.retryCount++;
//                logUtils.printLogger(String.format(
//                        "Worker has been waiting %s, thread id:%s - %s for label: %s",
//                        dispatcher.retryCount,
//                        Thread.currentThread().getName(),
//                        dispatcher.workerName,
//                        dispatcher.label));
//            } catch (InterruptedException interruptedException) {
//                logUtils.printLoggerError("InterruptedException:" + interruptedException.getMessage());
//                throw new RuntimeException("InterruptedException caught while trying to wait.");
//            }
//        }//while (DispatcherAvailability.getInstance().getAvailable) {
//
//        DispatcherAvailability.getInstance().getAvailable = true;
//
//        connectWorker(dispatcher);
//
//        DispatcherAvailability.getInstance().getAvailable = false;
//        notifyAll();
//    }
//
//    private void connectWorker(
//            Dispatcher dispatcher) {
//        if (DispatcherAvailability.getInstance().isWorkerLaunchable(dispatcher)) {
//            DispatcherAvailability.getInstance().setWorkerToLaunchTracker(dispatcher);
//            DispatcherRequest dispatcherRequest = new DispatcherRequest(logUtils);
//            try {
//                dispatcherRequest.executeCallToDispatcher(dispatcher);
//                switch (dispatcherRequest.responseStatusCode) {
//                    case DispatcherRequest.RESPONSE_SUCCESS_RETURN_CODE:
//                        dispatcher.status = ConnectStatusTypes.connected;
//                        break;
//                    case DispatcherRequest.RESPONSE_LABEL_FAILURE_RETURN_CODE:
//                        dispatcher.status = ConnectStatusTypes.error;
//                        break;
//                }//switch (dispatcherRequest.responseStatusCode){
//            } catch (IOException ioException) {
//                logUtils.printLoggerError("IOException:" + ioException.getMessage());
//                throw new RuntimeException("IOException caught while trying to execute call to Dispatcher.");
//            } catch (URISyntaxException uriSyntaxException) {
//                logUtils.printLoggerError("URISyntaxException:" + uriSyntaxException.getMessage());
//                throw new RuntimeException("URISyntaxException caught while trying to execute call to Dispatcher.");
//            } catch (Exception e) {
//                logUtils.printLoggerError("Exception:" + e.getMessage());
//                throw new RuntimeException("Exception caught while sending the HttpGet request.");
//            }//try
//
//            DispatcherAvailability.getInstance().setWorkerToLaunchTracker(dispatcher);
//        } else {
//            logUtils.printLogger(String.format(
//                    "Discarding call to launch worker : %s for label: %s",
//                    dispatcher.workerName,
//                    dispatcher.label));
//        }//if (DispatcherAvailability.getInstance().isWorkerLaunchable(dispatcher)) {
//    }//private void connectWorker(
//}