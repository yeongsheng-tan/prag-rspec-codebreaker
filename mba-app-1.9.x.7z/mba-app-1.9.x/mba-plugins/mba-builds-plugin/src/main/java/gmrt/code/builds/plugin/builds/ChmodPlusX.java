package gmrt.code.builds.plugin.builds;

import hudson.FilePath;
import hudson.Functions;
import hudson.remoting.VirtualChannel;

import java.io.File;
import java.io.IOException;

/**
 * Chmods to executables recursively.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/2/11
 */
public class ChmodPlusX implements FilePath.FileCallable<Boolean> {

    /**
     * Returns <code>false</code> when any {@link File#setExecutable(boolean)} call fails. Will return <code>true</code>
     * when no files are processed.
     */
    public Boolean invoke(File f, VirtualChannel channel) throws IOException, InterruptedException {
        if (!Functions.isWindows())
            return process(f);
        return true;
    }

    boolean process(File f) {
        if (f.isDirectory()) {
            boolean result = true;
            for (File kid : f.listFiles()) {
                if (!process(kid))
                    result = false;
            }
            return result;
        } else {
            return f.setExecutable(true, true);
        }
    }

}