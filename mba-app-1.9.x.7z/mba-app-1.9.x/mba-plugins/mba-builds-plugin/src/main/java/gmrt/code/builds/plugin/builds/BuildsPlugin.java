package gmrt.code.builds.plugin.builds;

import gmrt.mba.Appliance;
import gmrt.mba.Config;
import gmrt.mba.HostResolver;
import gmrt.mba.builds.auth.Authorizer;
import gmrt.mba.builds.auth.Realm;
import hudson.*;
import hudson.model.*;
import hudson.model.listeners.ItemListener;
import hudson.remoting.Channel;
import hudson.security.AuthorizationStrategy;
import hudson.security.SecurityRealm;
import hudson.slaves.Cloud;
import hudson.tasks.Mailer;
import hudson.util.LogTaskListener;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

/**
 * Configures the local {@link Hudson} instance as well as any workers that are connected to it.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 7/21/11
 */
@Extension
public class BuildsPlugin extends Plugin {

    private static final Logger LOG = Logger.getLogger(BuildsPlugin.class);

    /**
     * Will be removed from the {@link #getMasterHostId()} name if it's there.
     */
    public static final String BANK_HOST_SUFFIX = "\\.bankofamerica\\.com";

    /**
     * Handles installing the managed build authentication and removing other options.
     */
    public void installAuthentication() throws IOException {

        DescriptorExtensionList<SecurityRealm, Descriptor<SecurityRealm>> securityRealms = SecurityRealm.all();
        for (Descriptor<SecurityRealm> desc : securityRealms) {
            if (!(desc instanceof Realm.DescriptorImpl)) {
                LOG.debug("Removing the " + desc.getDisplayName() + " realm");
                securityRealms.remove(desc);
            }
        }

        DescriptorExtensionList<AuthorizationStrategy, Descriptor<AuthorizationStrategy>> authStrats = hudson.security.AuthorizationStrategy.all();
        for (Descriptor<AuthorizationStrategy> desc : authStrats) {
            if (!(desc instanceof Authorizer.DescriptorImpl)) {
                LOG.debug("Removing the " + desc.getDisplayName() + " auth strategy");
                authStrats.remove(desc);
            }
        }

        LOG.info("Installing the " + Realm.class.getName() + " and " + Authorizer.class.getName());
        Hudson.getInstance().setSecurityRealm(new Realm());
        Hudson.getInstance().setAuthorizationStrategy(new Authorizer());

    }

    /**
     * Disables the anonymous usage statistics going out from Hudson.
     */
    public void disableFeedback() throws IOException {
        if (Hudson.getInstance().isUsageStatisticsCollected()) {
            LOG.info("Turning off Hudson Usage Statistics ...");
            Hudson.getInstance().setNoUsageStatistics(true);
        }
    }

    /**
     * Sets up the {@link hudson.tasks.Mailer.DescriptorImpl} attributes using the {@link gmrt.mba.HostResolver} and
     * {@link gmrt.mba.Notifications}. For some reason that's where Hudson gets it from for pretty much all cases?
     */
    public void configureNotifications() {

        LOG.info("Configuring notifications URL ...");

        HostResolver hostResolver = Appliance.getInstance().getBean(gmrt.mba.builds.ManagedContext.class, HostResolver.class);

        Mailer.DescriptorImpl descriptor = (Mailer.DescriptorImpl) Hudson.getInstance().getDescriptorOrDie(Mailer.class);
        descriptor.setHudsonUrl("http://" + hostResolver.getHost() + "/builds/");

    }

    /**
     * Creates (or deletes/recreates) the "default" worker instance by adding a {@link hudson.model.Slave} to
     * {@link Hudson} that launches using a command on the master node.
     */
    public void configureDefaultWorker() {

        Config config = Appliance.getInstance().getConfig();

        Hudson hudson = Hudson.getInstance();

        try {

            BuildsMasterWorkers cloud = BuildsMasterWorkers.INSTANCE;

            Hudson.CloudList clouds = hudson.clouds == null ? new Hudson.CloudList(hudson) : hudson.clouds;
            Cloud existingCloud = clouds.getByName(BuildsMasterWorkers.NAME);
            if (existingCloud == null) {
                clouds.add(cloud);
            }

            if (config.getBuilds().isMasterWorkerEnabled()) {
                LOG.info("Master worker is enabled, removing any executors from the master ...");
	            /* CODE-2048 - allows user configurable number of executors on master node instead of forcing this to 0 executors everytime
	            hudson.setNumExecutors(0);
	            */

                if (cloud.getInstanceCount() == 0) {
                    LOG.info("Configuring the default master worker ...");
                    cloud.provision();
//                } else {
//                    LOG.info("Refreshing the master workers ...");
//                    int count = cloud.getInstanceCount();
//                    cloud.goOffline();
//                    cloud.provision(count);
                }

            } else {
                LOG.info("Master worker is disabled, adding a single executor on the master and removing all master workers ...");
                hudson.setNumExecutors(1);
                cloud.goOffline();
            }

        } catch (Exception e) {
            LOG.error("Exception occured creating the MBA Master Executor...", e);
        }

    }

    /**
     * Returns the "shortened" and file-system-safe hostname of the master as acquired from
     * {@link gmrt.mba.HostResolver#getHost()}
     */
    public String getMasterHostId() {

        HostResolver hr = Appliance.getInstance().getBean(Appliance.class, HostResolver.class);
        String hostname = hr.getName() + "_" + Integer.toString(hr.getPort());
        return hostname.replaceAll(BANK_HOST_SUFFIX, "");

    }

    /**
     * Provided a worker root path, return the correct home path.
     */
    public FilePath getWorkerHome(FilePath workerRoot) {
        return workerRoot.child("home/").child(getMasterHostId());
    }

    /**
     * Shortcut for {@link Hudson#getPlugin(Class)}
     */
    public static BuildsPlugin getInstance() {
        return Hudson.getInstance().getPlugin(BuildsPlugin.class);
    }

    /**
     * Overloads {@link hudson.model.listeners.ItemListener#onLoaded()} to make the configuration changes to the singleton
     * {@link Hudson} instance by calling methods on {@link BuildsPlugin}
     *
     * @author jason.stiefel@bankofamerica.com
     * @since 7/28/11
     */
    @Extension
    public static class SetupListener extends ItemListener {

        @Override
        public void onLoaded() {

            LOG.info("Configuring Builds for MBA ...");

            BulkChange bc = new BulkChange(Hudson.getInstance());
            BuildsPlugin bp = Hudson.getInstance().getPlugin(BuildsPlugin.class);

            try {

                Hudson.getInstance().getActions().add(new BuildsWorkerAction(null));
                BuildsWorkerAction bwa = BuildsWorkerAction.getInstance(Hudson.getInstance());
                bwa.online(Hudson.MasterComputer.localChannel,
                        Hudson.getInstance().getRootPath(),
                        new LogTaskListener(java.util.logging.Logger.getLogger(Hudson.class.getName()), Level.INFO));

                bp.installAuthentication();
                bp.disableFeedback();
                bp.configureNotifications();
                //bp.configureDefaultWorker();

                bc.commit();

            } catch (Exception e) {
                bc.abort();
                throw new RuntimeException("Exception occured configuring Jenkins", e);
            }

            LOG.info("MBA configuration complete ...");

        }

    }


    /**
     * Handles configuring a {@link Computer} (or really its {@link Node}) as it comes online or goes offline.
     */
    @Extension
    public static class ComputerListener extends hudson.slaves.ComputerListener {

        /**
         * Looks up the {@link BuildsWorkerAction} and calls
         * {@link BuildsWorkerAction#online(hudson.remoting.VirtualChannel, hudson.FilePath, hudson.model.TaskListener)}
         */
        @Override
        public void preOnline(Computer c, Channel channel, FilePath root, TaskListener listener)
                throws IOException, InterruptedException {

            BuildsWorkerAction action = BuildsWorkerAction.getInstance(c);
            action.online(channel, root, listener);

        }

        /**
         * Mostly just calls {@link hudson.model.Computer#getHostName()} so it's cached when we need it downstream.
         */
        @Override
        public void onOnline(Computer c, TaskListener listener) throws IOException, InterruptedException {

            String hostName = c.getHostName();
            listener.getLogger().println("[MBA] Determined worker hostname: " + hostName);

        }

        /**
         * Delegates to {@link BuildsWorkerAction#offline()}
         */
        @Override
        public void onOffline(Computer c) {
            BuildsWorkerAction.getInstance(c).offline();
        }


    }

    /**
     * Adds the {@link BuildsWorkerAction} to any workers whether they are a {@link BuildsWorker} or not. When the
     * computer comes online this action will be updated.
     */
    @Extension
    public static class TransientComputerActionFactory extends hudson.model.TransientComputerActionFactory {

        @Override
        public Collection<? extends Action> createFor(Computer target) {
            return Arrays.asList(new BuildsWorkerAction(target));
        }

    }

}
