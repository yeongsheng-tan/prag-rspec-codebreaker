package gmrt.code.builds.plugin.builds;

import gmrt.mba.Appliance;
import gmrt.mba.Config;
import gmrt.mba.HostResolver;
import hudson.FilePath;
import hudson.model.*;
import hudson.remoting.VirtualChannel;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * An {@link hudson.model.Action} that will be added to the {@link hudson.model.Computer#transientActions} of all
 * computers and updated when the {@link hudson.model.Node} comes online/offline.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/27/11
 */
public class BuildsWorkerAction extends InvisibleAction {

    private final Computer parent;

    /**
     * A simple set of transient properties that can be used to cache worker info such as when a tool was installed or
     * These properties will be cleared whenever the worker is disconnected/connected.
     */
    private transient Map<String, String> properties;

    /**
     * A conduit to the worker system log.
     */
    private transient TaskListener listener;

    /**
     * A read-only copy of the JVM system properties after we've made our changes. This is <strong>NOT</strong> updated
     * at any time aside from during the {@link #online(VirtualChannel, FilePath, TaskListener)}
     * call.
     */
    private transient Map<String, String> systemProperties;

    private transient FilePath home;
    private transient FilePath temp;
    private transient FilePath tool;

    /**
     * @param parent <strong>Can be null</strong> when the parent is actually the master node ({@link Hudson}).
     */
    public BuildsWorkerAction(Computer parent) {
        this.parent = parent;
    }

    /**
     * Called by {@link BuildsPlugin.ComputerListener} as a worker comes online, sets up the home, temp and tool
     * directories on the worker. Sets the corresponding system properties in the remote JVM and will ask all
     * {@link SysPropContributor}s to pitch in additional properties if they wish.
     */
    /** package **/ synchronized void online(VirtualChannel channel, FilePath root, TaskListener listener)
            throws IOException, InterruptedException {

        this.properties = new HashMap<String, String>();
        this.listener = listener;

        Config config = Appliance.getInstance().getConfig();

        // If parent == null then this action is for the master Hudson computer.
        if (parent == null)
            home = new FilePath(config.getWork()).child("local/").child("master.home/");
        else
            home = BuildsPlugin.getInstance().getWorkerHome(root);

        home.mkdirs();

        temp = home.child("temp/");
        temp.mkdirs();

        tool = home.child("tool/");
        tool.mkdirs();

        listener.getLogger().println("[MBA] Preparing worker environment ...");

        Map<String, String> workerProperties = new HashMap<String, String>();
        workerProperties.put("user.home", home.getRemote());
        workerProperties.put("java.io.tmpdir", temp.getRemote());

        for (SysPropContributor spc : SysPropContributor.all())
            spc.contribute(parent == null ? Hudson.getInstance() : parent.getNode(), workerProperties);

        listener.getLogger().println("[MBA] Setting system properties on worker:");
        for (Map.Entry<String, String> entry : workerProperties.entrySet())
            listener.getLogger().println(StringUtils.leftPad(entry.getKey(), 20) + ": " + entry.getValue());

        systemProperties = new HashMap<String, String>();
        for (Map.Entry<Object, Object> entry : channel.call(new SysPropTask(workerProperties)).entrySet())
            systemProperties.put((String)entry.getKey(), entry.getValue().toString());

    }

    /**
     * Called by {@link BuildsPlugin.ComputerListener} as a worker goes offline. "Resets" this action to nulls.
     */
    /** package **/ synchronized void offline() {

        this.systemProperties = null;
        this.properties = null;
        this.listener = null;
        this.home = null;
        this.temp = null;
        this.tool = null;

    }

    /**
     * Looks up a transient property for the worker. Will return <code>null</code> when worker is not connected.
     */
    public String getProperty(String key) {
        if (properties == null)
            return null;
        return properties.get(key);
    }

    /**
     * Sets a transient property for the worker.
     *
     * @param value Value to set or <code>null</code> to clear.
     *
     * @throws IllegalStateException When worker is not connected.
     */
    public void setProperty(String key, String value) {
        if (properties == null)
            throw new IllegalStateException("Cannot set a transient property on a worker that is not connected.");
        if (value == null)
            properties.remove(key);
        else
            properties.put(key, value);
    }

    /**
     * Returns the specified system property from the worker. System properties are only updated during
     * {@link #online(VirtualChannel, FilePath, TaskListener)} and this will return
     * <code>null</code> if the worker is offline.
     */
    public String getSystemProperty(String key) {
        if (systemProperties == null)
            return null;
        return systemProperties.get(key);
    }

    /**
     * Returns the home directory as a {@link FilePath} for the computer node. The formula for this path is:
     * <code>WORKER_ROOT_DIR/homes/{@link gmrt.mba.HostResolver#getName()}_{@link gmrt.mba.HostResolver#getPort()}/</code>.
     * <p/><strong>Will be <code>null</code> when {@link #parent} is offline.</strong>
     */
    public FilePath getHome() {
        return home;
    }

    /**
     * Returns the temp directory as a {@link FilePath} for the node. The formula for this path is:
     * <code>{@link #getHome()}/temp</code>
     * <p/><strong>Will be <code>null</code> when {@link #parent} is offline.</strong>
     *
     * @see {@link #getHome()}
     */
    public FilePath getTemp() {
        return temp;
    }

    /**
     * Returns the tools directory as a {@link FilePath} for the node node. The formula for this path is:
     * <code>{@link #getHome()}/tool</code>
     * <p/><strong>Will be <code>null</code> when {@link #parent} is offline.</strong>
     *
     * @see {@link #getHome()}
     */
    public FilePath getTool() {
        return tool;
    }

    /**
     * A listener connected to the system log of the worker. Will be <code>null</code> when {@link #parent} is offline.
     */
    public TaskListener getListener() {
        return listener;
    }

    /**
     * Convenience method to look up the <code>BuildsWorkerAction</code> for the specified {@link Computer}. It's a
     * tiny bit safer to call {@link #getInstance(hudson.model.Node)} just in case you're trying to look up the action
     * for the Hudson master instance, which in our world only has a {@link Node} and no computer because it has no
     * executors!
     *
     * @throws IllegalStateException If the action cannot be found.
     */
    public static BuildsWorkerAction getInstance(Computer c) {
        BuildsWorkerAction action = getAction(c.getActions());
        if (action == null)
            throw new IllegalStateException("Computer " + c.getName() + " did not have a BuildsWorkerAction!");
        return action;
    }

    /**
     * Convenience method to look up the <code>BuildsWorkerAction</code> for the {@link Computer} of the specified
     * {@link Node}. If the {@link Node} == {@link Hudson} then a bit of special logic kicks in and returns the
     * action that was attached to {@link Hudson} by the {@link BuildsPlugin.SetupListener}.
     *
     * @see #getInstance(hudson.model.Computer)
     */
    public static BuildsWorkerAction getInstance(Node node) {
        if (node == Hudson.getInstance())
            return getAction(Hudson.getInstance().getActions());
        return getInstance(node.toComputer());
    }

    private static BuildsWorkerAction getAction(List<Action> actions) {
        for (Action action : actions) {
            if (action instanceof BuildsWorkerAction)
                return (BuildsWorkerAction)action;
        }
        return null;
    }

}
