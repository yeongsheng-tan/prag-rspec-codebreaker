package gmrt.code.builds.plugin.builds;

import hudson.*;
import hudson.model.Node;
import hudson.remoting.Channel;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.io.OutputStream;
import java.util.*;

/**
 * Decorates launched processes with the desired HOME, HOMEPATH, HOMEDRIVE, JAVA_HOME, etc.. environment variables.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/17/11
 */
@Extension
public class BuildsWorkerDecorator extends LauncherDecorator {

    @Override
    public Launcher decorate(final Launcher launcher, final Node node) {

        if (!(node instanceof BuildsWorker) && !(node instanceof hudson.model.Hudson))
            return launcher;

        return new Launcher(launcher) {

            @Override
            public Proc launch(ProcStarter starter) throws IOException {


                launcher.getListener().getLogger().println("[MBA] Decorating process for launch ...");

                BuildsWorkerAction bca = BuildsWorkerAction.getInstance(node);
                String home = bca.getHome().getRemote();
                String temp = bca.getTemp().getRemote();

                starter = starter.copy();

                String[] origEnvs = starter.envs();
                List<String> envs = origEnvs == null ? new LinkedList<String>() : new LinkedList<String>(Arrays.asList(origEnvs));

                if (!launcher.isUnix()) {
                    override(envs, "HOMEDRIVE", home.substring(0, home.indexOf(":") + 1).toUpperCase());
                    override(envs, "HOMEPATH", home.substring(home.indexOf(":") + 1));
                    override(envs, "USERPROFILE", home);
                    override(envs, "APPDATA", home);
                    override(envs, "LOCALAPPDATA", home);
                }
                override(envs, "TEMP", temp);
                override(envs, "TMP", temp);
                override(envs, "HOME", home);

                override(envs, "M2_HOME", "");

                String javaHome = get(envs, "JAVA_HOME");
                String fileSep = bca.getSystemProperty("file.separator");
                if (!StringUtils.isBlank(javaHome)) {

                    launcher.getListener().getLogger().println("[MBA] JAVA_HOME is already configured: " + javaHome);
                } else {

                    javaHome = bca.getSystemProperty("java.home");

                    if (javaHome.endsWith(fileSep + "jre")) {
                        launcher.getListener().getLogger().println("[MBA] java.home points to /jre, resolving ...");
                        javaHome = javaHome.substring(0, javaHome.lastIndexOf(fileSep + "jre"));
                    }

                    launcher.getListener().getLogger().println("[MBA] JAVA_HOME is not defined, failing over to using the agent JVM: " + javaHome);
                    override(envs, "JAVA_HOME", javaHome);
                }

                // Although Jenkins seems to also do this it uses the wrong file separator on windows and results in
                // the path not being recognized correctly.
                override(envs, "PATH+JAVA", new StringBuilder(javaHome).append(fileSep).append("bin").toString());

                starter.envs(envs.toArray(new String[envs.size()]));

                return launcher.launch(starter);
            }

            @Override
            public Channel launchChannel(String[] cmd, OutputStream out, FilePath workDir, Map<String, String> envVars) throws IOException, InterruptedException {
                return launcher.launchChannel(cmd, out, workDir, envVars);
            }

            @Override
            public void kill(Map<String, String> modelEnvVars) throws IOException, InterruptedException {
                launcher.kill(modelEnvVars);
            }

            private void override(List<String> envs, String key, String value) {
                int idx = find(envs, key);
                if (idx != -1)
                    envs.remove(idx);
                envs.add(key + "=" + value);
            }

            private int find(List<String> envs, String key) {
                for (int i = 0; i < envs.size(); i++) {
                    String env = envs.get(i);
                    if (env.toLowerCase().startsWith(key.toLowerCase() + "="))
                        return i;
                }
                return -1;
            }

            private String get(List<String> envs, String key) {
                int idx = find(envs, key);
                if (idx == -1)
                    return null;
                String env = envs.get(idx);
                return env.substring(env.indexOf("=") + 1);
            }
        };

    }
}
