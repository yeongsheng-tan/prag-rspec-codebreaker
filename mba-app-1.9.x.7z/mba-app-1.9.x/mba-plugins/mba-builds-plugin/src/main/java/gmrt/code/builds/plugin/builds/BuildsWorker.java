package gmrt.code.builds.plugin.builds;

import hudson.Extension;
import hudson.FilePath;
import hudson.model.*;
import hudson.slaves.ComputerLauncher;
import hudson.slaves.NodeProperty;
import hudson.slaves.RetentionStrategy;
import org.kohsuke.stapler.DataBoundConstructor;

import java.io.IOException;
import java.util.*;

/**
 * A worker for your MBA.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/17/11
 */
public class BuildsWorker extends Slave {

    /**
     * Label that is applied to worker nodes when they come online.
     */
    public static final String MBA_WORKER_LABEL = "mba.worker";

//    @Extension
//    public static final class DescriptorImpl extends SlaveDescriptor {
//        public String getDisplayName() {
//            return "Builds Worker";
//        }
//    }

    @DataBoundConstructor
    public BuildsWorker(String name, String nodeDescription, String remoteFS, Mode mode, String labelString,
                        ComputerLauncher launcher, RetentionStrategy retentionStrategy,
                        List<? extends NodeProperty<?>> nodeProperties) throws Descriptor.FormException, IOException {
        super(name, nodeDescription, remoteFS, "1", mode, labelString, launcher, retentionStrategy, nodeProperties);
    }

    /**
     * Returns a new {@link BuildsComputer}.
     */
    @Override
    public Computer createComputer() {
        return new BuildsComputer(this);
    }

}
