package gmrt.code.builds.plugin.builds;

import hudson.Extension;
import hudson.model.AbstractBuild;
import hudson.model.TaskListener;
import org.jenkinsci.plugins.tokenmacro.DataBoundTokenMacro;
import org.jenkinsci.plugins.tokenmacro.MacroEvaluationException;

import java.io.IOException;

/**
 * A {@link org.jenkinsci.plugins.tokenmacro.TokenMacro} implementation to pull values from the
 * {@link BuildsEnvAction}. The reason I implemented this way is using an EnvironmentVariableTokenMacro was causing
 * an endless loop.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/25/11
 */
@Extension
public class BuildsEnvMacro extends DataBoundTokenMacro {

    @Parameter(required = true)
    public String var = "";

    @Override
    public String evaluate(AbstractBuild<?, ?> context, TaskListener listener, String macroName)
            throws MacroEvaluationException, IOException, InterruptedException {
        BuildsEnvAction action = context.getAction(BuildsEnvAction.class);
        if (action == null || !action.env.containsKey(var))
            return "";
        return action.env.get(var);
    }

    @Override
    public boolean acceptsMacroName(String macroName) {
        return macroName.equals("BUILDS_ENV");
    }
}
