package gmrt.code.builds.plugin.builds;

import hudson.model.AbstractBuild;

import java.util.HashMap;
import java.util.Map;

/**
 * Adds builds specific environment variables to a build. Instances of this action should <strong>NOT</strong> be
 * held as attributes as the immutable action instance will often be "updated" by calls to
 * {@link #override(hudson.model.AbstractBuild, java.util.Map)}.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/15/11
 */
public class BuildsEnvAction extends AbstractEnvAction {

    public static final String MBA_HOSTNAME = "MBA_HOSTNAME";
    public static final String MBA_HOSTPORT = "MBA_HOSTPORT";
    public static final String MBA_ARTIFACTS_RELEASES = "MBA_ARTIFACTS_RELEASES";
    public static final String MBA_ARTIFACTS_SNAPSHOTS = "MBA_ARTIFACTS_SNAPSHOTS";
    public static final String MBA_ARTIFACTS_GROUP = "MBA_ARTIFACTS_GROUP";
    public static final String MBA_ARTIFACTS_BACKUP = "MBA_ARTIFACTS_BACKUP";
    public static final String MBA_WORKER_USER = "MBA_WORKER_USER";
    public static final String MBA_WORKER_CRED = "MBA_WORKER_CRED";
    public static final String MBA_WORKER_REALM = "MBA_WORKER_REALM";
    public static final String MBA_WORKER_HOST = "MBA_WORKER_HOST";
    public static final String MBA_WORKER_HOME = "MBA_WORKER_HOME";
	public static final String MBA_VERSION = "MBA_VERSION";
	public static final String MBA_UPDATE_CENTER_URL = "MBA_UPDATE_CENTER_URL";

    public BuildsEnvAction(Map<String, String> env) {
        super(env);
    }

    /**
     * If a <code>BuildsEnvAction</code> exists on the specified build it will be overriden with the specified env
     * and replaced on the build. If no action exists we will just add a new <code>BuildsEnvAction</code>
     */
    public static BuildsEnvAction override(AbstractBuild build, Map<String, String> env) {

        BuildsEnvAction old = build.getAction(BuildsEnvAction.class);
        Map<String, String> merged = new HashMap<String, String>();
        if (old != null) {
            merged.putAll(old.env);
            build.getActions().remove(old);
        }

        merged.putAll(env);
        BuildsEnvAction action = new BuildsEnvAction(merged);
        build.addAction(action);

        return action;

    }

    /**
     * @see #override(hudson.model.AbstractBuild, java.util.Map)
     */
    public static BuildsEnvAction override(AbstractBuild build, String... env) {
        return override(build, AbstractEnvAction.convert(env));
    }

    @Override
    public String toString() {
        return "BuildsEnvAction{" +
                "env=" + env +
                '}';
    }



}
