package gmrt.code.builds.plugin.builds;

import hudson.remoting.Callable;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;

/**
 * Sets the specified system properties on the worker and then returns all current system properties.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 6/30/11
 */
public class SysPropTask implements Callable<Properties, IOException> {

    final Map<String, String> properties;

    public SysPropTask(Map<String, String> properties) {
        this.properties = properties;
    }

    public Properties call() throws IOException {

        for (Map.Entry<String, String> entry : properties.entrySet()) {
            if (entry.getValue() == null)
                System.getProperties().remove(entry.getKey());
            else
                System.setProperty(entry.getKey(), entry.getValue());
        }

        return System.getProperties();
    }
}
