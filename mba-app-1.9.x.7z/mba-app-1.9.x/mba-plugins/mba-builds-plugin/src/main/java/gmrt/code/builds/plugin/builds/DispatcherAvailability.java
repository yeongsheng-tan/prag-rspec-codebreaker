//package gmrt.code.builds.plugin.builds;
//
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.Map;
//import java.util.Set;
//
///**
// * Maintains a map of workers connecting to the dispatcher.
// *
// * @author jatin.tak@baml.com
// * @since 1/17/12
// */
//public class DispatcherAvailability {
//
//    /*
//     * Time between request for workers for same label.
//     *
//     * Default to 1 minute.
//     */
//    private long demandRequestDelay;
//
//    private DispatcherAvailability() {
//        demandRequestDelay = 1;
//    }
//
//    private static final DispatcherAvailability __singletonAvailable = new DispatcherAvailability();
//
//    public static DispatcherAvailability getInstance() {
//        if (__singletonAvailable == null) {
//            throw new RuntimeException("No DispatcherAvailability instance available.");
//        } else {
//            return __singletonAvailable;
//        }
//    }
//
//    /*
//    *This variable maintains the critical section when launching the worker session.
//    *The critical section is needed to synch the threads from Jenkins so that we only request
//    * a worker form the dispatcher as needed.
//    *
//    * Note: Jenkins normal behaviour is to launch all the workers associated
//    * for a label.
//     */
//    public boolean getAvailable = false;
//
//    /*
//    *Maintains a map and their state for the workers we are connecting to the dispatcher.
//     */
//    public HashMap dispatchedWorkers = new HashMap();
//
//    /*
//    *Stores a Dispatcher to the dispatcherWorkers map.
//     */
//    public void setWorkerToLaunchTracker(Dispatcher dispatcher) {
//        dispatchedWorkers.put(dispatcher.workerName, dispatcher);
//    }
//
//    /*
//    *Removes a Dispatcher from the dispatcherWorkers map.  Normally when the worker is disconnected.
//     */
//    public void removeWorkerFromLaunchTracker(String workerName) {
//        dispatchedWorkers.remove(workerName);
//    }
//
//    /*
//    *Determines if we should launch the worker.
//    *
//    * Only launch if the worker nor any of the workers the label is associated with is
//    *  connecting, connected or has an error.
//     */
//    public Boolean isWorkerLaunchable(Dispatcher dispatcher) {
//        Set set = dispatchedWorkers.entrySet();
//        Iterator iterator = set.iterator();
//
//        while (iterator.hasNext()) {
//            Map.Entry mapEntry = (Map.Entry) iterator.next();
//            Dispatcher mappedDispatcher = (Dispatcher) mapEntry.getValue();
//
//            if (mapEntry.getKey() == dispatcher.workerName) {
//                if (mappedDispatcher.status == ConnectStatusTypes.connecting ||
//                        mappedDispatcher.status == ConnectStatusTypes.connected ||
//                        mappedDispatcher.status == ConnectStatusTypes.error) {
//                    return false;//This worker already launched...
//                }
//            } else {
//                //I have a worker, check the label, have we launched for this label
//                if (haveWeLaunchedWithThisLabel(dispatcher.label)) {
//                    return false;
//                }
//            }
//        }
//
//        return true;//There is no other worker so launch it...
//    }
//
//    private Boolean haveWeLaunchedWithThisLabel(String label) {
//        Set set = dispatchedWorkers.entrySet();
//        Iterator iterator = set.iterator();
//
//        while (iterator.hasNext()) {
//            Map.Entry mapEntry = (Map.Entry) iterator.next();
//            Dispatcher mappedDispatcher = (Dispatcher) mapEntry.getValue();
//            Date date = new Date();
//            long currentTime = date.getTime();
//
//            if (mappedDispatcher.label == label &&
//                    //TODO: Change to a config option
//                    (currentTime - mappedDispatcher.timeStamp < demandRequestDelay * 1000 * 60) &&
//                    (mappedDispatcher.status == ConnectStatusTypes.connected ||
//                            mappedDispatcher.status == ConnectStatusTypes.connecting)) {
//                return true;//I have a worker with my label that has already launched within the minute
//            }
//        }//while
//
//        return false;//no other worker with my label has been launched
//    }//private Boolean haveWeLaunchedWithThisLabel(String label)
//}
