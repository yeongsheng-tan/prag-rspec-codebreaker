package gmrt.code.builds.plugin.builds.labels;

import hudson.Extension;
import hudson.FilePath;
import hudson.model.*;
import hudson.model.labels.LabelAtom;
import hudson.remoting.Channel;
import hudson.slaves.ComputerListener;

import java.io.IOException;
import java.util.List;
import java.util.Set;

/**
 * Listens for workers to come online and caches a set of {@link LabelAtom}s describing them when they do. This
 * listener only works for workers.
 *
 * @author jason.stiefel@bankofamerica.com
 * @see gmrt.code.builds.plugin.builds.labels.PlatformIdLabeler
 * @see gmrt.code.builds.plugin.builds.labels.PlatformIdLabelMaker
 * @see gmrt.code.builds.plugin.builds.labels.PlatformIdComposer
 * @see gmrt.code.builds.plugin.builds.labels.PlatformIdTask
 * @since 2/4/11
 */
@Extension
public class PlatformLabelListener extends ComputerListener {

    private PlatformIdLabeler labeler = new PlatformIdLabeler();

    @Override
    public void onOnline(Computer c, TaskListener listener) throws IOException, InterruptedException {

        if ("".equals(c.getNode().getNodeName())) {
            listener.getLogger().println("[MBA] Not labeling the actual master node ...");
            return;
        }

        listener.getLogger().println("[MBA] Determining correct platform labels for node " + c.getNode().getNodeName());
        PlatformLabelFinder.LABELS.put(c.getNode().getNodeName(), labeler.labelNode(c.getNode(), c.getChannel()));
        listener.getLogger().println("[MBA] Assigning labels to " + c.getNode().getNodeName() + ": " + c.getNode().getAssignedLabels());

        // Hopefully this will reset the Node -> Label associations in Hudson
        List<Node> nodes = Hudson.getInstance().getNodes();
        Hudson.getInstance().setNodes(nodes);

    }

}
