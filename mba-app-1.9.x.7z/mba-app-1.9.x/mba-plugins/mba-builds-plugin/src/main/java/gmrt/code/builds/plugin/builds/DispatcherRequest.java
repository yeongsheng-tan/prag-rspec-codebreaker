//package gmrt.code.builds.plugin.builds;
//
//import gmrt.mba.Appliance;
//import gmrt.mba.HostResolver;
//import org.apache.http.HttpResponse;
//import org.apache.http.client.HttpClient;
//import org.apache.http.client.methods.HttpGet;
//import org.apache.http.impl.client.DefaultHttpClient;
//
//import java.io.IOException;
//import java.net.*;
//
///**
// * Sends http request to dispatcher to connect worker to a slave.
// *
// * @author : Eladio Martin
// * @since : 1/25/12
// */
//
//public class DispatcherRequest {
//    private LogUtils logUtils = null;
//
//    protected static final String LABELOS_REQUEST = "labelOS";
//    protected static final String JNLP_URL_REQUEST = "JnlpUrl";
//    public static final int RESPONSE_SUCCESS_RETURN_CODE = 200;
//    public static final int RESPONSE_LABEL_FAILURE_RETURN_CODE = 500;
//
//    public int responseStatusCode;
//    public String responseStatusLine;
//
//    public DispatcherRequest(LogUtils logUtils) {
//        this.logUtils = logUtils;
//        this.logUtils.setLogger(DispatcherRequest.class);
//    }
//
//    public void executeCallToDispatcher(
//            Dispatcher dispatcher)
//            throws IOException, URISyntaxException {
//        String resultMessage = "";
//
//        try {
//            logUtils.printLogger(String.format(
//                    "executeCallToDispatcher: Launching Worker %s ",
//                    dispatcher.workerName));
//
//            URI UriToExecute = initializeUrl(dispatcher);
//
//            HttpGet httpGet = new HttpGet(UriToExecute);
//            HttpClient httpClient = new DefaultHttpClient();
//            HttpResponse response = httpClient.execute(httpGet);
//
//            responseStatusLine = response.getStatusLine().toString();
//            responseStatusCode = response.getStatusLine().getStatusCode();
//
//            switch (responseStatusCode) {
//                case RESPONSE_SUCCESS_RETURN_CODE:
//                    resultMessage = String.format(
//                            "executeCallToDispatcher: SUCCESS Connected to Worker : %s \n\tResponse status line : %s\n\tResponse status code: %d",
//                            dispatcher.workerName,
//                            responseStatusLine,
//                            responseStatusCode);
//                    break;
//                case RESPONSE_LABEL_FAILURE_RETURN_CODE:
//                    resultMessage = String.format(
//                            "executeCallToDispatcher: FAILED to Connect to Worker : %s \n\tResponse status line : %s\n\tResponse status code: %d",
//                            dispatcher.workerName,
//                            responseStatusLine,
//                            responseStatusCode);
//                    break;
//            }
//
//            logUtils.printLogger(resultMessage);
//        } catch (IOException ioException) {
//            logUtils.printLoggerError("IOException:" + ioException.getMessage());
//            throw new RuntimeException("IOException caught while sending the HttpGet request.");
//        } catch (Exception e) {
//            logUtils.printLoggerError("Exception:" + e.getMessage());
//            throw new RuntimeException("Exception caught while sending the HttpGet request.");
//        }
//    }//private void executeCallToDispatcher
//
//    private URI initializeUrl(
//            Dispatcher dispatcher)
//            throws URISyntaxException, MalformedURLException {
//        String jnlpUrl = getJnlpUrl(dispatcher);
//        String dispatcherUrl = "";
//
//        try {
//            dispatcherUrl = Appliance.getInstance().getConfig().getGrid().getDefaultDispatcherUrl();
//        } catch (Exception e) {
//            logUtils.printLoggerError("Exception:" + e.getMessage());
//        }
//
//        logUtils.printLogger(String.format(
//                "initializeUrl: Worker : %s \n\tJnlpUrl: %s \n\tlabelOS : %s \n\tdispatcher : %s",
//                dispatcher.workerName,
//                jnlpUrl,
//                dispatcher.label,
//                dispatcherUrl));
//
//        URI dispatcherUri = new URI(dispatcherUrl);
//        String host = dispatcherUri.getHost();
//        int port = dispatcherUri.getPort();
//        String path = dispatcherUri.getPath();
//
//        String urlParams = String.format(
//                "%s=%s&%s=%s",
//                JNLP_URL_REQUEST,
//                jnlpUrl,
//                LABELOS_REQUEST,
//                dispatcher.label);
//
//        URI UriToExecute = new URI(
//                "http", null,
//                host, port,
//                path, urlParams, null);
//
//        logUtils.printLogger(String.format(
//                "initializeUrl: Worker : %s \n\tUrl to execute: %s",
//                dispatcher.workerName,
//                UriToExecute.toURL().toString()));
//
//        return UriToExecute;
//    }//private URI initializeUrl
//
//
//    /**
//     * @param dispatcher instance
//     * @return The JNLP URL for the Jenkins instance. Note that we use IP Addresses instead of hostnames because some machines'
//     *         can't be resolved in the DNS for some reason. (dev laptops for example)
//     */
//    private String getJnlpUrl(
//            Dispatcher dispatcher) {
//        HostResolver hostResolver = Appliance.getInstance().getBean(Appliance.class, HostResolver.class);
//        int port = hostResolver.getPort();
//
//        // Use the IP Address instead since not all hostnames can be resolved into ip addresses via DNS
//        // For example, the dev laptops and any other computer connecting via VPN.
//        try {
//            URI jnlpUri = new URI(
//                    "http",
//                    null,
//                    this.getIpAddress(),
//                    port,
//                    String.format(
//                            "/builds/%sslave-agent.jnlp",
//                            dispatcher.computerUrl),
//                    null, null
//            );
//            return jnlpUri.toURL().toString();
//        } catch (UnknownHostException unknownHostException) {
//            logUtils.printLoggerError("UnknownHostException: " + unknownHostException.getMessage());
//            throw new RuntimeException(unknownHostException.getMessage());
//        } catch (Exception e) {
//            logUtils.printLoggerError("Exception: " + e.getMessage());
//            throw new RuntimeException(e.getMessage());
//        }
//    }//private String getJnlpUrl
//
//    private String getIpAddress()
//            throws UnknownHostException {
//        InetAddress inetAddress = InetAddress.getLocalHost();
//        byte[] ipAddress = inetAddress.getAddress();
//        StringBuilder addressBuilder = new StringBuilder();
//        addressBuilder.append(ipAddress[0] & 0xff);
//        for (int i = 1; i < ipAddress.length; i++) {
//            addressBuilder.append(".");
//            addressBuilder.append(ipAddress[i] & 0xff);
//        }
//        return addressBuilder.toString();
//    }//private String getIpAddress
//
//
//}
