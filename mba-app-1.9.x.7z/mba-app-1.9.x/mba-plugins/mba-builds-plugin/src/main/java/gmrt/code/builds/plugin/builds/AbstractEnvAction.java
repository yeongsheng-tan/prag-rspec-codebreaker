package gmrt.code.builds.plugin.builds;

import hudson.EnvVars;
import hudson.Util;
import hudson.model.AbstractBuild;
import hudson.model.EnvironmentContributingAction;
import hudson.model.InvisibleAction;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 8/25/11
 */
public abstract class AbstractEnvAction extends InvisibleAction implements EnvironmentContributingAction {

    public final Map<String,String> env;

    protected AbstractEnvAction(String... pairs) {
        this(convert(pairs));
    }

    protected AbstractEnvAction(Map<String, String> env) {
        this.env = Collections.unmodifiableMap(env);
    }

    public void buildEnvVars(AbstractBuild<?, ?> build, EnvVars envVars) {
        for (Map.Entry<String, String> entry : env.entrySet()) {
            envVars.put(entry.getKey(), entry.getValue());
        }
    }

    public static Map<String, String> convert(String... pairs) {
        if ((pairs.length % 2) != 0)
            throw new IllegalArgumentException("Must provide _pairs_ of env variables");
        Map<String, String> map = new HashMap<String, String>(pairs.length / 2);
        for (int i = 0; i < pairs.length; i++) {
            String key = pairs[i++];
            String val = pairs[i];
            map.put(key, val);
        }
        return map;
    }
}
