package gmrt.code.builds.plugin.builds;

import hudson.ExtensionList;
import hudson.ExtensionPoint;
import hudson.model.AbstractBuild;
import hudson.model.Hudson;
import hudson.model.TaskListener;

import java.io.IOException;

/**
 * An {@link ExtensionPoint} that will be called by the
 * {@link BuildsWrapper#preCheckout(hudson.model.AbstractBuild, hudson.Launcher, hudson.model.BuildListener)} to give
 * plugins an opportunity to write files to the build workspace (or its parent, etc..) prior to scm checkout.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/24/11
 */
public abstract class WsContributor implements ExtensionPoint {

    public abstract void contribute(AbstractBuild build, TaskListener listener) throws IOException, InterruptedException;

    public static ExtensionList<WsContributor> all() {
        return Hudson.getInstance().getExtensionList(WsContributor.class);
    }

}
