package gmrt.code.builds.plugin.builds;

import gmrt.mba.Appliance;
import gmrt.mba.Config;
import hudson.Extension;
import hudson.FilePath;
import hudson.model.*;
import hudson.slaves.CommandLauncher;
import hudson.slaves.NodeProperty;
import hudson.slaves.RetentionStrategy;
import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.StaplerRequest;
import org.kohsuke.stapler.StaplerResponse;

import javax.servlet.ServletException;
import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * A <code>BuildsMasterWorker</code> is a {@link BuildsWorker} that is launched locally on the master node by the
 * {@link BuildsMasterWorkers} "pseudo-cloud". This subclass of {@link BuildsWorker} is intended to be
 * configuration-free.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/25/11
 */
public class BuildsMasterWorker extends BuildsWorker {

    /**
     * Label that is applied to the master worker when it comes online.
     */
    public static final String MBA_MASTER_WORKER_LABEL = "mba.master";

    @Extension
    public static final class DescriptorImpl extends SlaveDescriptor {
        public String getDisplayName() {
            return "Code/Builds Master Worker";
        }

        @Override
        public String getConfigPage() {
            return super.getConfigPage();    //To change body of overridden methods use File | Settings | File Templates.
        }

        @Override
        public boolean isInstantiable() {
            return false;
        }
    }

    /**package **/ BuildsMasterWorker(String name, FilePath fsRoot, String labelString, CommandLauncher launcher, List<? extends NodeProperty<?>> nodeProperties)
            throws Descriptor.FormException, IOException {
        super(name, "", fsRoot.getRemote(),
                Mode.NORMAL, labelString, launcher, RetentionStrategy.Always.INSTANCE, nodeProperties);
    }

    @Override
    public Computer createComputer() {
        return new BuildsMasterComputer(this);
    }

}
