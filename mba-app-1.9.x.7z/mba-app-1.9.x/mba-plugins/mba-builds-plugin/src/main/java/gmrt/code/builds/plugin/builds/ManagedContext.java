package gmrt.code.builds.plugin.builds;

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 2/5/11
 */
public interface ManagedContext extends gmrt.da.ManagedContext<ManagedContext> {}
