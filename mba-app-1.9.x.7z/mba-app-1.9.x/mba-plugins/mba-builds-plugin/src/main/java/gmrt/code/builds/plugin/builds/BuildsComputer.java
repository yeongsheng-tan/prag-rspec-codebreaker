package gmrt.code.builds.plugin.builds;

import hudson.slaves.SlaveComputer;

/**
 * A {@link SlaveComputer} that wraps a {@link BuildsWorker}.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/23/11
 */
public class BuildsComputer extends SlaveComputer {

    public BuildsComputer(BuildsWorker worker) {
        super(worker);
    }

    /**
     * Returns the {@link BuildsWorker} for this <code>BuildsComputer</code>
     */
    public BuildsWorker getWorker() {
        return (BuildsWorker)getNode();
    }
}
