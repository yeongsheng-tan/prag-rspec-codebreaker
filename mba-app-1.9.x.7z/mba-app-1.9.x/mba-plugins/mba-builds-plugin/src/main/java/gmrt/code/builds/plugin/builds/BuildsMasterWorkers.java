package gmrt.code.builds.plugin.builds;

import gmrt.mba.Appliance;
import gmrt.mba.Config;
import hudson.Extension;
import hudson.FilePath;
import hudson.model.Descriptor;
import hudson.model.Hudson;
import hudson.model.Label;
import hudson.model.Node;
import hudson.slaves.*;
import net.sf.json.JSONObject;
import org.kohsuke.stapler.QueryParameter;
import org.kohsuke.stapler.StaplerRequest;
import org.kohsuke.stapler.StaplerResponse;

import javax.servlet.ServletException;
import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * <code>BuildsMasterWorkers</code> is a dead simple {@link Cloud} that is used to manage a collection of
 * {@link BuildsMasterWorker} instances running on the master node.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/25/11
 */
public class BuildsMasterWorkers extends AbstractCloudImpl {

    public static final String MASTER_WORKER_NAME_TEMPLATE = "(Local Worker %s)";
    public static final String MASTER_WORKER_HOME_TEMPLATE = "mba.master.%s";
    public static final String NAME = "Managed Build Workers";

    // Keep track of how many nodes we've allocated.
    private int nodeCounter;

    static final BuildsMasterWorkers INSTANCE = new BuildsMasterWorkers(0);

    @Extension
    public static class DescriptorImpl extends Descriptor<Cloud> {
        @Override
        public String getDisplayName() {
            return NAME;
        }

        @Override
        public Cloud newInstance(StaplerRequest req, JSONObject formData) throws FormException {
            return INSTANCE;
        }

    }

    /**
     * This cloud is intended to be a singleton that is added by the {@link BuildsPlugin.SetupListener} in the event
     * it has been deleted.
     */
    BuildsMasterWorkers(int nodeCount) {
        super(NAME, Appliance.getInstance().getConfig().getBuilds().getWorkerLimit().toString());
        nodeCounter = nodeCount;
    }

    private void setNodeCounter(int value) {
        nodeCounter = value;
    }

    private int getNodeCounter() {
        return nodeCounter;
    }


    /**
     * Have we exceeded the limit yet?
     */
    public boolean canProvision() {
        return getInstanceCount() < getInstanceCap();
    }

    public void doProvision(StaplerRequest req, StaplerResponse rsp, @QueryParameter String workerType) throws ServletException, IOException, Descriptor.FormException {
        //checkPermission(PROVISION);
        if (workerType == null) {
            sendError("The 'workerType' parameter is missing", req, rsp);
            return;
        }

        if (workerType.equalsIgnoreCase("local")) {
            provision();
        }
//        else {
//            String labelOS = null;
//            String remoteFileSystemRoot = null;
//            if (workerType.equalsIgnoreCase("remote_windows")) {
//                labelOS = "mbs_win";
//                remoteFileSystemRoot = "D:\\apps\\jenkins\\work";
//            } else if (workerType.equalsIgnoreCase("remote_linux")) {
//                labelOS = "mbs_linux";
//                remoteFileSystemRoot = "/opt/condor/jenkins/work";
//            } else {
//                throw new RuntimeException("Invalid type parameter: " + workerType);
//            }
//
//            Hudson hudson = Hudson.getInstance();
//            String mbsWorkerType = "";
//            if (labelOS.equals("mbs_win")){
//                mbsWorkerType = "windows";
//            }
//            else if (labelOS.equals("mbs_linux")){
//                mbsWorkerType = "linux";
//            }
//            BuildsWorker mbsWorkerNode = new BuildsWorker(mbsWorkerType + "_worker_"  + nodeCounter++, // name
//                    "MBS worker", // description
//                    remoteFileSystemRoot, // remoteFS
//                    Node.Mode.NORMAL, //mode
//                    labelOS, //label
//                    new DispatcherWorkerLauncher(), //launcher
//                    new RetentionStrategy.Demand(1, 2), //retention strategy
//                    Collections.<NodeProperty<?>>emptyList() // node properties
//            );
//            hudson.addNode(mbsWorkerNode);
//
//        }
//        rsp.forwardToPreviousPage(req);
    }

    /**
     * Creates a new {@link BuildsMasterWorker} instance and adds it to the nodes collection.
     */
    /**
     * package *
     */
    BuildsMasterWorker provision(String labels, List<? extends NodeProperty<?>> nodeProperties)
            throws Descriptor.FormException, IOException {

        if (!canProvision())
            throw new UnsupportedOperationException("Cannot provision more than " + getInstanceCap() + " master workers");

        int workerIndex = getInstanceCount();
        FilePath root = nextWorkerRoot(workerIndex);
        FilePath home = nextWorkerHome(root);
        BuildsMasterWorker ins = new BuildsMasterWorker(nextWorkerName(workerIndex), root, labels, buildLauncher(home), nodeProperties);
        Hudson.getInstance().addNode(ins);
        return ins;
    }

    /**
     * @see {@link #provision(String, java.util.List)}
     */
    /**
     * package *
     */
    BuildsMasterWorker provision() throws Descriptor.FormException, IOException {
        return provision("", new ArrayList<NodeProperty<?>>());
    }

    /**
     * Provisions the indicated number of workers.
     *
     * @see {@link #provision()}
     */
    /**
     * package *
     */
    List<BuildsMasterWorker> provision(int count) throws Descriptor.FormException, IOException {
        List<BuildsMasterWorker> workers = new LinkedList<BuildsMasterWorker>();
        for (int i = 0; i < count; i++)
            workers.add(provision());
        return workers;
    }

    /**
     * Removes all the {@link BuildsMasterWorker} nodes from {@link Hudson}.
     */
    /**
     * package *
     */
    void goOffline() throws IOException {
        for (Node node : new ArrayList<Node>(Hudson.getInstance().getNodes())) {
            if (node instanceof BuildsMasterWorker)
                Hudson.getInstance().removeNode(node);
        }
    }

    /**
     * Should never be called.
     */
    @Override
    public Collection<NodeProvisioner.PlannedNode> provision(Label label, int excessWorkload) {
        throw new UnsupportedOperationException("Calling #provision() is not supported.");
    }

    /**
     * Always returns <code>false</code>, we only want to provision via manual action.
     */
    @Override
    public boolean canProvision(Label label) {
        return false;
    }

    /**
     * package *
     */
    int getInstanceCount() {

        int count = 0;
        for (Node node : Hudson.getInstance().getNodes()) {
            if (node instanceof BuildsMasterWorker)
                count++;
        }

        return count;
    }

    protected FilePath nextWorkerRoot(int workerIndex) {
        Config config = Appliance.getInstance().getConfig();
        return new FilePath(Hudson.MasterComputer.localChannel, config.getWork().getAbsolutePath()).
                child("local").child(BuildsMasterWorker.MBA_MASTER_WORKER_LABEL + "." + workerIndex);
    }

    /**
     * Delegates to {@link BuildsPlugin#getWorkerHome(hudson.FilePath)}
     */
    protected FilePath nextWorkerHome(FilePath workerRoot) {
        return BuildsPlugin.getInstance().getWorkerHome(workerRoot);
    }

    /**
     * Looks at the {@link BuildsMasterWorker}s installed already and increments the counter to be inserted into the
     * {@link #MASTER_WORKER_NAME_TEMPLATE}
     */
    protected String nextWorkerName(int workerIndex) {
        return String.format(MASTER_WORKER_NAME_TEMPLATE, workerIndex);
    }

    protected CommandLauncher buildLauncher(FilePath homePath) {

        Config config = Appliance.getInstance().getConfig();
        Hudson hudson = Hudson.getInstance();

        StringBuilder cmd = new StringBuilder(System.getProperty("java.home")).
                append(File.separatorChar).append("bin").append(File.separatorChar).append("java ");
        cmd.append(config.getBuilds().getWorkerJdkArgs());
        cmd.append(" -Duser.home=").append(homePath.getRemote());

        String jarPath;
        try {
            jarPath = new File(hudson.getJnlpJars("slave.jar").getURL().toURI()).getAbsolutePath();
        } catch (Exception e) {
            throw new RuntimeException("Fatal exception occurred building CommandLauncher for new Master Worker", e);
        }

        cmd.append(" -jar ").append(jarPath);

        return new CommandLauncher(cmd.toString());
    }


}