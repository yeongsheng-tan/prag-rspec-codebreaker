//package gmrt.code.builds.plugin.builds;
//
//import hudson.Extension;
//import hudson.model.Hudson;
//import hudson.widgets.Widget;
//
//import java.util.List;
//
///**
// * Widget the displays boxes in the left margin providing details on the connected Managed Build Clouds.
// *
// * @author jason.stiefel@bankofamerica.com
// * @since Dec 13, 2010
// */
//@Extension
//public class WorkerLauncherWidget extends Widget {
//
//    public WorkerLauncherWidget() {}
//
//    public List<BuildsMasterWorkers> getClouds() {
//        return Hudson.getInstance().clouds.getAll(BuildsMasterWorkers.class);
//    }
//
//}
