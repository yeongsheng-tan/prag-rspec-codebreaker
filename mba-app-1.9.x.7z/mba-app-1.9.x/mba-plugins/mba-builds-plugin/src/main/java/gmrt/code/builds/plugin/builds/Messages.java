package gmrt.code.builds.plugin.builds;

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/6/11
 */
public class Messages {

    public static String BuildsPlugin_postJobsLoaded() {
        return "MBA Builds Plugin";
    }

}
