package gmrt.code.builds.plugin.builds;

import hudson.Extension;
import hudson.Launcher;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.tasks.BuildWrapper;
import hudson.tasks.BuildWrapperDescriptor;

import java.io.IOException;

/**
 * Added to all builds by the {@link BuildsRunListener}, this wrapper is responsible for calling
 * {@link WsContributor} instances.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/24/11
 */
public class BuildsWrapper extends BuildWrapper {

    /**
     * This is sort of a "dummy" descriptor that shouldn't really be used as we are "injecting" the wrapper
     * automatically from the {@link hudson.model.listeners.RunListener}.
     */
    @Extension
    public static class DescriptorImpl extends BuildWrapperDescriptor {
        /**
         * Returns false for everything- we don't need anyone to add this wrapper we'll add it via
         * {@link BuildsRunListener}
         */
        @Override
        public boolean isApplicable(AbstractProject<?, ?> item) {
            return false;
        }
        @Override
        public String getDisplayName() {
            return "MBA Builds Wrapper";
        }
    }

    /**
     * Calls {@link WsContributor}s.
     */
    @Override
    public void preCheckout(AbstractBuild build, Launcher launcher, BuildListener listener) throws IOException, InterruptedException {
        for (WsContributor cont : WsContributor.all()) {
            cont.contribute(build, listener);
        }
    }

    /**
     * No-op, Jenkins forces us to implement.
     */
    @Override
    public Environment setUp(AbstractBuild build, Launcher launcher, BuildListener listener) throws IOException, InterruptedException {
        return new Environment() {
            @Override
            public boolean tearDown(AbstractBuild build, BuildListener listener) throws IOException, InterruptedException {
                return super.tearDown(build, listener);
            }
        };
    }
}
