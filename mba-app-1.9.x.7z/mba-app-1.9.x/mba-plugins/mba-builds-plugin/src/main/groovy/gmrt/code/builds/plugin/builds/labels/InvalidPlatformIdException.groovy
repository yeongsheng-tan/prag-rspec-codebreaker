package gmrt.code.builds.plugin.builds.labels

/**
 * Thrown when a platformId string cannot be parsed into a set of labels.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/11/11
 */
class InvalidPlatformIdException extends RuntimeException {

  InvalidPlatformIdException(String platformId) {
    super(String.valueOf("PlatformId is invalid: ${platformId}"));
  }
}
