package gmrt.code.builds.plugin.builds

/**
 * Various utility methods.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/25/11
 */
class Util {

  /**
   * Overrides any matching options in the optionString. This was built for override Java "-D" system properties
   * but should work for anything really. Uses {@link hudson.Util#tokenize} to handle quoted options.
   *
   * @param prefix Option prefix, i.e. "-D"
   * @param overrides The overrides to set
   * @param optionString Current option string, can be null or empty.
   */
  static String overrideOpts(String prefix, Map<String, String> overrides, String optionString) {

    List<String> opts = new LinkedList<String>(
            optionString == null ? new ArrayList<String>(0) : Arrays.asList(hudson.Util.tokenize(optionString, " ")));
    overrides.each { key, value ->
      int idx = opts.findIndexOf { it.startsWith("${prefix}${key}=") }
      def opt = "${prefix}${key}=${value}"
      if (idx != -1)
        opts.set(idx, opt);
      else
        opts << opt;
    }

    opts.join(' ');
  }

}
