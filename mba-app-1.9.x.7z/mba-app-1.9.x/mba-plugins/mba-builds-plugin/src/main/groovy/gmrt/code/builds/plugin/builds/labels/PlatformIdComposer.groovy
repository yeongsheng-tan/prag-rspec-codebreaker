package gmrt.code.builds.plugin.builds.labels

/**
 * Composes a platform id out of the <strong>os.arch</strong>, <strong>os.name</strong>, <strong>os.version</strong>
 * and <strong>sun.arch.data.model</strong> system properties passed to the
 * {@link PlatformIdComposer#compose(String, String, String, String)} method. Will return
 * {@link PlatformIdComposer#MBA_UNKNOWN_PLATFORM} in the event of a failure to determine.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/3/11
 */
class PlatformIdComposer {

  public static final String MBA_UNKNOWN_PLATFORM = 'mba.unknown.platform';

  /**
   * A map of values that will always be converted when encountered.
   */
  protected final CONVERSIONS = [
          'amd64': 'x86.64',
          'windows': 'win',
          '32': 32,
          '64': 64
  ]

  public String compose(String osArch, String osBits, String osName, String osVersion) {

    def arch = convert(osArch.toLowerCase());
    def bits = convert(osBits);

    // There's a chance that the sun.arch.data.model is "less" than the architecture bits (32bit jvm on 64bit arch)
    // so we'll always favor an indicated architecture over any bits specified since we're describing the platform not
    // the jvm being used.
    if (!(arch =~ /[a-z0-9]+\.[0-9]{2}/))
      arch = "${arch}.${bits}"

    def name = convert((osName.toLowerCase() =~ /([\w\.]++).*/).with {
      if (!matches())
        throw new IllegalArgumentException("Invalid name specified: ${osName}");
      group(1);
    })
    def version = convert((osVersion.toLowerCase() =~ /([0-9\.]++).*/).with {
      if (!matches())
        throw new IllegalArgumentException("Invalid version specified: ${osVersion}");
      group(1)
    })

    if (!['linux', 'win'].contains(name))
      return MBA_UNKNOWN_PLATFORM;

    return "${arch}_${name}_${version}"

  }

  def convert(value) {
    if (CONVERSIONS.containsKey(value))
      return CONVERSIONS[value];
    value;
  }

}
