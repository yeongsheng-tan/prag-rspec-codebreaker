package gmrt.code.builds.plugin.builds.labels

import gmrt.code.builds.plugin.builds.ManagedContext
import gmrt.mba.Appliance

import hudson.model.Node

import org.apache.commons.lang.StringUtils
import org.apache.log4j.Logger

import hudson.remoting.VirtualChannel
import gmrt.code.builds.plugin.builds.BuildsPlugin
import gmrt.code.builds.plugin.builds.BuildsMasterWorker
import gmrt.code.builds.plugin.builds.BuildsWorker

/**
 * Implements the actual logic
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/12/11
 */
class PlatformIdLabeler {

  private static final Logger LOG = Logger.getLogger(PlatformIdLabeler.class);

  /**
   * Executes the actual labeling operation.
   *
   * @see PlatformIdTask
   */
  public Set<String> labelNode(Node node, VirtualChannel channel) throws IOException, InterruptedException {

    if (LOG.isDebugEnabled())
      LOG.debug("Executing platform labeling for worker coming online: " + node.displayName);

    PlatformIdLabelMaker labelerPlatform = Appliance.getInstance().getBean(ManagedContext.class, PlatformIdLabelMaker.class);
    PlatformIdComposer composerPlatform = Appliance.getInstance().getBean(ManagedContext.class, PlatformIdComposer.class);

    String[] platformIdPieces = StringUtils.split(channel.call(new PlatformIdTask()), '|');
    String platformId = composerPlatform.compose(platformIdPieces[0], platformIdPieces[1],
            platformIdPieces[2], platformIdPieces[3]);

    LOG.info("Determined platformId (" + platformId + ") for worker: " + node.displayName);

    Set<String> atoms = labelerPlatform.getLabels(platformId)

    // Add the worker label, master is just using its name as the label pickup.
    if (node instanceof BuildsMasterWorker)
      atoms.add(BuildsMasterWorker.MBA_MASTER_WORKER_LABEL)
    else
      atoms.add(BuildsWorker.MBA_WORKER_LABEL);

    if (LOG.isDebugEnabled())
      LOG.debug("Determined label atoms (" + atoms + ") for worker: " + node.displayName);

    return atoms;
  }

}
