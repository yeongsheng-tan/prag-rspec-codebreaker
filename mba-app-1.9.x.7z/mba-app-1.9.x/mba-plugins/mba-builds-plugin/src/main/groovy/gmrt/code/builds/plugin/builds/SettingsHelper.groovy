package gmrt.code.builds.plugin.builds

import gmrt.da.auth.User
import gmrt.mba.Appliance
import gmrt.mba.HostResolver
import hudson.model.AbstractBuild
import hudson.model.Executor
import hudson.model.TaskListener
import org.apache.velocity.VelocityContext
import org.apache.velocity.app.VelocityEngine

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/19/11
 */
public class SettingsHelper {

/**
 * Creates the settings.xml for a deployment. Combines the "global" template that is maintained in the Hudson
 * administration interface with whatever we can make available at the job level:
 * <ul>
 * <li><b>env({@link Map})</b>: Build environment variables, includes
 * {@link AbstractBuild#getEnvironment(TaskListener)} and {@link hudson.model.Computer#getEnvironment()}
 * <li><b>worker({@link User})</b>
 * <li><b>build({@link hudson.model.AbstractBuild})</b>
 * <li><b>env({@link hudson.EnvVars}</b>
 * </ul>
 *
 * @see SettingsHelper#createSettings
 */
  public String createBuildSettings(String id,
                                    User worker,
                                    Executor executor, AbstractBuild build, TaskListener listener,
                                    String settingsXmlTemplate)
  throws IOException, InterruptedException {

    Map<String, String> env = new HashMap<String, String>();
    env.putAll(build.getEnvironment(listener));
    env.putAll(build.getBuildVariables());
    if (build.executor)
      env.putAll(build.getExecutor().getOwner().getEnvironment());

    Map<String, Object> binding = new HashMap<String, Object>();
    binding.put("build", build);
    binding.put("env", env);
    binding.put('worker', worker);

    return processTemplate(id, settingsXmlTemplate, binding, listener);
  }

  /**
   * Combines the provided binding map with the template specified.
   */
  public String processTemplate(String id, String settingsXmlTemplate, Map<String, Object> binding, TaskListener listener) {
    String settings = null;
    try {
      settings = createSettings(id, settingsXmlTemplate, binding);
    } catch (IOException e) {
      listener.fatalError("There is a problem with your deploy settings template ...", e);
    }

    return settings
  }

  /**
   * Renders the provided template string using a {@link org.apache.velocity.app.VelocityEngine}. Provides a few
   * objects in the binding by default:
   * <li><b>appliance</b> {@link gmrt.mba.Appliance}
   * <li><b>hostResolver</b> {@link HostResolver}
   *
   * @param id Unique id that will be used in logging any exceptions. (i.e. Build Settings or Developer Settings)
   */
  public String createSettings(String id, String settingsXmlTemplate, Map<String, Object> _binding) throws IOException {

    HostResolver hr = Appliance.instance.getBean(Appliance.class, HostResolver.class);

    HashMap<String, Object> binding = new HashMap<String, Object>(_binding);
    binding.put("appliance", Appliance.instance)
    binding.put("hostResolver", hr);

    StringWriter sw = new StringWriter();

    VelocityEngine engine = Appliance.instance.getBean(Appliance.class, VelocityEngine.class);
    engine.evaluate(new VelocityContext(binding), sw, id, settingsXmlTemplate);
    return sw.toString();

  }

}
