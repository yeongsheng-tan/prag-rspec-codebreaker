package gmrt.code.builds.plugin.builds.labels

/**
 * Thrown when a label contains a character that is invalid according to the
 * {@link hudson.model.labels.LabelExpressionLexer}.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/11/11
 */
class InvalidLabelCharException extends RuntimeException {

  /**
   * List of characters or sequences that are "illegal" for Hudson labels. Derived from the source of the
   * {@link hudson.model.labels.LabelExpressionLexer}
   */
  public static final String[] ILLEGAL_CHARS = ["-"] as String[];

  InvalidLabelCharException(String label) {
    super(String.valueOf("Label contains an invalid character: ${label}. Complete list of invalid characters is: ${ILLEGAL_CHARS}"));
  }
}
