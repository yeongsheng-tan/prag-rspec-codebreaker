package gmrt.code.builds.plugin.builds

import gmrt.mba.HostResolver

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 8/9/11
 */
class RemotingJarInstrumenter {

  final File remotingJar;
  final HostResolver hostResolver;

  RemotingJarInstrumenter(File remotingJar, HostResolver hostResolver) {
    this.remotingJar = remotingJar
    this.hostResolver = hostResolver
  }

  void perform() {

    File mbaProps = File.createTempFile('mba', 'props');
    mbaProps.write("""
mba.remoting.host=${hostResolver.name}
mba.remoting.port=${hostResolver.port}
""")

    AntBuilder ant = new AntBuilder();
    ant.zip(destfile: remotingJar, update: true) {
      zipfileset(dir: mbaProps.parentFile, includes: mbaProps.name, fullpath: "META-INF/mba-builds-remoting/mba.remoting.properties")
    }

  }

}
