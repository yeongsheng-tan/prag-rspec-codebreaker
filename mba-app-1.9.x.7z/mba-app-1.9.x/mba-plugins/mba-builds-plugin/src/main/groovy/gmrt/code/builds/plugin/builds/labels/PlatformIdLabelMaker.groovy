package gmrt.code.builds.plugin.builds.labels

/**
 * Maps a simple platform id into a series of labels. ex: "x86.64_linux_2.6.18" will map to a Hudson label expression
 * of "x86 x86.64 linux linux_2 linux_2.6 linux_2.6.18".
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/4/11
 */
class PlatformIdLabelMaker {

  private static final PATTERN = /([a-z0-9]{2,})\.?(\d++)?(?:_?([a-z]++)?(?:_?([0-9\.]++)?)?)?/

  /**
   * Basic mapping to a Hudson node label expression.
   */
  public Set<String> getLabels(String platformId) throws InvalidLabelCharException, InvalidPlatformIdException {

    if (platformId == PlatformIdComposer.MBA_UNKNOWN_PLATFORM)
      return checkLabelsForInvalidChars([platformId] as Set<String>);

    def (String arch, String bits, String os, String ver) = (platformId?.toLowerCase() =~ PATTERN).with {
      if (!matches())
        throw new InvalidPlatformIdException(platformId);
      return [group(1), group(2), group(3), group(4)];
    }

    def labels = new LinkedHashSet<String>();
    labels << arch.trim();
    if (bits)
      labels << "${arch}.${bits}".toString();
    if (os)
      labels << os.trim();
    if (ver) {
      def verFrag;
      ver.split(/\./).each {
        verFrag = "${(verFrag ? "${verFrag}." : '')}${it}";
        labels << "${os}_${verFrag}".trim();
      }
    }

    checkLabelsForInvalidChars(labels);
  }

  /**
   * Checks the characters in each label against the {@link InvalidLabelCharException#ILLEGAL_CHARS} list, throwing
   * that exception when one is encountered.
   * @throws InvalidLabelCharException
   */
  protected Set<String> checkLabelsForInvalidChars(Set<String> labels) throws InvalidLabelCharException {
    InvalidLabelCharException.ILLEGAL_CHARS.each { invalidChar ->
      labels.each { label ->
        if (label.contains(invalidChar))
          throw new InvalidLabelCharException(label);
      }
    }
    labels;
  }

}
