package gmrt.code.builds.plugin.builds

import org.testng.Assert
import org.testng.annotations.Test

/**
 * These aren't even close to a complete set. Definitely needs some test cases filled in.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/4/11
 */
class PlatformIdComposerTest {

  def gmrt.code.builds.plugin.builds.labels.PlatformIdComposer comp = new gmrt.code.builds.plugin.builds.labels.PlatformIdComposer();

  @Test
  void standardLinuxPlatforms() {

    // This would be a 32bit jvm running on a 64bit processor.
    Assert.assertEquals(comp.compose('amd64', '32', 'Linux', '2.6.18-164.2.1.el5'), 'x86.64_linux_2.6.18')
    Assert.assertEquals(comp.compose('x86.64', '32', 'Linux', '2.6.18'), 'x86.64_linux_2.6.18')

    Assert.assertEquals(comp.compose('x86', '64', 'Linux', '2.6'), 'x86.64_linux_2.6');
  }

  @Test
  void standardWinPlatforms() {
    Assert.assertEquals(comp.compose('x86', '32', 'Windows 2003', '5.2'), 'x86.32_win_5.2')
    Assert.assertEquals(comp.compose('x86', '64', 'Windows 7', '6.1'), 'x86.64_win_6.1')
  }

  @Test
  void whoKnows() {
    Assert.assertEquals(comp.compose('alt21', '4', 'Badass Homebrew', '1989'), gmrt.code.builds.plugin.builds.labels.PlatformIdComposer.MBA_UNKNOWN_PLATFORM);
  }
}
