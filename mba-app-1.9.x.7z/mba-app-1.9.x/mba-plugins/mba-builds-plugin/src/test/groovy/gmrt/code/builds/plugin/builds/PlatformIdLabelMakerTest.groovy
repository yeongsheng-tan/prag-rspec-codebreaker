package gmrt.code.builds.plugin.builds

import org.testng.Assert
import org.testng.annotations.Test

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 2/4/11
 */
class PlatformIdLabelMakerTest {

  gmrt.code.builds.plugin.builds.labels.PlatformIdLabelMaker labeler = new gmrt.code.builds.plugin.builds.labels.PlatformIdLabelMaker();

  @Test
  void simplePlatformIds() {

    Assert.assertEquals(labeler.getLabels("x86_linux_2.6.18"), ['x86','linux','linux_2','linux_2.6','linux_2.6.18']);
    Assert.assertEquals(labeler.getLabels("x86.32_linux_2.6"), ['x86','x86.32','linux','linux_2','linux_2.6']);
    Assert.assertEquals(labeler.getLabels("x86.64_linux"), ['x86','x86.64','linux']);
    Assert.assertEquals(labeler.getLabels("x86.64_linux_2.6.22"), ['x86','x86.64','linux','linux_2','linux_2.6','linux_2.6.22']);
    Assert.assertEquals(labeler.getLabels("x86_win_6.1"), ['x86','win','win_6','win_6.1']);
    Assert.assertEquals(labeler.getLabels("x86_win"), ['x86','win']);
    Assert.assertEquals(labeler.getLabels("x86"), ['x86']);
    Assert.assertEquals(labeler.getLabels("x86.32"), ['x86','x86.32']);

  }

  @Test(expectedExceptions = gmrt.code.builds.plugin.builds.labels.InvalidPlatformIdException.class)
  void invalidArch() {

    labeler.getLabels("x.64_linux");

  }

  @Test(expectedExceptions = gmrt.code.builds.plugin.builds.labels.InvalidPlatformIdException.class)
  void invalidOs() {

    labeler.getLabels("amd64_linux32_5.4.3");

  }

  @Test(expectedExceptions = gmrt.code.builds.plugin.builds.labels.InvalidPlatformIdException.class)
  void invalidVersionWithLetters() {
    labeler.getLabels("x86.64_win_XP");
  }

  @Test(expectedExceptions = gmrt.code.builds.plugin.builds.labels.InvalidPlatformIdException.class)
  void invalidVersionWithUnderScore() {
    labeler.getLabels("x86.32_win_43_4");
  }

  @Test
  void unknownPassesThrough() {
    Assert.assertEquals(labeler.getLabels(gmrt.code.builds.plugin.builds.labels.PlatformIdComposer.MBA_UNKNOWN_PLATFORM), [gmrt.code.builds.plugin.builds.labels.PlatformIdComposer.MBA_UNKNOWN_PLATFORM]);
  }

  @Test(expectedExceptions = gmrt.code.builds.plugin.builds.labels.InvalidPlatformIdException.class)
  void invalidPlatformId() {
    labeler.getLabels('x86-64');
  }

}
