//package gmrt.code.builds.plugin.builds;
//
//import org.testng.Assert;
//import org.testng.annotations.Test;
//
///**
// * @author : nbkippo
// * @since : 2/8/12
// */
//
//public class DispatcherAvailabilityTest {
//
//    @Test (groups = "SingletonTest")
//    public void testInputData(){
//        Dispatcher dispatcher = new Dispatcher();
//        dispatcher.workerName = "MBS_test_worker";
//        dispatcher.computerUrl = "computer.getUrl()";
//        dispatcher.label = "test_mbs";
//        DispatcherAvailability.getInstance().setWorkerToLaunchTracker(dispatcher);
//        Assert.assertEquals(DispatcherAvailability.getInstance().dispatchedWorkers.get("MBS_test_worker"), dispatcher);
//    }
//
//    @Test(groups = "SingletonTest", dependsOnMethods = "testInputData")
//    public void testRemoveData(){
//        DispatcherAvailability.getInstance().removeWorkerFromLaunchTracker("MBS_test_worker");
//        assert (DispatcherAvailability.getInstance().dispatchedWorkers.isEmpty());
//    }
//}