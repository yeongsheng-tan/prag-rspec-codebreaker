package gmrt.mba.plugins.mvn;

import gmrt.mba.plugins.tools.ToolListener;
import hudson.Extension;
import hudson.FilePath;
import hudson.model.Hudson;
import hudson.model.Node;
import hudson.model.TaskListener;
import hudson.tasks.Maven;
import hudson.tools.ToolInstallation;

import java.io.IOException;

/**
 * Delegates to {@link MvnPlugin#writeToolSettings(hudson.tasks.Maven.MavenInstallation, hudson.model.Node, hudson.model.TaskListener)}
 * when a {@link hudson.tasks.Maven.MavenInstallation} is installed.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 8/24/11
 */
@Extension
public class MvnToolListener extends ToolListener {

    @Override
    public void onInstalled(Node node, ToolInstallation tool, FilePath path, TaskListener listener)
            throws IOException, InterruptedException {

        if (tool instanceof Maven.MavenInstallation) {
            MvnPlugin.getInstance().writeToolSettings((Maven.MavenInstallation) tool, node, listener);
            MvnPlugin.getInstance().writeScmSettings(node, listener);
        }

    }
}
