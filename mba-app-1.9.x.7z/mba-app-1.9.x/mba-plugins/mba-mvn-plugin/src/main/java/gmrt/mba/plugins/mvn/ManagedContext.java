package gmrt.mba.plugins.mvn;

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/10/11
 */
public interface ManagedContext extends gmrt.da.ManagedContext {
}
