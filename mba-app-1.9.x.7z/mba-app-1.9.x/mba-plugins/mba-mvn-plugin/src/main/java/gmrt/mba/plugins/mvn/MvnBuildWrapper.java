package gmrt.mba.plugins.mvn;

import gmrt.code.builds.plugin.builds.BuildsEnvAction;
import gmrt.code.builds.plugin.builds.Util;
import hudson.Extension;
import hudson.Launcher;
import hudson.maven.MavenBuild;
import hudson.maven.MavenModuleSet;
import hudson.maven.MavenModuleSetBuild;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.model.Computer;
import hudson.model.listeners.RunListener;
import hudson.tasks.BuildWrapper;
import hudson.tasks.BuildWrapperDescriptor;

import java.io.IOException;
import java.util.*;

/**
 * Adds the {@link MvnPlugin#MBA_ARTIFACTS_LOCAL} env variable to the build and that's just about all this does now.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 12, 2010
 */
public class MvnBuildWrapper extends BuildWrapper {

    /**
     * This is sort of a "dummy" descriptor that shouldn't really be used as we are "injecting" the wrapper
     * automatically from the {@link RunListener}.
     */
    @Extension
    public static class DescriptorImpl extends BuildWrapperDescriptor {
        /**
         * Returns false for everything- we don't need anyone to add this wrapper we'll add it via
         * {@link MvnRunListener}
         */
        @Override
        public boolean isApplicable(AbstractProject<?, ?> item) {
            return false;
        }

        @Override
        public String getDisplayName() {
            return "MBA Maven Build Wrapper";
        }
    }

    /**
     * Adds user.home to the build variables for a Maven build.
     */
    @Override
    public void makeBuildVariables(AbstractBuild build, Map<String, String> variables) {
        BuildsEnvAction ba = build.getAction(BuildsEnvAction.class);
        if (ba != null) {
            variables.put("user.home", ba.env.get(BuildsEnvAction.MBA_WORKER_HOME));
        }
    }

    /**
     * Calls {@link BuildsEnvAction#override(hudson.model.AbstractBuild, String...)} for
     * {@link MvnPlugin#MBA_ARTIFACTS_LOCAL}.
     */
    @Override
    public Environment setUp(final AbstractBuild build, Launcher launcher, final BuildListener listener)
            throws IOException, InterruptedException {

        BuildsEnvAction.override(build,
                MvnPlugin.MBA_ARTIFACTS_LOCAL, MvnPlugin.getInstance().getLocalRepositoryPath(Computer.currentComputer().getNode()).getRemote());

        return new Environment() {
            @Override
            public void buildEnvVars(Map<String, String> env) {
                BuildsEnvAction ba = build.getAction(BuildsEnvAction.class);
                if (ba != null) {
                    env.put("user.home", ba.env.get(BuildsEnvAction.MBA_WORKER_HOME));
                }
            }
        };
    }

}
