package gmrt.mba.plugins.mvn;

import gmrt.code.builds.plugin.builds.BuildsWorkerAction;
import gmrt.code.builds.plugin.builds.SettingsHelper;
import gmrt.mba.Appliance;
import gmrt.mba.HostResolver;
import hudson.FilePath;
import hudson.Plugin;
import hudson.XmlFile;
import hudson.model.Hudson;
import hudson.model.Node;
import hudson.model.TaskListener;
import hudson.tasks.Maven;
import org.apache.commons.io.IOUtils;
import org.kohsuke.stapler.StaplerRequest;
import org.kohsuke.stapler.StaplerResponse;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * This is the "configurable" global element of the appliance mvn settings, both deployment and developer.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since Dec 12, 2010
 */
public class MvnPlugin extends Plugin {

    /**
     * Environment variable added to all builds pointing to the local maven repository.
     */
    public static final String MBA_ARTIFACTS_LOCAL = "MBA_ARTIFACTS_LOCAL";

    /**
     * Environment variable pointing to the build settings.xml file relative to the build workspace.
     */
    public static final String MBA_MVN_SETTINGS = "MBA_MVN_SETTINGS";

    public static final String BUILD_SETTINGS_PROPERTY = "org.apache.maven.user-settings";

    private String mvnSettingsXml;

    private transient SettingsHelper settingsHelper = new SettingsHelper();

    /**
     * Lazily loads the tool, build and developer settings.xml files
     */
    @Override
    public void postInitialize() throws Exception {

        load();
        doLazyLoadFromResource();

    }

    private void doLazyLoadFromResource() throws IOException {
        mvnSettingsXml = readSettings("mvn-settings.xml");
    }

    public String getMvnSettingsXml() {
        return mvnSettingsXml;
    }

    /**
     * Kicks the developer settings.xml file out to the request.
     */
    public void doSettings( StaplerRequest req, StaplerResponse rsp ) throws IOException, ServletException {

        rsp.setStatus(HttpServletResponse.SC_OK);
        rsp.setContentType("application/xml; charset=UTF-8");
        rsp.setHeader("Content-Disposition", "attachment; filename=settings.xml");
        String settings = settingsHelper.createSettings("Developer Settings", mvnSettingsXml, new HashMap<String, Object>());
        rsp.serveFile(req, new ByteArrayInputStream(settings.getBytes()),
                System.currentTimeMillis(), -1, "settings.xml");
        rsp.flushBuffer();
    }

    /**
     * Returns the expected path of the global settings.xml file for the given node.
     */
    public FilePath getToolSettingsPath(Maven.MavenInstallation mvn, Node node, TaskListener listener)
            throws IOException, InterruptedException {
        mvn = mvn.forEnvironment(node.toComputer().getEnvironment()).forNode(node, listener);
        return new FilePath(node.getChannel(), mvn.getHome()).child("conf").child("settings.xml");
    }

    /**
     * Returns the local repository path for the given node
     */
    public FilePath getLocalRepositoryPath(Node node) throws IOException, InterruptedException {
        BuildsWorkerAction bwa = BuildsWorkerAction.getInstance(node);
        return bwa.getHome().child(".m2").child("repository");
    }

    /**
     * Writes the settings.xml file to the directory specified, assumes you will pass in ${TOOL}/conf as a target.
     */
    public FilePath writeToolSettings(Maven.MavenInstallation mvn, Node node, TaskListener listener)
            throws IOException, InterruptedException {

        Map<String, Object> binding = getSettingsBinding();
        binding.put("toolSettings", true);
        binding.put("localRepository", getLocalRepositoryPath(node).getRemote());

        FilePath remoteSettings = getToolSettingsPath(mvn, node, listener);
        writeSettings("tool settings", getMvnSettingsXml(), binding, remoteSettings, listener);

        return remoteSettings;
    }

    /**
     * Writes the WORKER_HOME/.scm/svn-settings.xml file which provides a configuration for the mvn svn scm provider.
     */
    public FilePath writeScmSettings(Node node, TaskListener listener) throws IOException, InterruptedException {
        BuildsWorkerAction bwa = BuildsWorkerAction.getInstance(node);
        FilePath scmSettings = bwa.getHome().child(".scm").child("svn-settings.xml");
        writeSettings("scm settings", readSettings("svn-settings.xml"), new HashMap<String, Object>(), scmSettings, listener);
        return scmSettings;
    }

    private void writeSettings(String id, String template, Map<String, Object> binding, FilePath target, TaskListener listener)
            throws IOException, InterruptedException {

        String settingsXml = settingsHelper.processTemplate(id, template, binding, listener);

        listener.getLogger().println("[MBA] Writing " + id + " to: " + target.getRemote());
        target.write(settingsXml, "UTF-8");

    }

    private Map<String, Object> getSettingsBinding() {
        Map<String, Object> binding = new HashMap<String, Object>();
        binding.put("appliance", Appliance.getInstance());
        binding.put("hostResolver", Appliance.getInstance().getBean(Appliance.class, HostResolver.class));
        return binding;
    }

    private String readSettings(String filename) throws IOException {
        return IOUtils.toString(getSettings(filename));
    }

    private InputStream getSettings(String filename) throws IOException {
        return Appliance.getInstance().getContext(ManagedContext.class).
                getResource("classpath:gmrt/mba/plugins/mvn/ManagedContext/" + filename).getInputStream();
    }

    /**
     * Overloaded to control the filename, I wanted it to be the fqcn.
     */
    protected XmlFile getConfigXml() {
        return new XmlFile(Hudson.XSTREAM,
                new File(Hudson.getInstance().getRootDir(),getClass().getName()+".xml"));
    }

    /**
     * Shortcut for {@link Hudson#getPlugin(Class)}
     */
    public static MvnPlugin getInstance() {
        return Hudson.getInstance().getPlugin(MvnPlugin.class);
    }
}
