package gmrt.mba.plugins.mvn;

import hudson.Extension;
import hudson.model.RootAction;

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 9/4/11
 */
@Extension
public class MvnSettingsAction implements RootAction {

    @Override
    public String getIconFileName() {
        return "clipboard.png";
    }

    @Override
    public String getDisplayName() {
        return "Maven Settings";
    }

    @Override
    public String getUrlName() {
        return "/plugin/mba-mvn-plugin/settings";
    }
}
