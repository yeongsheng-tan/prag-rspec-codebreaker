package gmrt.mba.plugins.mvn;

import hudson.Extension;
import hudson.maven.AbstractMavenBuild;
import hudson.model.*;
import hudson.model.listeners.RunListener;
import hudson.tasks.BuildWrapper;
import hudson.util.DescribableList;

import java.io.IOException;

/**
 * Adds the {@link MvnBuildWrapper} to all builds.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 1/21/11
 */
@Extension
public class MvnRunListener extends RunListener<AbstractBuild<? extends AbstractProject<?, ?>, ?>> {

    @Override
    public void onStarted(AbstractBuild<? extends AbstractProject<?, ?>, ?> build, TaskListener listener) {
        if (build.getProject() instanceof BuildableItemWithBuildWrappers) {
            try {
                DescribableList<BuildWrapper,Descriptor<BuildWrapper>> list =
                        ((BuildableItemWithBuildWrappers) build.getProject()).getBuildWrappersList();
                if (list.get(MvnBuildWrapper.class) == null)
                    list.add(new MvnBuildWrapper());
            } catch (IOException e) {
                listener.fatalError("[MBA] Exception occured adding the MvnBuildWrapper: %s", e.getMessage());
            }
        }
    }

}
