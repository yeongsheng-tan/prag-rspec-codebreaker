package gmrt.mba.plugins.update

import gmrt.mba.builds.plugin.artifacts.Ga
import gmrt.mba.builds.plugin.artifacts.Gav
import gmrt.mba.builds.plugin.artifacts.Repository
import gmrt.mba.plugins.update.util.HpiJsonUtil
import net.sf.json.JSONObject
import org.apache.log4j.Logger
import org.testng.Assert
import org.testng.annotations.BeforeSuite
import org.testng.annotations.Test

/**
 * @author yeongsheng.tan@baml.com
 * @since 3/18/11
 */
class UpdatePluginTest {
    private static Logger LOG = Logger.getLogger(UpdatePluginTest.class);

    Repository repo;

	/**
	 * Constructs a new {@link Repository} instance using the MBA_ARTIFACTS_GROUP environment variable. Will call
	 * {@link Repository#updateIndex} if there is no local copy of it.
	 */
	@BeforeSuite(groups = "SYSTEM_INTEGRATION")
	void prepare() {
		def repoDir = new File("target/test-data/${getClass().getName()}/mba-group")
		def idxExists = (new File(repoDir, ".index")).exists()
		repo = new Repository('mba-group',System.getenv()['MBA_ARTIFACTS_GROUP'].toURL(),repoDir);

		if (!idxExists)
            repo.updateIndex(System.out)
	}

	@Test(groups = "SYSTEM_INTEGRATION")
	void hpiJsonFormatter(){
		def jsonUtil = new HpiJsonUtil()

		def results = repo.find().groupId("gmrt.mba.plugins").packaging("hpi").grouped().collect { Ga ga, List<Gav> gavs ->
			println "${ga}:"
			Gav firstHpiGav = null
			gavs.each { gav ->
				println "\t${gav}"
				if(firstHpiGav==null){
					if(!gav.version.endsWith('-SNAPSHOT'))
						firstHpiGav = gav
				}
			}

			if(firstHpiGav!=null){
                print "Resolving ${firstHpiGav}: "
                repo.resolve(firstHpiGav.narrow('hpi', null)).with {
                    Assert.assertTrue(it.exists())
                    Assert.assertTrue(it.name.endsWith('.hpi'))
                    println path
                    it

                    JSONObject jsonStream = jsonUtil.toUpdateCenterPluginsJsonFormat(it,null)
                    print "\nHpi json formatted output: "
                    println(jsonStream.toString(4))
                    Assert.assertNotNull(jsonStream)
                }
            }
		}
		Assert.assertTrue(results.size() > 0)
	}
}
