package gmrt.mba.plugins.update;

import hudson.model.Hudson;
import hudson.model.UpdateSite;
import org.apache.log4j.Logger;
import org.objenesis.ObjenesisStd;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.testng.PowerMockTestCase;
import org.testng.annotations.Test;

import java.io.File;

import static org.mockito.Mockito.spy;

/**
 * @author yeongsheng.tan@baml.com
 * @since 10/4/11
 */
//@RunWith(PowerMockRunner.class)
@PrepareForTest({Hudson.class})
@PowerMockIgnore("javax.*")
public class MbaUpdateSiteTest extends PowerMockTestCase{
	private static Logger LOG = Logger.getLogger(MbaUpdateSiteTest.class);


	@Test(groups = "SYSTEM_INTEGRATION")
	public void testMbaUpdateSiteLoad() throws Exception {
		File jenkinsRootDirectory = new File("./src/test/resources");
		Hudson hudson = spy((Hudson) new ObjenesisStd().getInstantiatorOf(Hudson.class).newInstance());
		PowerMockito.doReturn(jenkinsRootDirectory).when(hudson).getRootDir();
		PowerMockito.mockStatic(Hudson.class);
		PowerMockito.doReturn(hudson).when(Hudson.class);
		Hudson.getInstance();

		UpdateSite site = new MbaUpdateSite(UpdatePluginConstants.mbaUpdateSiteId,"mbaupdatecenter/");
	}
}
