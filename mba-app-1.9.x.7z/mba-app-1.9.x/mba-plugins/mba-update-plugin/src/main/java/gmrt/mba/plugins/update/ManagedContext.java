package gmrt.mba.plugins.update;

/**
 * @author yeongsheng.tan@baml.com
 * @since 4/11/11
 */
public interface ManagedContext extends gmrt.da.ManagedContext  {
}
