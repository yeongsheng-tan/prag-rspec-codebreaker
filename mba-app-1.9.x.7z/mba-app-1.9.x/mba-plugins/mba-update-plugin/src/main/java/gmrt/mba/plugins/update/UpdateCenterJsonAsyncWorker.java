package gmrt.mba.plugins.update;

import hudson.Extension;
import hudson.model.AsyncPeriodicWork;
import hudson.model.Hudson;
import hudson.model.TaskListener;
import org.apache.log4j.Logger;

import java.io.IOException;

/**
 * @author yeongsheng.tan@bankofamerica.com
 * @since 9/19/11
 */
@Extension
public class UpdateCenterJsonAsyncWorker extends AsyncPeriodicWork {
	private static Logger LOG = Logger.getLogger(UpdateCenterJsonAsyncWorker.class);

	public UpdateCenterJsonAsyncWorker() {
		super(UpdateCenterJsonAsyncWorker.class.getName());
	}

	@Override
	public void execute(TaskListener listener) throws IOException, InterruptedException {
		UpdatePlugin plugin = getPlugin();
		plugin.downloadUpdateSiteJSON();

	}

	@Override
	public long getRecurrencePeriod() {
		return UpdatePluginConstants.updateSiteRefreshRate;
	}

	@Override
	public long getInitialDelay() {
		return 1000;
	}

	protected UpdatePlugin getPlugin() {
		return Hudson.getInstance().getPlugin(UpdatePlugin.class);
	}
}
