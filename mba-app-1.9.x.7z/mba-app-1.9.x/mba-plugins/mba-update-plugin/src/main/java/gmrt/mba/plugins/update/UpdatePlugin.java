package gmrt.mba.plugins.update;

import gmrt.code.builds.plugin.builds.BuildsEnvAction;
import gmrt.code.builds.plugin.builds.BuildsWorkerAction;
import gmrt.code.builds.plugin.builds.SettingsHelper;
import gmrt.mba.Appliance;
import gmrt.mba.Config;
import gmrt.mba.HostResolver;
import gmrt.mba.auth.WorkerRealm;
import gmrt.mba.plugins.update.model.PluginEntry;
import gmrt.mba.plugins.update.util.TimeoutReference;
import hudson.FilePath;
import hudson.Plugin;
import hudson.XmlFile;
import hudson.model.*;
import hudson.util.FormValidation;
import net.sf.json.JSONObject;
import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.oro.text.regex.*;
import org.kohsuke.stapler.StaplerRequest;
import org.kohsuke.stapler.StaplerResponse;
import org.springframework.core.io.Resource;

import javax.servlet.ServletException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.GeneralSecurityException;
import java.util.*;

/**
 * @author jason.stiefel@bankofamerica.com
 * @author yeongsheng.tan@baml.com
 * @since 1/28/11
 */
public class UpdatePlugin extends Plugin {
    private static Logger LOG = Logger.getLogger(UpdatePlugin.class);
	// url to the update-center.json file;
	// if MasterUpdateHost=currentHost, looks up in ${JENKINS_HOME}/userContent/updateCenter/update-center.json else
	// http://${defaultMasterUpdateHost}/builds/userContent/updateCenter/update-center.json
	public String updateSiteUrl="";
	public String defUpdateSiteUrlSuffix="/builds/userContent/updateCenter/update-center.json";
	private transient boolean updateSiteValid = true;
	private transient String updateSiteFailCause = "";
	private transient SettingsHelper settingsHelper = new SettingsHelper();
	private static final String UPDATE_URL_REGEX = "http:\\/\\/.*:[0-9]{4}\\/{1}builds\\/userContent\\/updateCenter\\/update\\-center\\.json$";
	private static final String mbaUpdateCenterJobName = "_mba.update.center";
	private final PatternCompiler compiler = new Perl5Compiler();
	private final PatternMatcher matcher = new Perl5Matcher();
	private Pattern pattern = null;

	TimeoutReference<List<PluginEntry>> pluginEntryReference = new TimeoutReference<List<PluginEntry>>(UpdatePluginConstants.updateSiteRefreshRate,
																			new TimeoutReference.ReferenceRetriever<List<PluginEntry>>() {
																				public List<PluginEntry> createReference() {
																					try {
																						List<PluginEntry> pluginEntries = getPluginEntries();
																						UpdatePlugin.this.pluginEntryReference.put(pluginEntries);
																						return pluginEntries;
																					} catch (Exception e) {
																						LOG.error("[MBA] Error while retrieving plugin entries", e);
																					}
																					return Collections.emptyList();
																				}
																			});

	public void setUpdateSiteUrl(String updateSiteUrl) {
		this.updateSiteUrl = updateSiteUrl;
	}

	public String getUpdateSiteUrl() {
		return this.updateSiteUrl;
	}

	public void setUpdateSiteValid(boolean updateSiteValid) {
		this.updateSiteValid = updateSiteValid;
	}

	public boolean isUpdateSiteValid() {
		return this.updateSiteValid;
	}

	public void setUpdateSiteFailCause(String updateSiteFailCause) {
		this.updateSiteFailCause = updateSiteFailCause;
	}

	public String getUpdateSiteFailCause() {
		return this.updateSiteFailCause;
	}

	@Override
	public void configure(StaplerRequest req, JSONObject json) throws IOException, ServletException, Descriptor.FormException {
		super.configure(req, json);

		String updSiteUrlStr = req.getParameter("mbaupdatesite.updateSiteUrl");
		URL updSiteUrl = null;
		if(pattern==null)
			throw new ServletException("[MBA] Regex pattern for update-center.json URL not initialized!");
		if(!matcher.contains(updSiteUrlStr,pattern)){
			updSiteUrl = new URL(StringUtils.trim(getUpdateSiteUrl()));
		}else{
			if (!StringUtils.equals(updSiteUrlStr, getUpdateSiteUrl())) {
				diagnoseUpdateSiteUrl(updSiteUrlStr);
				setUpdateSiteUrl(updSiteUrlStr);
				Config config = Appliance.getInstance().getConfig();
				config.setMbaUpdateHost(updSiteUrl.getHost());
				config.setMbaUpdatePort(updSiteUrl.getPort());
				downloadUpdateSiteJSON();
				this.pluginEntryReference.invalidate();
			}
		}
		save();
	}

    /**
     * Removes the default update site and adds the MBS update site.
     */
	public void postInitialize() throws Exception {
		pattern = compiler.compile(UPDATE_URL_REGEX,Perl5Compiler.DEFAULT_MASK);

		// init the Master CODE/ MBA Update Site URL using settings in mba.properties
		Config config = Appliance.getInstance().getConfig();
		if(config.getMbaUpdateHost()==null || config.getMbaUpdatePort()==0 || config.getMbaUpdateHost().trim().length()==0)
			throw new Exception("[MBA] UpdatePlugin postInitialize error: mba.properties file props mba.update.host and/or mba.update.port is/ empty");

        LOG.info("[MBA] Configuring Managed Build Appliance update sites ...");

		LOG.info("[MBA] Removed all existing update sites.");
		Hudson.getInstance().getUpdateCenter().getSites().removeAll(UpdateSite.class);

	    updateSiteUrl="http://updates.jenkins-ci.org/update-center.json";
		Hudson.getInstance().getUpdateCenter().getSites().add(new MbaUpdateSite("default",updateSiteUrl));
		LOG.info("[MBA] Added default update site: " + updateSiteUrl);
		updateSiteUrl = "http://" + config.getMbaUpdateHost() + ":" + config.getMbaUpdatePort() + defUpdateSiteUrlSuffix;
		Hudson.getInstance().getUpdateCenter().getSites().add(new MbaUpdateSite(UpdatePluginConstants.mbaUpdateSiteId,updateSiteUrl));
		LOG.info("[MBA] Added " + UpdatePluginConstants.mbaUpdateSiteId + " update site: " + updateSiteUrl);
	    new XmlFile(UpdateCenter.XSTREAM,new File(Hudson.getInstance().root,UpdateCenter.class.getName()+".xml")).write(Hudson.getInstance().getUpdateCenter().getSites());
		//Persist the updateCenter sites collection changes
		Hudson.getInstance().getUpdateCenter().save();
		LOG.info("[MBA] Updated UpdateCenter object state with UpdateSites changes");

		super.postInitialize();

		MbaUpdateSite updateSite = (MbaUpdateSite) Hudson.getInstance().getUpdateCenter().getById(UpdatePluginConstants.mbaUpdateSiteId);
		if(!updateSite.isMasterCodeMbaHost()){
			diagnoseUpdateSiteUrl(getUpdateSiteUrl());
		}else{
			LOG.info("[MBA] this appliance is designated as the Master CODE/Builds appliance to serve as the UpdateCenter.");
			initUpdateCenterStorageStructure();
			LOG.info("[MBA] attemtping to create the MBA UpdateCenter build job on Master CODE/Builds appliance if it does not exist.");
			String  updateCenterJobConfigXmlPath = "classpath:gmrt/mba/plugins/update/ManagedContext/config.xml";
			initUpdateCenterBuildJob(mbaUpdateCenterJobName,Appliance.getInstance().getContext(ManagedContext.class).getResource(updateCenterJobConfigXmlPath).getInputStream());
		}
	}

	public FormValidation doRefreshPluginInfo(StaplerRequest req, StaplerResponse rsp) throws IOException, ServletException {
		try {
			downloadUpdateSiteJSONForce();
			this.pluginEntryReference.invalidate();
			setUpdateSiteValid(true);
			return FormValidation.ok("Refresh completed. Refresh the browser");
		} catch (IOException e) {
			return FormValidation.error("Refresh error - cause : " + e.getMessage());
		}
	}

	public String getDefaultUpdateSiteUrl(){
		MbaUpdateSite mbaUpdSite = (MbaUpdateSite) Hudson.getInstance().getUpdateCenter().getById(UpdatePluginConstants.mbaUpdateSiteId);
		String defUpdSiteUrl = "http://" + mbaUpdSite.getMasterUpdateHost();
        defUpdSiteUrl += defUpdateSiteUrlSuffix;
		return defUpdSiteUrl;
	}

	public List<PluginEntry> getPluginEntryReference() {
		List<PluginEntry> pluginEntries = new ArrayList<PluginEntry>();
		List<PluginEntry> list = this.pluginEntryReference.get();
		if (list != null) {
			for (PluginEntry pluginEntry : list) {
				pluginEntries.add(pluginEntry);
			}
		}
		return pluginEntries;
	}

	public String getUpdateSiteJSON(String url) throws HttpException, IOException {
		GetMethod method = new GetMethod(url);
		InputStream responseBodyAsStream = null;
		try {
			method.getParams().setCookiePolicy(CookiePolicy.IGNORE_COOKIES);
			HttpClient client = new HttpClient();
			client.getParams().setConnectionManagerTimeout(UpdatePluginConstants.httpTimeOut);
			client.getParams().setSoTimeout(UpdatePluginConstants.httpTimeOut);
			DefaultHttpMethodRetryHandler handler = new DefaultHttpMethodRetryHandler(2, false);
			client.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, handler);
			client.executeMethod(method);
			responseBodyAsStream = method.getResponseBodyAsStream();
			return IOUtils.toString(responseBodyAsStream, "UTF-8");
		} finally {
			IOUtils.closeQuietly(responseBodyAsStream);
			method.releaseConnection();
		}
	}

	public void downloadUpdateSiteJSON() throws HttpException, IOException {
		String updateCenterUrl = getUpdateSiteUrl();
		diagnoseUpdateSiteUrl(updateCenterUrl);
		MbaUpdateSite mbaUpdSite = (MbaUpdateSite) Hudson.getInstance().getUpdateCenter().getById(UpdatePluginConstants.mbaUpdateSiteId);
		if ((!this.updateSiteValid || StringUtils.isBlank(updateCenterUrl)) && !mbaUpdSite.isMasterCodeMbaHost()) {
			LOG.error("[MBA] Invalid mba update site url encountered -> " + updateCenterUrl);
			return;
		}else{
			downloadUpdateSiteJSONForce();
		}
		LOG.info("[MBA] Completed fetching update-center.json file.");
	}

	public void downloadUpdateSiteJSONForce() throws HttpException, IOException {
		LOG.info("[MBA] fetching update-center.json from " + getUpdateSiteUrl());
		String json = getUpdateSiteJSON(getUpdateSiteUrl());
		LOG.info("[MBA] raw json content fetched from " + getUpdateSiteUrl() + " : " + json);
		try {
			json = stripOutCallBackMethod(json);
			writeUpdateSiteInfo(json);
		} catch (GeneralSecurityException e) {
			LOG.error("[MBA] writing update-center.json FAILED! ", e);
		}
	}

	public String stripOutCallBackMethod(String json) {
		json = StringUtils.trimToEmpty(json);
		String prefix = "updateCenter.post(";
		String suffix = ");";
		if (json.startsWith(prefix) && json.endsWith(suffix)) {
			json = json.substring(prefix.length(), json.length() - suffix.length());
		}
		return json;
	}

	private void writeUpdateSiteInfo(String json) throws IOException, GeneralSecurityException {
		((MbaUpdateSite) Hudson.getInstance().getUpdateCenter().getById(UpdatePluginConstants.mbaUpdateSiteId)).doPostBack(null, null, json);
	}

	private List<PluginEntry> getPluginEntries() {
		List<PluginEntry> entries = new ArrayList<PluginEntry>();
		for (UpdateSite.Plugin plugin : getAvailablePlugin()) {
			entries.add(new PluginEntry(plugin, false));
		}
		Set<String> updatedPluginKey = new HashSet<String>();
		for (UpdateSite.Plugin plugin : getUpdatedPlugin()) {
			entries.add(new PluginEntry(plugin, true));
			updatedPluginKey.add(plugin.name);
		}

		for (UpdateSite.Plugin plugin : getInstalledPlugin()) {
			if (!updatedPluginKey.contains(plugin.name)) {
				entries.add(new PluginEntry(plugin, true, true));
			}
		}
		return entries;
	}

	protected List<UpdateSite.Plugin> getInstalledPlugin() {
		List<UpdateSite.Plugin> availablePlugins = new ArrayList<UpdateSite.Plugin>();
		MbaUpdateSite updateSite = (MbaUpdateSite) Hudson.getInstance().getUpdateCenter().getById(UpdatePluginConstants.mbaUpdateSiteId);
		for (UpdateSite.Plugin each : updateSite.getInstalled()) {
			if (UpdatePluginConstants.mbaUpdateSiteId.equals(each.sourceId)) {
				availablePlugins.add(each);
			}
		}
		return availablePlugins;
	}

	protected List<UpdateSite.Plugin> getAvailablePlugin() {
		List<UpdateSite.Plugin> availablePlugins = new ArrayList<UpdateSite.Plugin>();
		for (UpdateSite.Plugin each : Hudson.getInstance().getUpdateCenter().getById(UpdatePluginConstants.mbaUpdateSiteId).getAvailables()) {
			if (UpdatePluginConstants.mbaUpdateSiteId.equals(each.sourceId)) {
				availablePlugins.add(each);
			}
		}
		return availablePlugins;
	}

	protected List<UpdateSite.Plugin> getUpdatedPlugin() {
		List<UpdateSite.Plugin> availablePlugins = new ArrayList<UpdateSite.Plugin>();
		for (UpdateSite.Plugin each : Hudson.getInstance().getUpdateCenter().getById(UpdatePluginConstants.mbaUpdateSiteId).getUpdates()) {
			if (UpdatePluginConstants.mbaUpdateSiteId.equals(each.sourceId)) {
				availablePlugins.add(each);
			}
		}
		return availablePlugins;
	}

	public boolean diagnoseUpdateSiteUrl(String updateSiteUrl) {
		String diagnosis = diagnoseUrl(updateSiteUrl, UpdatePluginConstants.mbaUpdateSiteId);
		if (diagnosis == null) {
			setUpdateSiteValid(true);
		} else {
			setUpdateSiteValid(false);
			setUpdateSiteFailCause(diagnosis);
		}
		return isUpdateSiteValid();
	}

	public String diagnoseUrl(String urlString, String siteName) {
		try {
			if (StringUtils.isBlank(urlString)) {
				return String.format("<b>Empty %s Url</b><br/>- Please set it in ", siteName);
			}
			if (!matcher.contains(urlString, pattern)) {
				return String.format("<b>%s Url must end with regex format '/{1}builds/userContent/update-center.json$'</b><br/>- Please fix it in ", siteName);
			}
			checkConnection(urlString);
		} catch (IllegalArgumentException e) {
			return String.format("<b>Wrong %s Url (IllegalArgumentException)</b> (%s)<br/>- Please fix it in ", siteName, urlString);
		} catch (HttpException e) {
			return String.format("<b>Wrong %s Url (HttpException)</b> (%s)<br/>- Please fix it in ", siteName, urlString);
		} catch (IOException e) {
			LOG.error(String.format("Error on %s", siteName), e);
			return String.format("<b>Incorrect contents on %s</b> (%s)<br/>- Please fix it in ", siteName, urlString);
		} finally {
		}
		return null;
	}

	public String checkConnection(String url) throws HttpException, IOException, IllegalArgumentException {
		GetMethod method = new GetMethod(url);
		InputStream responseBodyAsStream = null;
		try {
			method.getParams().setCookiePolicy(CookiePolicy.IGNORE_COOKIES);
			HttpClient client = new HttpClient();
			client.getParams().setConnectionManagerTimeout(3000);
			client.getParams().setSoTimeout(3000);
			DefaultHttpMethodRetryHandler handler = new DefaultHttpMethodRetryHandler(1, false);
			client.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, handler);
			client.executeMethod(method);
			if (method.getStatusCode() >= 300){
				throw new HttpException();
			}
			responseBodyAsStream = method.getResponseBodyAsStream();
			return IOUtils.toString(responseBodyAsStream, "UTF-8");
		} finally {
			IOUtils.closeQuietly(responseBodyAsStream);
			method.releaseConnection();
		}
	}

	public void initUpdateCenterStorageStructure() throws IOException{
		LOG.info("[MBA] performing a check and initialization on the requisite dir structure/s to host the update-center.json file and the latest hpi plugins.");
		File buildsUpdateCenterDir = new File(System.getProperty("JENKINS_HOME") + "/userContent/updateCenter");
		File buildsUpdateCenterPluginsDir = new File(buildsUpdateCenterDir.getAbsolutePath() + "/plugins");
		File emptyUpdateCenterJsonFile = new File(buildsUpdateCenterDir.getAbsolutePath() + "/update-center.json");
		if(!buildsUpdateCenterDir.exists()){
			FileUtils.forceMkdir(buildsUpdateCenterDir);
			LOG.info("[MBA] created dir " + buildsUpdateCenterDir.getAbsolutePath());
			FileUtils.forceMkdir(buildsUpdateCenterPluginsDir);
			LOG.info("[MBA] created dir " + buildsUpdateCenterPluginsDir.getAbsolutePath());
			emptyUpdateCenterJsonFile.createNewFile();
			LOG.info("[MBA] created empty file " + emptyUpdateCenterJsonFile.getAbsolutePath());
		}else if(!buildsUpdateCenterPluginsDir.exists()){
			FileUtils.forceMkdir(buildsUpdateCenterPluginsDir);
			LOG.info("[MBA] created dir " + buildsUpdateCenterPluginsDir.getAbsolutePath());
			emptyUpdateCenterJsonFile.createNewFile();
			LOG.info("[MBA] created empty file " + emptyUpdateCenterJsonFile.getAbsolutePath());
		}else if(!emptyUpdateCenterJsonFile.exists()){
			emptyUpdateCenterJsonFile.createNewFile();
			LOG.info("[MBA] created empty file " + emptyUpdateCenterJsonFile.getAbsolutePath());
		}
	}

	public void initUpdateCenterBuildJob(String jobName, InputStream jobConfigXmlPath){
		UpdateCenterBuildJob j = new UpdateCenterBuildJob(Hudson.getInstance());
		TopLevelItem t = j.createJob(jobName,jobConfigXmlPath);
		j.writeBuildWrapperSettings(jobName);
		LOG.info("[MBA] Successfully created Job: " + jobName);
	}

	private Map<String, Object> getSettingsBinding() {
        Map<String, Object> binding = new HashMap<String, Object>();
        binding.put("appliance", Appliance.getInstance());
        binding.put("hostResolver", Appliance.getInstance().getBean(Appliance.class, HostResolver.class));
        return binding;
    }

	private void writeSettings(String id, String template, Map<String, Object> binding, FilePath target, TaskListener listener)
            throws IOException, InterruptedException {

        String buildSupportResource = settingsHelper.processTemplate(id, template, binding, listener);

        listener.getLogger().println("[MBA] Writing " + id + " to: " + target.getRemote());
        target.write(buildSupportResource, "UTF-8");
    }

	private String getBuildSettingsSupportContents(org.springframework.core.io.Resource buildSupportResource) throws IOException{
		return FileUtils.readFileToString(buildSupportResource.getFile(),"UTF-8");
	}

    /**
     * Returns the absolute path of the mba-update-center-jar-with-dependencies.jar for the given build.
     */
    public FilePath getBuildSettingsPath(Node node, String jobName, String buildSupportFileName) throws IOException, InterruptedException {
	    BuildsWorkerAction bwa = BuildsWorkerAction.getInstance(node);
	    LOG.info("[MBA] Build support filename: "+buildSupportFileName);
	    LOG.info("[MBA] Builds worker HOME: "+bwa.getHome());
	    LOG.info("[MBA] Path to stream and output build support file: "+bwa.getHome().getParent().getParent().child("workspace").child(jobName).child(buildSupportFileName).absolutize());
	    return bwa.getHome().getParent().getParent().child("workspace").child(jobName).child(buildSupportFileName).absolutize();
    }

	/**
     * Writes the CODE/Builds UpdateCenter job mba-update-center-jar-with-dependencies.jar to the expected location for the specified build.
     */
    public FilePath writeJobBuildSupportSettings(Node node, AbstractBuild build, TaskListener listener)throws IOException, InterruptedException {
        WorkerRealm realm = Appliance.getInstance().getBean(gmrt.mba.auth.ManagedContext.class, WorkerRealm.class);
        BuildsEnvAction ba = build.getAction(BuildsEnvAction.class);

        Map<String, Object> binding = getSettingsBinding();
        binding.put("build", build);
        binding.put("worker", realm.getUser(ba.env.get(BuildsEnvAction.MBA_WORKER_USER)));

	    String jobName=build.getProject().getName();
	    FilePath remoteSettings = null;
	    //String updateCenterJobConfigXmlPath = "classpath:gmrt/mba/plugins/update/ManagedContext/config.xml";
	    String updateCenterPomPath = "classpath:gmrt/mba/plugins/update/ManagedContext/update-center-pom.xml";
	    Resource r = Appliance.getInstance().getContext(ManagedContext.class).getResource(updateCenterPomPath);
        //remoteSettings = getBuildSettingsPath(node,jobName,r.getFilename());
	    remoteSettings = getBuildSettingsPath(node,jobName,"pom.xml");
        writeSettings("CODE/Builds UpdateCenter build job support settings resources", getBuildSettingsSupportContents(r), binding, remoteSettings, listener);
        return remoteSettings;
    }

    public static UpdatePlugin getInstance() {
        return Hudson.getInstance().getPlugin(UpdatePlugin.class);
    }
}
