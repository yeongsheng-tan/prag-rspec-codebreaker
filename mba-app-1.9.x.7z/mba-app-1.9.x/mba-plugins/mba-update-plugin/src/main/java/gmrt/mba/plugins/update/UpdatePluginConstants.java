package gmrt.mba.plugins.update;

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 1/28/11
 */
public class UpdatePluginConstants {
	public static final String mbaUpdateSiteId="mba-update-site";
	public static final long updateSiteRefreshRate=10800000; // 3 hour refresh rate for the update-center.json file fetch in millisecond
	public static final int httpTimeOut=5000; // HTTP Timeout setting in milliseconds; defaults to 5 seconds in millisecond
}
