package gmrt.mba.plugins.update;

import hudson.Extension;
import hudson.Launcher;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.model.Computer;
import hudson.tasks.BuildWrapper;
import hudson.tasks.BuildWrapperDescriptor;

import java.io.IOException;

/**
 * Provides the workspace path for a UpdateCenter job on the CODE/Builds MasterComputer.
 *
 * @author yeongsheng.tan@baml.com
 * @since Nov 23, 2011
 */
public class UpdatePluginBuildWrapper extends BuildWrapper {

    @Extension
    public static class DescriptorImpl extends BuildWrapperDescriptor {
        @Override
        public boolean isApplicable(AbstractProject<?, ?> item) {
            return false;
        }
        @Override
        public String getDisplayName() {
            return "CODE/Builds UpdatePlugin Build Wrapper";
        }
    }

    /**
     * Calls {@link gmrt.mba.plugins.update.UpdatePlugin#writeJobBuildSupportSettings(hudson.model.Node, hudson.model.AbstractBuild, hudson.model.TaskListener)}.
     */
    @Override
    public Environment setUp(final AbstractBuild build, Launcher launcher, final BuildListener listener)
            throws IOException, InterruptedException {

        UpdatePlugin.getInstance().writeJobBuildSupportSettings(Computer.currentComputer().getNode(), build, listener);

        return new Environment() {
            @Override
            public boolean tearDown(AbstractBuild build, BuildListener listener) throws IOException, InterruptedException {
                return super.tearDown(build, listener);
            }
        };
    }
}
