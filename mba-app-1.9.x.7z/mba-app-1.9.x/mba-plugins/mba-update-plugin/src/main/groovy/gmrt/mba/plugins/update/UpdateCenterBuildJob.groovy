package gmrt.mba.plugins.update

import hudson.model.Hudson
import hudson.model.TopLevelItem
import org.apache.log4j.Logger

/**
 * Convenience class to construct/destroy a Jenkins UpdateCenter build project.
 *
 * @author yeongsheng.tan@baml.com
 * @since Nov 23, 2011
 */
class UpdateCenterBuildJob {
	def static Logger LOG = Logger.getLogger(UpdateCenterBuildJob.class)
	private Hudson h;

	public UpdateCenterBuildJob(Hudson jenkins_instance){
		h = jenkins_instance
	}

	public TopLevelItem createJob(String jobName, InputStream jobConfig){
		if (getJob(jobName)!=null) {
            LOG.info("Job '${jobName}' already exists")
            return null
        }
		TopLevelItem tli = h.createProjectFromXML(jobName,jobConfig)
		h.save()
		h.reload()
		return tli
	}

	public TopLevelItem getJob(String jobName){
		return h.getItem(jobName)
	}

	public void deleteJob(String jobName){
		TopLevelItem job = h.getItem(jobName)
		if(job!=null){
			job.delete()
			h.save()
			h.reload()
		}
	}

	public void writeBuildWrapperSettings(String jobName){
		h.reload()
		def project = h.projects.find{ jobName.equals(it.getDisplayName()) }
		if(project!=null)
			project.getBuildWrappersList().replace(new UpdatePluginBuildWrapper())
		h.reload()
	}
}
