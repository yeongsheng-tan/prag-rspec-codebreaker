package gmrt.mba.plugins.update

import gmrt.bhive.plugins.bhive.artifacts.ArtifactsLogic
import java.util.jar.Attributes
import java.util.jar.JarFile
import java.util.jar.Manifest
import java.util.zip.ZipEntry
import net.sf.json.JSONObject
import org.sonatype.aether.artifact.Artifact

/**
 * @author jason.stiefel@bankofamerica.com
 * @since 2/18/11
 */
class Hpi {

  private ArtifactsLogic al;
  private String mbaRepositoryId;
  private Artifact pomArtifact;
  private Artifact artifact;
  private Manifest mf;

  def String displayName;
  def String shortName;
  def long timestamp;
  def URL url;
  //def Map<String, Hpi> dependencies = [:];
  def String dependencies;
  def String developers;
  def String builtBy;
  def String coreVersion;
  def String title;
  def String excerpt;
  //def String coreSince;
  def String version;
  def String wiki;

  def String groupId;
  def String previousTimestamp;
  def String previousVersion;

  Hpi(ArtifactsLogic al, String mbaRepositoryId, Artifact artifact) {
    this.al = al;
    this.mbaRepositoryId = mbaRepositoryId;
    this.artifact = artifact;
    this.pomArtifact = al.getPom(mbaRepositoryId, artifact);
    this.shortName = getShortName(artifact);
    //this.version = artifact.baseVersion;

    JarFile jar = new JarFile(artifact.file);
    ZipEntry ze = jar.getEntry('META-INF/MANIFEST.MF');
    timestamp = ze.getTime();
    mf = jar.manifest;
    jar.close();

    builtBy = mf.mainAttributes.getValue('Built-By');
    coreVersion = getRequiredJenkinsVersion(mf.getMainAttributes());
    //coreSince = mf.mainAttributes.getValue('Compatible-Since-Version');
	title = mf.mainAttributes.getValue('Implementation-Title')
    displayName = mf.mainAttributes.getValue('Long-Name');
	excerpt = mf.mainAttributes.getValue('Specification-Title')
	version = mf.mainAttributes.getValue('Implementation-Version')
	groupId = mf.mainAttributes.getValue('Group-Id')
	//url = 'http://' + Appliance.instance.config.mbaUpdateHost + ':' + Appliance.instance.config.mbaUpdatePort + '/artifacts/content/groups/mba-group/gmrt/mba/plugins/' + title + '/' + version + '/' + artifact.artifactId +'/title-version.hpi'
	/*
	al.getDependencies(mbaRepositoryId, pomArtifact).
            findAll { it.artifact.extension == 'hpi' && !dependencies.containsKey(getShortName(it.artifact)); }.
            each { Dependency d ->
      Artifact resolved = al.resolveArtifact(mbaRepositoryId, d.artifact);
      dependencies[getShortName(d.artifact)] = new Hpi(al, mbaRepositoryId, resolved);
    }
    */
	wiki = mf.mainAttributes.getValue('Url').toURL()
	dependencies = mf.mainAttributes.getValue('Plugin-Dependencies')
	developers = mf.mainAttributes.getValue('Plugin-Developers')

	Set<Artifact> allVersionsOfThisHpi = al.find(mbaRepositoryId,groupId.trim(),artifact.artifactId,null,'hpi',null)
	Artifact previousVersionHpi=null;
	if(allVersionsOfThisHpi.size() > 1){
		List lstAllVersionsOfThisHpi = allVersionsOfThisHpi.asList()
		previousVersionHpi = lstAllVersionsOfThisHpi.sort().get(lstAllVersionsOfThisHpi.size() - 1)
	}else{
		previousVersionHpi = artifact
	}
	Map previousVersionDetail = getPreviousHpiVersionInfo((previousVersionHpi==null?artifact:previousVersionHpi))
	previousVersion = previousVersionDetail.get('previousVersion')
	previousTimestamp = previousVersionDetail.get('previousTimestamp')

  }

  /**
   * Returns what I _think_ is the shortname for an artifact.
   * @param artifact
   * @return
   */
  protected String getShortName(Artifact artifact) {
    return "${artifact.artifactId}:${artifact.baseVersion}";
  }

  JSONObject toJSON() {

    JSONObject plugin = new JSONObject()

    plugin['buildDate'] = new Date(timestamp).format('MMM dd, yyyy');
	plugin['dependencies'] = dependencies
	plugin['developers'] = developers
	plugin['excerpt'] = excerpt
	plugin['name'] = displayName
    //plugin['previousTimestamp'] = new Date(timestamp - 10000).format("yyyy-MM-dd'T'HH:mm:ss'.00Z'");
	plugin['previousTimestamp'] = previousTimestamp
    plugin['previousVersion'] = previousVersion;
    plugin['releaseTimestamp'] = new Date(timestamp).format("yyyy-MM-dd'T'HH:mm:ss'.00Z'");
    //plugin['wiki'] = "http://code.bankofamerica.com/docs/display/MBS/Plugins/${hpi.shortName}";

    plugin['requiredCore'] = coreVersion;
    //plugin['compatibleSinceVersion'] = coreSince;

/*    JSONArray deps = new JSONArray();
    dependencies.each {
      JSONObject dep = new JSONObject();
      dep['name'] = it.value.shortName;
      dep['version'] = it.value.version;
      // TODO support optional
      deps << dep;
    }
    plugin['dependencies'] = deps;

    plugin['developers'] = new JSONArray();
	*/

	plugin['title'] = title
	//plugin['url'] = url
	plugin['version'] = version
	plugin['wiki'] = wiki
    plugin;
  }

  boolean equals(o) {
    if (this.is(o)) return true;
    if (!(o instanceof Hpi)) return false;

    Hpi hpi = (Hpi) o;

    if (artifact != hpi.artifact) return false;
    if (mbaRepositoryId != hpi.mbaRepositoryId) return false;
    if (pomArtifact != hpi.pomArtifact) return false;

    return true;
  }

  int hashCode() {
    int result;
    result = (mbaRepositoryId != null ? mbaRepositoryId.hashCode() : 0);
    result = 31 * result + (pomArtifact != null ? pomArtifact.hashCode() : 0);
    result = 31 * result + (artifact != null ? artifact.hashCode() : 0);
    return result;
  }

	//Borrowed from backend-update-center2 sources from Jenkins public git repo
	//Replaces the deprecated Hudson-Version with the Jenkins-Version manifest attribute
    public String getRequiredJenkinsVersion(Attributes attrib) throws IOException {
        String v = attrib.getValue("Jenkins-Version");
        if (v!=null)
	        return v;

        v = attrib.getValue("Hudson-Version");
        if (fixNull(v) != null) {
            try {
                VersionNumber n = new VersionNumber(v);
                if (n.compareTo(MavenRepositoryImpl.CUT_OFF)<=0)
                    return v;   // Hudson <= 1.395 is treated as Jenkins
                // TODO: Jenkins-Version started appearing from Jenkins 1.401 POM.
                // so maybe Hudson > 1.400 shouldn't be considered as a Jenkins plugin?
            } catch (IllegalArgumentException e) {
            }
        }

        // Parent versions 1.393 to 1.398 failed to record requiredCore.
        // If value is missing, let's default to 1.398 for now.
        return "1.398";
    }

	/**
     * Earlier versions of the maven-hpi-plugin put "null" string literal, so we need to treat it as real null.
     */
    private static String fixNull(String v) {
        if("null".equals(v))    return null;
        return v;
    }

	public Map<String,String> getPreviousHpiVersionInfo(Artifact artifact){
		JarFile jarFile = new JarFile(artifact.file);
		ZipEntry jarZip = jarFile.getEntry('META-INF/MANIFEST.MF');
		long artifactTimestamp = jarZip.getTime();
		Manifest manifest = jarFile.manifest;
		jarFile.close();

		Map previousVersionInfo = new HashMap();
		previousVersionInfo.put('previousVersion',manifest.mainAttributes.getValue('Plugin-Version'))
		previousVersionInfo.put('previousTimestamp',new Date(artifactTimestamp).format("yyyy-MM-dd'T'HH:mm:ss'.00Z'"))
	}
}