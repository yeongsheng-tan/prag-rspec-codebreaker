package gmrt.mba.plugins.update

import gmrt.bhive.plugins.bhive.artifacts.ArtifactsLogic
import org.sonatype.aether.artifact.Artifact
import org.apache.log4j.Logger
import org.sonatype.aether.util.artifact.DefaultArtifact

/**
 * A simple finder that locates HPI artifacts in Nexus repository using the search interfaces.
 *
 * @author jason.stiefel@bankofamerica.com
 * @since 2/18/11
 */
class HpiFinder {

  private static Logger LOG = Logger.getLogger(HpiFinder.class);

  ArtifactsLogic artifactsLogic;

  /**
   * Constructs a finder that uses the provided artifacts logic.
   */
  HpiFinder(ArtifactsLogic al) {
    this.artifactsLogic = al;
  }

  /**
   * Recursively collects list of {@link Hpi} that are found in the specified "target" in the local artifact repository.
   *
   * @param mbaRepositoryId See {@link ArtifactsLogic#MBA_ARTIFACTS_GROUP_ID} etc.. Matching an artifactId is not required
   * just suggested.
   * @param groupId A group pattern to be search. Can be a specific group or a wildcard (e.g. "gmrt.mba.*")
   *
   * TODO Enhance to the point where a groupId isn't required. Will probably need to download the indexes from the
   * repository and search locally? I can't figure out a way to search a remote repo with only
   */
  Set<Hpi> find(String mbaRepositoryId, String groupId) {
    Map<String, Hpi> hpis = [:];
    artifactsLogic.find(mbaRepositoryId, groupId, null, null, 'hpi', null).
            collect { new DefaultArtifact(it.groupId, it.artifactId, 'hpi', it.version) }.
            each { Artifact artifact ->

      String shortName = "${artifact.artifactId}:${artifact.version}"
      if (!hpis[shortName]) {
        LOG.info("Resolving hpi ${shortName}");
        Artifact dependency = artifactsLogic.resolveArtifact(mbaRepositoryId, artifact);
        Hpi hpi = new Hpi(artifactsLogic, mbaRepositoryId, dependency);
        hpis.put(shortName, hpi);
        hpi.dependencies.each {
          hpis.put(it.key, it.value);
        }
      }

    }
    hpis.values();
  }

}
