package gmrt.mba.plugins.update.util

import gmrt.mba.plugins.update.VersionNumber
import java.util.jar.Attributes
import java.util.jar.JarFile
import java.util.jar.Manifest
import java.util.zip.ZipEntry
import net.sf.json.JSONObject

/**
 * @author yeongsheng.tan@bankofamerica.com
 * @since 9/19/11
 */
class HpiJsonUtil {
	JSONObject toUpdateCenterPluginsJsonFormat(File latestHpiFile, File previousHpiFile) throws IOException {
		JSONObject plugin = new JSONObject();

		String previousHpiVersion = '-';
		String envTimeZone = System.getenv()['user.timezone']
		Calendar zeroEpoch = Calendar.getInstance(TimeZone.getTimeZone(envTimeZone==null ? 'EST5EDT' : envTimeZone))
		zeroEpoch.setTimeInMillis(0)
		String previousHpiTimeStamp = zeroEpoch.format("yyyy-MM-dd'T'HH:mm:ss'.00Z'")

		if(previousHpiFile!=null){
			JarFile previousJar = new JarFile(previousHpiFile);
			ZipEntry previousZe = previousJar.getEntry("META-INF/MANIFEST.MF");
			previousHpiTimeStamp = (new Date(previousZe.getTime())).format("yyyy-MM-dd'T'HH:mm:ss'.00Z'");
			Manifest previousMf = previousJar.manifest;
			previousJar.close();

			previousHpiVersion = previousMf.mainAttributes.getValue('Implementation-Version');
		}

		JarFile latestJar = new JarFile(latestHpiFile);
		ZipEntry latestZe = latestJar.getEntry("META-INF/MANIFEST.MF");
		long latestTimestamp = latestZe.getTime();
		Manifest latestMf = latestJar.manifest;
		latestJar.close();

		String builtBy = latestMf.mainAttributes.getValue('Built-By');
		String coreVersion = getRequiredJenkinsVersion(latestMf.getMainAttributes());
		//coreSince = mf.mainAttributes.getValue('Compatible-Since-Version');
		String title = latestMf.mainAttributes.getValue('Implementation-Title');
		String displayName = latestMf.mainAttributes.getValue('Long-Name');
		String excerpt = latestMf.mainAttributes.getValue('Specification-Title');
		String version = latestMf.mainAttributes.getValue('Implementation-Version');
		String groupId = latestMf.mainAttributes.getValue('Group-Id');
		//url = 'http://' + Appliance.instance.config.mbaUpdateHost + ':' + Appliance.instance.config.mbaUpdatePort + '/artifacts/content/groups/mba-group/gmrt/mba/plugins/' + title + '/' + version + '/' + artifact.artifactId +'/title-version.hpi'
		/*
		al.getDependencies(mbaRepositoryId, pomArtifact).
				findAll { it.artifact.extension == 'hpi' && !dependencies.containsKey(getShortName(it.artifact)); }.
				each { Dependency d ->
		  Artifact resolved = al.resolveArtifact(mbaRepositoryId, d.artifact);
		  dependencies[getShortName(d.artifact)] = new Hpi(al, mbaRepositoryId, resolved);
		}
		*/
		String wiki = latestMf.mainAttributes.getValue('Url').toURL();
		String dependencies = latestMf.mainAttributes.getValue('Plugin-Dependencies');
		String developers = latestMf.mainAttributes.getValue('Plugin-Developers');

		plugin['buildDate'] = new Date(latestTimestamp).format('MMM dd, yyyy');
		plugin['dependencies'] = dependencies;
		plugin['developers'] = developers;
		plugin['excerpt'] = excerpt;
		plugin['name'] = displayName;
		//plugin['previousTimestamp'] = new Date(timestamp - 10000).format("yyyy-MM-dd'T'HH:mm:ss'.00Z'");
		plugin['previousTimestamp'] = previousHpiTimeStamp;
		plugin['previousVersion'] = previousHpiVersion;
		plugin['releaseTimestamp'] = new Date(latestTimestamp).format("yyyy-MM-dd'T'HH:mm:ss'.00Z'");
		//plugin['wiki'] = "http://code.bankofamerica.com/docs/display/MBS/Plugins/${hpi.shortName}";

		plugin['requiredCore'] = coreVersion;
		//plugin['compatibleSinceVersion'] = coreSince;

	/*    JSONArray deps = new JSONArray();
		dependencies.each {
		  JSONObject dep = new JSONObject();
		  dep['name'] = it.value.shortName;
		  dep['version'] = it.value.version;
		  // TODO support optional
		  deps << dep;
		}
		plugin['dependencies'] = deps;

		plugin['developers'] = new JSONArray();
		*/

		plugin['title'] = title;
		//plugin['url'] = url
		plugin['version'] = version;
		plugin['wiki'] = wiki;

		plugin;
    }

	//Borrowed from backend-update-center2 sources from Jenkins public git repo
	//Replaces the deprecated Hudson-Version with the Jenkins-Version manifest attribute
    String getRequiredJenkinsVersion(Attributes attrib) throws IOException {
        String v = attrib.getValue("Jenkins-Version");
        if (v!=null)
	        return v;

        v = attrib.getValue("Hudson-Version");
        if (v!=null && fixNull(v) != null) {
            try {
                VersionNumber n = new VersionNumber(v);
                if (n.compareTo(MavenRepositoryImpl.CUT_OFF)<=0)
                    return v;   // Hudson <= 1.395 is treated as Jenkins
                // TODO: Jenkins-Version started appearing from Jenkins 1.401 POM.
                // so maybe Hudson > 1.400 shouldn't be considered as a Jenkins plugin?
            } catch (IllegalArgumentException e) {
            }
        }

        // Parent versions 1.393 to 1.398 failed to record requiredCore.
        // If value is missing, let's default to 1.398 for now.
        return "1.398";
    }

	/**
     * Earlier versions of the maven-hpi-plugin put "null" string literal, so we need to treat it as real null.
     */
    static String fixNull(String v) {
        if("null".equals(v))    return null;
        return v;
    }
}
