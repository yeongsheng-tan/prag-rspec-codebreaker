package gmrt.mba.plugins.scheduledtask;

import org.codehaus.plexus.component.annotations.Component;
import org.sonatype.nexus.formfields.CheckboxFormField;
import org.sonatype.nexus.formfields.FormField;
import org.sonatype.nexus.formfields.NumberTextFormField;
import org.sonatype.nexus.formfields.RepoOrGroupComboFormField;
import org.sonatype.nexus.maven.tasks.descriptors.SnapshotRemovalTaskDescriptor;
import org.sonatype.nexus.tasks.descriptors.ScheduledTaskDescriptor;

import java.util.ArrayList;
import java.util.List;

/**
 * PurgeOldMbaSnapshotsTask descriptor
 *
 * @author yeongsheng.tan@baml.com
 * @since 6/22/11
 */

@Component(role = ScheduledTaskDescriptor.class, hint = PurgeOldMbaSnapshotsTaskDescriptor.ID, description = PurgeOldMbaSnapshotsTaskDescriptor.NAME)
public class PurgeOldMbaSnapshotsTaskDescriptor extends SnapshotRemovalTaskDescriptor {
	public static final String ID = PurgeOldMbaSnapshotsTask.HINT;
	public static final String NAME = "Purge Old MBA Snapshots Task";

    public static final String REPO_OR_GROUP_FIELD_ID = "repositoryOrGroupId";
    public static final String MIN_TO_KEEP_FIELD_ID = "minSnapshotsToKeep";
    public static final String KEEP_DAYS_FIELD_ID = "removeOlderThanDays";
    public static final String REMOVE_WHEN_RELEASED_FIELD_ID = "removeIfReleaseExists";

    private final RepoOrGroupComboFormField repoField = new RepoOrGroupComboFormField(REPO_OR_GROUP_FIELD_ID,FormField.MANDATORY);

    private final NumberTextFormField minToKeepField = new NumberTextFormField(MIN_TO_KEEP_FIELD_ID, "Minimum snapshot count","Minimum number of snapshots to keep for one GAV.", FormField.OPTIONAL);

    private final NumberTextFormField keepDaysField = new NumberTextFormField(KEEP_DAYS_FIELD_ID, "Snapshot retention (days)",
                                 "The job will purge all snapshots older than the entered number of days, but will obey to Min. count of snapshots to keep.",
                                 FormField.OPTIONAL);

    private final CheckboxFormField removeWhenReleasedField = new CheckboxFormField(REMOVE_WHEN_RELEASED_FIELD_ID, "Remove if released",
                               "The job will purge all snapshots that have a corresponding released artifact (same version not including the -SNAPSHOT).",
                               FormField.OPTIONAL);

	public String getId() {
		return ID;
	}

	public String getName() {
		return NAME;
	}

	public List<FormField> formFields() {
        List<FormField> fields = new ArrayList<FormField>();

        fields.add(repoField);
        fields.add(minToKeepField);
        fields.add(keepDaysField);
        fields.add(removeWhenReleasedField);

        return fields;
	}
}
