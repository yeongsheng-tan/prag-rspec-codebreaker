package gmrt.mba.plugins.scheduledtask;

import org.codehaus.plexus.component.annotations.Component;
import org.codehaus.plexus.util.StringUtils;
import org.sonatype.nexus.maven.tasks.SnapshotRemovalRequest;
import org.sonatype.nexus.maven.tasks.SnapshotRemovalResult;
import org.sonatype.nexus.maven.tasks.SnapshotRemoverTask;
import org.sonatype.nexus.maven.tasks.descriptors.SnapshotRemovalTaskDescriptor;
import org.sonatype.nexus.scheduling.NexusTask;

/**
 * Creates the required scheduled tasks on MBA startup - existing tasks created by users are untouched
 *
 * @author yeongsheng.tan@baml.com
 * @since 6/6/11
 */
@Component(role = NexusTask.class,hint = PurgeOldMbaSnapshotsTask.HINT, instantiationStrategy = "per-lookup")
public class PurgeOldMbaSnapshotsTask extends SnapshotRemoverTask{
	//private static Logger LOG = Logger(PurgeOldMbaSnapshotsTask.class);
	protected static final String HINT = "PurgeOldMbaSnapshotsTask";
    protected static final int MIN_SNAPSHOTS_TO_KEEP = 1;
    protected static final int OLDER_THAN_DAYS = 7;
	protected static final boolean REMOVE_IF_RELEASE_EXISTS = false;
	protected static final String MBA_SNAPSHOTS_REPO_ID = "mba-snapshots";

	@Override
	protected String getAction() {
		return "PURGE OLD mba-snapshots";
	}

	@Override
	protected String getMessage() {
		if (getRepositoryId() != null) {
			return "Purging old snapshots artifacts from " + getRepositoryName();
		} else {
			return "Purging old snapshots artifacts from all registered repositories";
		}
	}

    @Override
    protected String getRepositoryFieldId(){
        return MBA_SNAPSHOTS_REPO_ID;
    }

	@Override
    public int getMinSnapshotsToKeep(){
        String param = getParameters().get(SnapshotRemovalTaskDescriptor.MIN_TO_KEEP_FIELD_ID);

        if ( StringUtils.isEmpty(param) ){
            return MIN_SNAPSHOTS_TO_KEEP;
        }

        return Integer.parseInt(param);
    }

	@Override
    public int getRemoveOlderThanDays(){
		String param = getParameters().get(SnapshotRemovalTaskDescriptor.KEEP_DAYS_FIELD_ID);

        if (StringUtils.isEmpty(param)){
            return OLDER_THAN_DAYS;
        }

        return Integer.parseInt( param );
    }

	@Override
    public boolean isRemoveIfReleaseExists(){
        return REMOVE_IF_RELEASE_EXISTS;
    }

	@Override
    public void setRemoveIfReleaseExists( boolean removeIfReleaseExists ){
        getParameters().put(SnapshotRemovalTaskDescriptor.REMOVE_WHEN_RELEASED_FIELD_ID, Boolean.toString(REMOVE_IF_RELEASE_EXISTS));
    }

	@Override
    public SnapshotRemovalResult doRun() throws Exception{
        SnapshotRemovalRequest req = new SnapshotRemovalRequest( getRepositoryId(), getRepositoryGroupId(), getMinSnapshotsToKeep(),getRemoveOlderThanDays(), isRemoveIfReleaseExists() );
        return getNexus().removeSnapshots( req );
	}
}
